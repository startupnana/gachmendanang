﻿var fName = "sm_vjv202_12_";
function SetSceneAction(){
}
var arrTotalFrames = [1195,495,465];
var cTotalFrames = 0;
var arrFrmOffSet = new Array();
for (var i=0; i<arrTotalFrames.length; i++){
	cTotalFrames += arrTotalFrames[i];
	arrFrmOffSet[i] = 0;
	if (i != 0){
		for (var ii=0; ii<i; ii++){
			arrFrmOffSet[i] += arrTotalFrames[ii];
		}
	}
}
