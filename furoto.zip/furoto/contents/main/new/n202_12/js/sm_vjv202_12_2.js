(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.webFontTxtInst = {}; 
var loadedTypekitCount = 0;
var loadedGoogleCount = 0;
var gFontsUpdateCacheList = [];
var tFontsUpdateCacheList = [];
lib.ssMetadata = [];



lib.updateListCache = function (cacheList) {		
	for(var i = 0; i < cacheList.length; i++) {		
		if(cacheList[i].cacheCanvas)		
			cacheList[i].updateCache();		
	}		
};		

lib.addElementsToCache = function (textInst, cacheList) {		
	var cur = textInst;		
	while(cur != exportRoot) {		
		if(cacheList.indexOf(cur) != -1)		
			break;		
		cur = cur.parent;		
	}		
	if(cur != exportRoot) {		
		var cur2 = textInst;		
		var index = cacheList.indexOf(cur);		
		while(cur2 != cur) {		
			cacheList.splice(index, 0, cur2);		
			cur2 = cur2.parent;		
			index++;		
		}		
	}		
	else {		
		cur = textInst;		
		while(cur != exportRoot) {		
			cacheList.push(cur);		
			cur = cur.parent;		
		}		
	}		
};		

lib.gfontAvailable = function(family, totalGoogleCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], gFontsUpdateCacheList);		

	loadedGoogleCount++;		
	if(loadedGoogleCount == totalGoogleCount) {		
		lib.updateListCache(gFontsUpdateCacheList);		
	}		
};		

lib.tfontAvailable = function(family, totalTypekitCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], tFontsUpdateCacheList);		

	loadedTypekitCount++;		
	if(loadedTypekitCount == totalTypekitCount) {		
		lib.updateListCache(tFontsUpdateCacheList);		
	}		
};
// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.音正解 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		playSound("vjvq_rWAV");
	}
	this.frame_13 = function() {
		//全て解答済みなのに判定を5秒間押さない場合
		if (exportRoot.mcLyoko.q1ans1.visible == false && exportRoot.mcLyoko.q1ans2.visible == false && exportRoot.mcLyoko.q1ans3.visible == false && exportRoot.mcLyoko.q1ans4.visible == false) {
			exportRoot.mcLyoko.keimc.gotoAndStop(2);
			exportRoot.mcLtate.keimc.gotoAndStop(2);
			exportRoot.timerMc.gotoAndPlay(2);
		}
		this.gotoAndStop(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(2).call(this.frame_3).wait(10).call(this.frame_13).wait(1));

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000099").s().p("AgvAwIAAhfIBfAAIAABfg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(14));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.7,-4.7,9.5,9.5);


(lib.ボタン範囲PB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AEYEEIovAAQgMAAgJgJQgJgJAAgMIAAnLQAAgMAJgJQAJgJAMAAIIvAAQAMAAAJAJQAJAJAAAMIAAHLQAAAMgJAJQgJAJgMAAIAAAAg");
	this.shape.setTransform(23.5,22.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.フェード用2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ArtGVIAAspIXbAAIAAMpg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75,-40.4,150,81);


(lib.グラデbox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","rgba(255,255,255,0)"],[0.906,1],-1.5,43,-1.5,-43).s().p("Eg2rAG9IAAt5MBtXAAAIAAN5g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","rgba(255,255,255,0)"],[0.906,1],-1.5,43,-1.5,-43).s().p("EAmwAG9IAAt5IP8AAIAAN5gEg2rAG9IAAt5IUoAAIAAN5g");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","rgba(255,255,255,0)"],[0.906,1],-1.5,43,-1.5,-43).s().p("EAiEAG9IAAt5IUoAAIAAN5gEg2rAG9IAAt5IUoAAIAAN5g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-350,-44.5,700,89);


(lib.選択枠解答q1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFCC00").ss(2,1,1).p("AHWiBIurAAQg8AAAAA8IAACLQAAA8A8AAIOrAAQA8AAAAg8IAAiLQAAg8g8AAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AnVCCQg8AAAAg8IAAiLQAAg8A8AAIOrAAQA8AAAAA8IAACLQAAA8g8AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.選択枠解答q1, new cjs.Rectangle(-54,-14,108,28), null);


(lib.jimaku = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// 字幕
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQARQgGgHAAgKQAAgJAGgGQAHgHAJAAQAKAAAHAHQAGAGAAAJQAAAKgGAHQgHAGgKAAQgJAAgHgGgAgKgKQgEAFAAAFQAAAGAEAFQAFAEAFAAQAGAAAFgEQAEgFAAgGQAAgFgEgFQgFgEgGAAQgFAAgFAEg");
	this.shape.setTransform(154.8,34.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag+ApQgFgLAAgkQAAgbADgbIANADQAIACgHAFQgDAZABAUQAAAaADALQADALAHAAQAHAAAGgKQADgHADgJIANAJQgFAPgHAIQgKAMgJAAQgRAAgHgUgAASgrIANgIQAfAgAGArIgSAFQgIgugYgag");
	this.shape_1.setTransform(143,29.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAIBKQgigBgOgOQgJgKAAgMQAAgNAHgHQAMgMAZAAQAYAAAEACQgQgSgGgOQgaACgaAAIgEgOQAgAAAUgBQgHgSgCgRIANAAQAGACgEAEQACAMAGAPQAXgCAQgDIAEAOIgmAFQANAYAbASIgKAMQgYgLgXAAQgWAAgJAIQgEAFAAAHQAAAHAGAFQAKAKAhgBIAYAAIgEAQg");
	this.shape_2.setTransform(128.3,28.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhBBDQASgpAIgtIgdABIgDgNQATAAAPgCIAEgjIAOACQAHACgGAEIgFAaQAPgCALgDIADANIgfAFQgKA7gPAigAAkBHQgZAAgWgMIAGgMQAQAJAZAAIAdAAIAAAPgAgCgBQAcgLAhAAIADANQgnABgWAKgAAbgwIAGgKIAaASIgGAJIgagRgAAog+IAGgJQALAGAPALIgGAKQgPgLgLgHg");
	this.shape_3.setTransform(114.1,28.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgdARQgKgJAAgGQAAgHAIgGQAqgpAMgUIAMAJQAHAHgKgCQgKAPgqAoQgCACAAABQAAAEACACQAlAeAXAZIgNAMQgXgbghgdg");
	this.shape_4.setTransform(101.2,28.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgHAtQgQgPAAgWQAAgeAYgSIg/AJIgEgPQBBgEBBgMIADAPQgYAAgNAFQgOAFgNANQgMANAAATQAAAQAJAKQAOANAlABIgFAPQgngCgOgQg");
	this.shape_5.setTransform(88.4,29.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgrA3QgJgIAAgZIAAhYIAOAAQAGABgFAEIAABTQAAARAGAGQAIAHAOAAQAZAAAbgdIAKAMQgdAgggAAQgYAAgLgMg");
	this.shape_6.setTransform(74.8,29.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag5BMIgCgMIAKAAQAAAAABgBQAAAAABAAQAAgBAAAAQAAgBAAgBIAAgpIgQAFQgDAGgBgEIgEgOIAYgHIAAglIgXAAIAAgNIAXAAIAAgeIANAAQAFAAgEAEIAAAaIARAAIAAANIgRAAIAAAhIAQgFIACALIgSAHIAAA0QAAAKgLAAgAAXBMIAAg0IgWAAIAAANIgMAAIAAhnIBTAAIAABjIgNAAIAAgJIgWAAIAAA0gAAlAMIAWAAIAAgaIgWAAgAABAMIAWAAIAAgaIgWAAgAAlgaIAWAAIAAgbIgWAAgAABgaIAWAAIAAgbIgWAAg");
	this.shape_7.setTransform(58.9,28.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIBMQgWAAgIgJQgHgHAAgKQAAgLAJgIQANgOAZgKQgBgHgBgCQgDgDgJAAQgNAAgbAWIgLgKQAfgTALgXIglACIgDgNIAtgBQAEgJAEgSIAMADQAHADgHADIgFARIAtgGIACAOIgzAEQgHAOgGAHQAIgCAHAAQAIAAAFAFQAEAEABAJIAtgNIAEAOQgaAFgWAIIAAAdIgNAAIAAgYQgTAKgGAFQgIAIAAAHQAAAEAEAEQAFAFANAAIA3AAIAAANg");
	this.shape_8.setTransform(43.3,29);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag7A6IgFgRQBWgCAdhEIAOAKQgjBIhSAEQgCAEgCAAQAAAAAAAAQgBAAAAAAQAAgBgBAAQAAgBgBgBgAg+gvIAMgNQAOAIAVAUIgMANQgTgRgQgLg");
	this.shape_9.setTransform(28.8,29.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpA+QAngQARgbQgQgLgQgIIAIgMQAUAKANAHQAKgUACgQIgwAAQgMAXgTARIgMgIQAhgjALgnIAPAHQAFADgIACQgBAIgEAIIArAAIAHgDIAJAIQADAEgGACQgFAagKAVIAPALIgJAPIgPgLQgTAcgjASg");
	this.shape_10.setTransform(14.8,28.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMBMIAAhbIg8AAIAAgPIA8AAIAAglIAOAAQAGACgFAEIAAAfIA9AAIAAAPIg9AAIAABbgAhKAwQARgXALgaIAPAHQADADgGACQgKAWgPAXgAAWAJIAMgKQAYAYAMAWIgOAJQgOgYgUgVgAAag5IAIgIQALAIALAMIgIAIQgMgMgKgIgAAshEIAJgHQALAIALANIgIAIIgXgWg");
	this.shape_11.setTransform(0.4,28.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAEAxQAYgHANgNQANgMAAgSQgBgVgOgOQgNgOgeABIAMAHQAHADgHAEQgKBCgQAPQgJAJgJAAQgLAAgGgGQgQgQAAgYQAAgcAUgVQAXgWAfAAQAeAAARAQQASATAAAZQAAAbgRAQQgLAMgXALgAgkgfQgSARAAAZQAAAPAKAKQACACAEAAQAEgBAFgEQAPgPAHhCQgRAEgMANg");
	this.shape_12.setTransform(-16.3,29.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgYA8IAAgNIAkAAIAAhpIANAAIAAB2g");
	this.shape_13.setTransform(-29.4,30.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag+BBQAhgDADgPIgxAAIAAgKIAyAAIAAgKIgLAAIgLAAIAAg+IAyAAIgJgHQAMgNAGgXIAOAGQAFACgHACIgDAFIA0AAIAAALIgfAAIAGAKIgOADIgFgNIgNAAIgLARIArAAIAAA+IgSAAIAAAKIAtAAIAAAKIgtAAIAAAcIgOAAIAAgcIgdAAQgCAYgrAHgAgMAlIAcAAIAAgKIgcAAgAgjAQIBIAAIAAgJIhIAAgAgjAAIBIAAIAAgIIhIAAgAgjgQIBIAAIAAgJIhIAAgAhJgmQATgQAHgXIANAGQAFACgHABIgCAFIAmAAIAAALIgUAAIAFAKIgOACIgEgMIgKAAQgJAPgKAKg");
	this.shape_14.setTransform(-41.7,29);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhCBKIAAg2IA2AAIAAA0IgNAAIAAgHIgcAAIAAAJgAg1A2IAcAAIAAgXIgcAAgAAcBKIAAhSIgjAAIAAgMIAjAAIAAg1IANAAQAGABgGADIAAAxIAiAAIAAAMIgiAAIAABSgAg+AKIAAgMIAuAAIAAAMgAg+gLIAAgNIAuAAIAAANgAhKghIAAgMIBGAAIAAAMgAg+g5IAAgMIAuAAIAAAMg");
	this.shape_15.setTransform(-58.8,28.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgYA8IAAh2IAxAAIAAANIgkAAIAABpg");
	this.shape_16.setTransform(-71.1,27.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgWgHIAKgNQAVAMAOAPIgMAOQgPgSgSgKg");
	this.shape_17.setTransform(-83.1,34.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgHAtQgQgPAAgWQAAgeAYgSIg/AJIgEgPQBBgEBBgMIADAPQgYAAgNAFQgOAFgNANQgMANAAATQAAAQAJAKQAOANAlABIgFAPQgngCgOgQg");
	this.shape_18.setTransform(-94.7,29.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAPA5QAWgHAJgJQAKgKAAgQQAAgSgKgKQgMgNgVgBQgGAbgOAdIALAPIgKAIIgJgLQgFAJgGAFQgIAJgJAAQgJAAgJgIQgIgIAAgRQAAgXAagaQgFgUgCgRIANAAQAGABgFADQABAPADAKQASgKAQgDQADgKADgUIANAEQAGACgGACIgEAWQAYABAOAPQAPAOAAAYQAAAXgNANQgMAMgWAHgAg4AhQAAAKAFAEQAEAEAEAAQADAAAFgFQAEgEAHgMQgJgNgGgUQgRASAAASgAgcgNQAGAWAGAJQALgVAFgXQgPADgNAKg");
	this.shape_19.setTransform(-110.8,28.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgVA9QgGgHAAgKQAAgJAFgGQAIgIAPAAQAJAAAIACQABgWgBgXIgwAEIAAgOIAvgDQAAgSgDgPIAOAAQAIABgHAEIACAbIAjgCIAAAOIgiACQABAYgBAZQAUAIATANIgIAMQgOgKgRgIQAAAMgHAHQgIAIgQAAQgNAAgJgIgAgMAlQgDAEAAADQABAFACADQAFAEAIAAQAJAAAEgEQAFgGgBgJQgLgEgGAAQgIAAgFAEgAhGAXQABg1AHghIAPADQAEACgFADQgHAXAAA3QAAAZADAPIgPADQgCgTgBgYg");
	this.shape_20.setTransform(-127,28.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgHAtQgQgPAAgWQAAgeAYgSIg/AJIgEgPQBBgEBBgMIADAPQgYAAgNAFQgOAFgNANQgMANAAATQAAAQAJAKQAOANAlABIgFAPQgngCgOgQg");
	this.shape_21.setTransform(-143.7,29.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAHA+QAbgDAKgKQAHgGAAgOQAAgOgHgIQgJgHgPgCQgLAigMAOIADAJIgMAJIgDgIQgSAPgLAAQgJAAgGgGQgHgIAAgMQAAgXAPgQQAKgHAJgGIABgaIgbACIgDgOIAggBIACgeIAMAAQAGACgFAEIgCAXQAfgCAWgEIADAOQgcAEgdACIAAAUQAJgCAPgBIACgLIANACQAFABgEAEIgBAFQAVACALALQANAMAAAUQAAATgMAKQgMANgbAEgAgqAPQgMAMABAUQAAAFADAEQACABAEAAQAJAAANgMQgGgVgBgSQgGACgHAHgAgRAAQACAQAFAQQAKgOAEgVQgKAAgLADg");
	this.shape_22.setTransform(-159.3,29);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhCAGQAAgdAIgpIANADQAHACgGAEQgHAnAAAWQAAAaADAgIgQABQgCgjAAgYgAAeA0QgeAAgUgTIAIgLQARAQAZAAIAlAAIAAAOgAgPgqQAvgEAaAAIAAAOQgcgBgtAFg");
	this.shape_23.setTransform(-175.1,29.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Ag0BMIAAhCQgHAUgLAKIgGgOQASgWAFgiIgSAAIAAgMIATAAIAAghIALAAQAFABgFADIAAAdIAPAAIAAAMIgPAAIAAAYQALAGAHAIIgGANQgFgHgHgFIAABDgAgUBKIAAiSIAsAAIAAAsIggAAIAABmgAgIgkIAUAAIAAgKIgUAAgAgIg2IAUAAIAAgKIgUAAgAA6BKIgBgKIAGAAQABAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAAAIAAhaIgQAAIgQAAIAAgsIArAAIAACIQAAAKgHAAgAAsgkIAVAAIAAgKIgVAAgAAsg2IAVAAIAAgKIgVAAgAAXBIIAAgXQgKAJgNAIIgGgLQARgJAMgKIgWAAIAAgkIAWAAIAAgHIgYAAIAAgJIAYAAIAAgIIAIAAQAGABgFADIAAAEIAaAAIAAAJIgaAAIAAAHIAXAAIAAAkIgWAAQAQAGALAIIgGAMQgKgKgMgGIAAAagAAgAcIANAAIAAgJIgNAAgAAKAcIANAAIAAgJIgNAAgAAgAPIANAAIAAgHIgNAAgAAKAPIANAAIAAgHIgNAAg");
	this.shape_24.setTransform(-192.2,29.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AhJBKIAAgOIBDAAIAAgdIgzAAIAAgOIByAAIAAAOIgzAAIAAAdIBEAAIAAAOgAg+gBQAlgMAAgVIAAgIIgfAAIAAAXIgPAAIAAgjIBAAAIAAgTIANAAQAGAAgFAEIAAAPIBAAAIAAAfIgPAAIAAgTIgiAAIAAAcQAAAFAGAAIAOAAQAHAAACgKIANAFQgFAQgMAAIgZAAQgOAAAAgLIAAghIgUAAIAAAIQAAAegsAOg");
	this.shape_25.setTransform(-208.9,28.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgIBMQgWAAgIgJQgHgHAAgKQAAgLAJgIQANgOAZgKQgBgHgBgCQgDgDgJAAQgNAAgbAWIgLgKQAfgTALgXIglACIgDgNIAtgBQAEgJAEgSIAMADQAHADgHADIgFARIAtgGIACAOIgzAEQgHAOgGAHQAIgCAHAAQAIAAAFAFQAEAEABAJIAtgNIAEAOQgaAFgWAIIAAAdIgNAAIAAgYQgTAKgGAFQgIAIAAAHQAAAEAEAEQAFAFANAAIA3AAIAAANg");
	this.shape_26.setTransform(-224.8,29);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgGA+QASgEAMgJIAJALQADAEgHgBQgMAHgRAGgAAqA6IAJgKQAOAKAPAFIgHAMQgPgFgQgMgAg/BJIAAgvIgLAFIgFgMQAYgJANgKIgLgMQgIAIgKAGIgGgKQAXgNAGgWIALABQAFABgFAEIgEAGIAXAAIACgCIAKAIQABADgEAAQgGAKgLALQAKAHAVAHIgFAOQgXgNgKgIQgLAKgMAFIAsAAIAAAxIgLAAIAAgEIgcAAIAAAHgAgzA3IAcAAIAAgXIgcAAgAgvgSIAMALQAGgFAGgLIgVAAgAAHAuIAAhYIAUAAIAFgQIgbAAIAAgMIBEAAIAAAMIgcAAIgHAQIAeAAIAABYgAATAkIAmAAIAAgQIgmAAgAATAKIAmAAIAAgPIgmAAgAATgQIAmAAIAAgPIgmAAgAhHgeIAAgcIAdAAIAAgRIANAAQAFABgFADIAAANIAdAAIAAAYIgMAAIAAgNIgwAAIAAARg");
	this.shape_27.setTransform(-240.3,29.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhBBJIAAgNIA7AAIAAgrIg3AAIAAgMIA3AAIAAgQIgZAAIAAgKQgQAMgWAIIgHgPQAzgQATgoIAQACQAAAAABAAQAAABAAAAQAAABAAAAQgBABgBABQAXAgAsAOIgGAPQgUgGgQgMIAAAMIgbAAIAAAQIA5AAIAAAMIg5AAIAAArIA9AAIAAANgAgbgZIA6AAQgPgIgPgYQgOAWgOAKgAgtAfIANgHQAHALAHAPIgOAHQgGgPgHgLgAAVAzQAGgMAFgRIANAEQAJACgIADQgEAMgHAMg");
	this.shape_28.setTransform(-257.5,28.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgXBDQgGgGAAgLQAAgJAGgGQAJgJAQAAQALAAAHACIAAgnIALAAQAIABgGAEIAAAmQAQAEASAKIgHANQgPgJgMgEQgCAOgGAGQgJAIgOAAQgRABgIgIgAgLAqQgEADAAAFQAAAEACADQAFAEAIAAQAKAAAEgEQAGgGAAgKQgIgDgKAAQgKAAgDAEgAhEAlQAUglAKgbQgLABgQAAIgCgOIAhgCIAIgfIAMADQAHADgHADIgFAVQAKgBALgDIAEANQgRAFgNAAQgLAhgUAogAATgiIAGgNIAsAPIgGAPQgcgNgQgEg");
	this.shape_29.setTransform(-273.6,28.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AhDA8QAtgDAVgLIgegGIgEAEIgMgHIASgTIguAAIAAgLIA3AAIAKgOIgjAAIAAAFIgLAAIAAgsIAiAAIAAgPIgwAAIAAgLICNAAIAAALIgxAAIAAAPIAjAAIAAAsIgMAAIAAgFIgxAAIAGAEQADACgFABIgFAHIBRAAIAAALIgiAAQgIANgMALQAWAFAYAMIgIAMQgUgKgcgKQgVARg4AEgAgXAfQAOABATAFQAKgIAGgLIgnAAgAAWgRIAXAAIAAgTIgXAAgAgLgRIAWAAIAAgTIgWAAgAgtgRIAXAAIAAgTIgXAAgAgLguIAWAAIAAgPIgWAAg");
	this.shape_30.setTransform(-289.8,29.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AhMA7QAVgIAUgQIAAhLIAOAAQAGABgGAEIAAA8QAlglATgzIAPAHQgcA/grAmIAAAHQAAAFAEAAIAoAAQAFAAACgGIAEgUIAQAEIgGAVQgDAQgMAAIgzAAQgNAAAAgLIAAgGQgQALgRAIgAAlgGIAOgIQASAXAIAYIgQAIQgKgbgOgUgAhLAjQALgYADgkIAPAFQAFACgGADQgEAigIAWgAgbg8IAIgNQAVAKAOAOIgKANQgNgOgUgKg");
	this.shape_31.setTransform(-306.6,29);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgQARQgGgHAAgKQAAgJAGgGQAHgHAJAAQAKAAAHAHQAGAGAAAJQAAAKgGAHQgHAGgKAAQgJAAgHgGgAgKgKQgEAFAAAFQAAAGAEAFQAFAEAFAAQAGAAAFgEQAEgFAAgGQAAgFgEgFQgFgEgGAAQgFAAgFAEg");
	this.shape_32.setTransform(2,16.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgVA8QAagGAPgPQANgNAAgRQAAgLgHgGQgGgGgJAAQgRACgjALIgHgRQAYgEAWgGQALgCAGAAQAPAAAJAJQALALAAASQgBAagRASQgQAQgbAIgAgeg6IADgRQAlAJAaACIgDAQQgagCglgIg");
	this.shape_33.setTransform(-8.2,11.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgsA0QgGgHAAgJQAAgIAGgHQAIgHAOgBQAHAAAHACIgDhHIALAAQAIABgGAEIABAbQAXgBARgDIAAALQgUAEgUgBIABAfQAdAIASAKIgGAMQgXgMgSgGQgBANgGAHQgIAIgPAAQgMAAgGgFgAgkAdQgDADAAAEQAAAKAPAAQAIAAAEgEQAEgEAAgLQgIgCgGAAQgKAAgEAEg");
	this.shape_34.setTransform(-19.9,12.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgrA3QgJgIAAgZIAAhYIAOAAQAGABgFAEIAABTQAAARAGAGQAIAHAOAAQAZAAAbgdIAKAMQgdAgggAAQgYAAgLgMg");
	this.shape_35.setTransform(-32.2,11.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgtBAQgHgGAAgKQABgKAGgGQAJgJASAAIARABIAAgVIgzABIAAgMIAzgBIAAgXIg/ACIAAgOIA/gCIAAgaIALAAQAGACgGAEIAAATIA3gCIAAANIg3ACIAAAYIAsgBIAAAMIgsABIAAAYQAcAGAaANIgIAPQgYgQgWgFQAAARgIAJQgHAIgSAAQgOAAgIgJgAgjAoQgEAEAAAFQAAAEAEADQAEAFAKAAQAIAAAGgFQAGgGgCgOIgOgBQgNAAgFAFg");
	this.shape_36.setTransform(-46.9,10.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAFA7QAVgTAGgdQgXgIgXgDQgSAmgGAGQgIAIgKAAQgIAAgGgGQgGgGAAgLQAAgOAOgOQAOgNAZAAIAOgnIglAJIgGgNQAWgDAUgFIAIgDIAKAJQAHAEgHACQgIAPgKAYQAUADAYAIQACgQgBgXIANACQAHACgGAEIgBAjQAMAEARAJIgHANIgZgNQgHAegTAVgAg0AJQgLAKAAAKQAAAEADACQACACAEAAQAGAAAEgHQAEgGAMgYQgPAAgJAJg");
	this.shape_37.setTransform(-62.9,11.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgHAtQgQgPAAgWQAAgeAYgSIg/AJIgEgPQBBgEBBgMIADAPQgYAAgNAFQgOAFgNANQgMANAAATQAAAQAJAKQAOANAlABIgFAPQgngCgOgQg");
	this.shape_38.setTransform(-79.1,11.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAPA5QAWgHAJgJQAKgKAAgQQAAgSgKgKQgNgNgTgBQgIAbgOAdIANAPIgLAIIgJgLQgFAJgGAFQgJAJgIAAQgJAAgJgIQgIgIAAgRQAAgXAagaQgFgUgCgRIANAAQAGABgFADQACAPACAKQARgKARgDQADgKACgUIAOAEQAGACgGACIgFAWQAZABAOAPQAPAOAAAYQAAAXgNANQgMAMgVAHgAg4AhQAAAKAFAEQAEAEAEAAQADAAAFgFQAEgEAHgMQgIgNgHgUQgRASAAASgAgcgNQAGAWAGAJQAMgVAEgXQgPADgNAKg");
	this.shape_39.setTransform(-95.2,10.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgWBLIgCgPIANAAQABAAABAAQAAgBABAAQAAAAAAgBQABAAAAgBIAAgnQgSAQgjAXQAAABAAAAQAAABAAAAQAAABgBAAQAAAAgBAAIgMgQQApgWAagWIAAgfIhCAAIAAgNIBCAAIAAgeIALAAQAFABgFADIAAAaIAjAAQgIgIgNgGIALgLQAMAEALALIgLAKIAcAAIAAANIhBAAIAAAFQADALAMAQQAOgJANgPIAMALQABADgEgBQgJAJgTAMQAPAUAhAOIgJARQgpgUgVgpIAAA/QAAALgJAAgAg7gJIALgLQAMAHAMANIgNAMQgLgMgLgJg");
	this.shape_40.setTransform(-111.9,11);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgIBMQgWAAgIgJQgHgHAAgKQAAgLAJgIQANgOAZgKQgBgHgBgCQgDgDgJAAQgNAAgbAWIgLgKQAfgTALgXIglACIgDgNIAtgBQAEgJAEgSIAMADQAHADgHADIgFARIAtgGIACAOIgzAEQgHAOgGAHQAIgCAHAAQAIAAAFAFQAEAEABAJIAtgNIAEAOQgaAFgWAIIAAAdIgNAAIAAgYQgTAKgGAFQgIAIAAAHQAAAEAEAEQAFAFANAAIA3AAIAAANg");
	this.shape_41.setTransform(-127.8,11);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgYA8IAAgNIAkAAIAAhpIANAAIAAB2g");
	this.shape_42.setTransform(-139.7,12.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgGBMIAAgiIhEAAIAAgMIBEAAIAAgPIgUACQAAAEgDgCIgCgOIAJAAIAMgLQgHgIgNgJIAIgJIAEAEIANgRIAIAHQADADgFgBIgKAOIAIAHIARgUIAIAIQADADgFAAIgdAdIAZgEIgHgHIAKgGQAJAJAIAPIgMAHIgDgIIgRACIAAARIBFAAIAAAMIhFAAIAAAigAg8AYIgJgLQAQgKAMgLIAJAIQgLALgNALQAAABgBAAQAAABAAAAQAAAAgBABQAAAAAAAAIgCgBgAAkAAIAJgJQAPAHANAKIgKAMQgNgLgOgJgAAdgWQANgKAGgJIAMAIQACADgEAAQgIAJgLAJgAhAgdIAJgKQAMAGAJAJIgJALQgJgJgMgHgAhCgvIAAgMIA8AAIAAgQIAMAAQAGACgGAEIAAAKIA9AAIAAAMg");
	this.shape_43.setTransform(-152,10.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AhHBKIAAgNIAZAAIAAgwQgKAJgNAGIgGgNQAkgPAIgeIgnAAIAAgNIAsAAQgCgIgKgMIAMgHQAKAMAEAPIAVAAQAHgMAGgSIAPAGQADADgFABQgHAPgFAFIAvAAIAAANIgpAAQAOAfAhAMIgIAOQgSgJgEgGIAAAxIAaAAIAAANgAATA9IAQAAIAAgpIgQAAgAgHA9IAOAAIAAgpIgOAAgAgiA9IAQAAIAAgpIgQAAgAgnAHIBPAAQgSgSgGgTIggAAQgHAZgQAMg");
	this.shape_44.setTransform(-168.9,10.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AghBIIAAhAQgLAUgSAPIgIgOQAagUAKgcIggAAIAAgNIAhAAIAAgVIgbABIgEgLQAlgDAcgFIAHALQAAAEgEgCIgXADIAAAXIAjAAIAAANIgjAAIAAAOQATAJANANIgKANQgJgLgNgKIAAA/gAArBHIgCgNIANAAQABAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAgBIAAh+IANAAQAFABgFAEIAAB+QAAAKgKAAgAAWAnIAAhcIANAAQAFABgFADIAABYg");
	this.shape_45.setTransform(-186.2,11.2);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AguBNIAAhHIgXAEQgBAFgDgDIgCgOIANAAIAMgOQgKgMgNgKIAHgKIAGAFIAWghIAKAGQADADgEgBIgXAgIAKAJIATgaIAKAFQADADgEAAIgiAqIAagCIgGgMIAIgEQAIAMAFAOIgJAFIgDgHIgOACIAABIgAAlBHQgLAAAAgOIAAgcIgPAAIAAAPIgMAAIAAhFIAMAAQAFABgFADIAAAoIAPAAIAAg5IghAFIgDgMIAkgFIAAgZIAKAAQAIAAgHAEIAAATIAfgGIAGANQACAEgHgEIggAFIAAA7IARAAIAAgyIANAAQAFABgEADIAAA4IgfAAIAAAbQAAADAEAAIAPAAQAHAAABgOIAMAEQgCAVgOABgAhLA5QAIgTABgSIAOADQACADgEABQgCASgHAUgAgYAXIAMgCQAFAMAAASIgMADQgBgTgEgMg");
	this.shape_46.setTransform(-202.9,11);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgGBAQAcgRAAgeIAAhWIAyAAIAACFQAAAKgLAAIgOAAIgBgPIAKAAQABAAAAAAQABAAAAAAQAAgBAAAAQABgBAAgBIAAgkIgYAAQgBAjggAVgAAjAHIAYAAIAAgYIgYAAgAAjgeIAYAAIAAgaIgYAAgAhFA+QAPgNALgSIAMAHQAFAEgIAAQgKARgOAOgAgWAoIAKgJQAMAJAGAHIgJALQgJgKgKgIgAhHAcIAAgLIAVAAIAAg7IgRAAIAAgKIARAAIAAgXIALAAQAGABgFADIAAATIAaAAIAAgXIALAAQAFABgFADIAAATIAQAAIAAAKIgQAAIAAA7IASAAIAAALgAgmARIAaAAIAAgOIgaAAgAgmgHIAaAAIAAgMIgaAAgAgmgeIAaAAIAAgMIgaAAg");
	this.shape_47.setTransform(-220.3,11.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAxBHIAAgIIhvAAIAAgMIBvAAIAAgXIhnAAIAAgMIBnAAIAAgUIhvAAIAAgNIA3AAIAAg1IAOAAQAGABgGAEIAAAwIA3AAIAABYgAAYgdQAKgPAHgUIAPAHQAEADgGAAQgFAPgMASgAg3g0IANgJQAKALAJARIgOAJQgJgSgJgKg");
	this.shape_48.setTransform(-237,11);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgYA8IAAh2IAxAAIAAAMIgkAAIAABqg");
	this.shape_49.setTransform(-249.4,9.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgWgHIAKgNQAVAMAOAPIgMAOQgPgSgSgKg");
	this.shape_50.setTransform(-261.4,16.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AhCAGQAAgdAIgpIANADQAHACgGAEQgHAnAAAWQAAAaADAgIgQABQgCgjAAgYgAAeA0QgeAAgUgTIAIgLQARAQAZAAIAlAAIAAAOgAgPgqQAvgEAaAAIAAAOQgcgBgtAFg");
	this.shape_51.setTransform(-273,11.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AglA/QAggEARgMQgHgJgFgLQgJANgQALIgIgLQAagQAHgXIgZACQAAAEgDgDIgFgOIAbgBIAMgKQgPgKgMgHIAHgLIAHADQAKgNAJgRIALAHQAGADgHABQgIAMgMAOIAMAIQAMgLANgSIAMAHQACADgEABQgNARgaAVIAogCIgLgLIAKgIQAPALAKASIgLAIIgGgIIgrADIgFALIAhAAIACgDIALAGQAFACgHADQgKARgLALQARAKAaAEIgFAPQgbgFgVgPQgUAOgiAHgAAWAnQAHgHAHgKIgaAAQAEAJAIAIgAg3BNIAAhFIgNANIgGgNQAVgQAOgcIAMAIQADADgFABIgMATIAABSgAhIgoQAUgNAPgTIAMAKQAAABAAAAQAAABgBAAQgBAAAAABQgBAAgBAAQgMARgXAPg");
	this.shape_52.setTransform(-289.8,10.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgFA9QARgFAMgKQgMgOgGgRIgJAAIAAgNIA4AAIABgCIALAJQABAAgBABQAAAAAAABQAAAAgBAAQgBABgBAAQgHATgMAOQAKAIAYAGIgEAOQgTgEgUgPQgQAPgRAFgAAiAlQAGgGAIgQIgeAAQAJARAHAFgAgUBKIAAgRIguAHQgBACgBAAQgBABAAAAQgBABAAgBQAAAAAAgBIgEgPIASgCIAAg4IgUAAIAAgKICXAAIAAAKIhUAAIAABRgAgsAxIAYgCIAAgLIgYAAgAgsAZIAYAAIAAgLIgYAAgAgsADIAYAAIAAgKIgYAAgAgzgZIAAgwIBlAAIAAAwgAgmgjIBKAAIAAgJIhKAAgAgmg3IBKAAIAAgIIhKAAg");
	this.shape_53.setTransform(-306.8,11.2);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgfBDQAhgUgBgVQgGAFgJAAQgLAAgGgGQgIgIAAgKQAAgKAIgIQAIgIAMAAQAHAAAHACIAAgOIhIAEIgCgOIBKgDIAAgfIAMAAQAIABgGAEIAAAaIA3gEIAAANIg3ADIAAAZQACALAAAPQAAAiglAXgAgWgDQgEADAAAHQAAAGADADQAEAEAHAAQAIAAAEgFQADgEAAgGQAAgFgDgEQgDgDgHAAQgHAAgFAEg");
	this.shape_54.setTransform(-153,11);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgKAtQgPgPAAgWQgBgeAZgSIg/AJIgFgPQBCgEBBgMIACAPQgXAAgNAFQgPAFgNANQgMANAAATQAAAQALAKQAMANAlABIgEAPQgogCgOgQgAAYgLIAGgIIAaAQIgHAHIgZgPgAAlgbIAHgIIAaAQIgHAIIgagQg");
	this.shape_55.setTransform(-168.4,11.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AglBJIAAg2IgdAkIgMgKIAbgfQAHgKAHgJIAAgQIgdAKIgFgOIAigIIAAgnIALAAQAHABgFAEIAAAeIAHAEQAGACgHAEIgGAMIAAAFQAegdAQAAQAUAAgCAaIgEAzQAAAKAIAAQAJAAAEgFQAGgHAEgKIAMAKQgIAMgGAGQgIAJgLAAQgZAAACgZIADgyQAAgNgIAAQgLAAgfAgIAABCg");
	this.shape_56.setTransform(-184.9,10.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgRA4QgVAAgIgIQgIgIAAgNQAAgIADgKIAPADQgDAKAAAFQAAAGAEAEQAEAEAOABIBIAAIAAAOgAgsgoIAAgPIBVAAIAAAPg");
	this.shape_57.setTransform(-200.1,11.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgVA9QgGgHAAgKQAAgJAFgGQAIgIAPAAQAIAAAJACQABgWgBgXIgwAEIAAgOIAvgDQgBgSgCgPIAOAAQAHABgFAEIABAbIAjgCIAAAOIgiACQACAYgCAZQAUAIASANIgHAMQgOgKgRgIQAAAMgHAHQgIAIgPAAQgOAAgJgIgAgMAlQgCAEAAADQgBAFADADQAFAEAIAAQAKAAADgEQAFgGgBgJQgLgEgGAAQgIAAgFAEgAhFAXQAAg1AHghIAPADQAEACgFADQgHAXAAA3QAAAZADAPIgPADQgDgTABgYg");
	this.shape_58.setTransform(-226.2,10.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgGA+QASgEAMgJIAJALQADAEgHgBQgMAHgRAGgAAqA6IAJgKQAOAKAPAFIgHAMQgPgFgQgMgAg/BJIAAgvIgLAFIgFgMQAYgJANgKIgLgMQgIAIgKAGIgGgKQAXgNAGgWIALABQAFABgFAEIgEAGIAXAAIACgCIAKAJQABACgEAAQgGAKgLALQAKAHAVAHIgFAOQgXgNgKgIQgLAKgMAFIAsAAIAAAxIgLAAIAAgEIgcAAIAAAHgAgzA3IAcAAIAAgXIgcAAgAgvgSIAMALQAGgFAGgLIgVAAgAAHAuIAAhYIAUAAIAFgQIgbAAIAAgMIBEAAIAAAMIgcAAIgHAQIAeAAIAABYgAATAkIAmAAIAAgQIgmAAgAATAKIAmAAIAAgPIgmAAgAATgQIAmAAIAAgPIgmAAgAhHgeIAAgcIAdAAIAAgRIANAAQAFABgFADIAAANIAdAAIAAAYIgMAAIAAgNIgwAAIAAARg");
	this.shape_59.setTransform(-243.6,11.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AhBBJIAAgNIA7AAIAAgrIg3AAIAAgMIA3AAIAAgQIgZAAIAAgKQgQAMgWAIIgGgPQAygQATgoIAPACQABAAABAAQAAABAAAAQAAABAAAAQgBABgBABQAWAgAuAOIgHAPQgUgGgQgMIAAAMIgbAAIAAAQIA4AAIAAAMIg4AAIAAArIA+AAIAAANgAgbgZIA7AAQgQgIgQgYQgMAWgPAKgAgtAfIANgGQAIAKAFAPIgNAHQgGgPgHgLgAAVAzQAGgMAFgRIANAEQAIACgHADQgFAMgGAMg");
	this.shape_60.setTransform(-260.8,10.6);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("Ag+ApQgFgLAAgkQAAgbACgbIAPADQAHACgHAFQgCAZAAAUQgBAaAEALQADALAHAAQAHAAAGgKQADgHADgJIAOAJQgHAPgGAIQgKAMgJAAQgQAAgIgUgAASgrIANgIQAeAgAHArIgSAFQgIgugYgag");
	this.shape_61.setTransform(-277.1,11.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AhGA/IAAgNIAYAAIAAhJIAPAAQAFABgFADIAABFIAcAAIAAhjIg/AAIAAgNICFAAIAAANIg3AAIAAApIArAAIAAALIgrAAIAAAvIA7AAIAAANg");
	this.shape_62.setTransform(-306.9,11.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("Ag5BMIgCgMIAKAAQAAAAABgBQAAAAABAAQAAgBAAAAQAAgBAAgBIAAgpIgQAFQgDAGgBgEIgEgOIAYgHIAAglIgXAAIAAgNIAXAAIAAgeIANAAQAFAAgEAEIAAAaIARAAIAAANIgRAAIAAAhIAQgFIACALIgSAHIAAA0QAAAKgLAAgAAXBLIAAgzIgWAAIAAANIgMAAIAAhnIBTAAIAABjIgNAAIAAgJIgWAAIAAAzgAAlAMIAWAAIAAgaIgWAAgAABAMIAWAAIAAgaIgWAAgAAlgaIAWAAIAAgbIgWAAgAABgaIAWAAIAAgbIgWAAg");
	this.shape_63.setTransform(-147.6,10.9);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("Ag+BBQAggDAEgPIgxAAIAAgKIAyAAIAAgKIgLAAIgLAAIAAg+IAzAAIgKgHQAMgNAHgXIANAGQAFACgHACIgCAFIAzAAIAAALIgfAAIAGAKIgOADIgFgNIgNAAIgLARIArAAIAAA+IgSAAIAAAKIAuAAIAAAKIguAAIAAAcIgOAAIAAgcIgdAAQgCAYgrAHgAgMAlIAcAAIAAgKIgcAAgAgkAQIBJAAIAAgJIhJAAgAgkAAIBJAAIAAgIIhJAAgAgkgQIBJAAIAAgJIhJAAgAhJgmQATgQAHgXIANAGQAFACgHABIgCAFIAmAAIAAALIgUAAIAFAKIgOACIgEgMIgKAAQgJAPgLAKg");
	this.shape_64.setTransform(-231.3,11);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgeBDQAfgUABgVQgHAFgJAAQgLAAgGgGQgIgIAAgKQAAgKAIgIQAIgIALAAQAJAAAGACIAAgOIhIAEIgDgOIBLgDIAAgfIAMAAQAIABgHAEIAAAaIA4gEIAAANIg4ADIAAAZQADALAAAPQAAAiglAXgAgWgDQgEADAAAHQAAAGAEADQADAEAHAAQAHAAAFgFQADgEAAgGQAAgFgDgEQgDgDgHAAQgHAAgFAEg");
	this.shape_65.setTransform(-257.9,29);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgKAtQgQgPAAgWQAAgeAZgSIhAAJIgDgPQBAgEBBgMIADAPQgYAAgNAFQgOAFgNANQgLANAAATQgBAQAKAKQANANAmABIgGAPQgngCgOgQgAAYgLIAHgIIAZAQIgGAHIgagPgAAlgbIAHgIIAZAQIgHAIIgZgQg");
	this.shape_66.setTransform(-273.3,29.4);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgiA6QAkgMAJgYQAIgRgBg0IgZAAIAAgPIBPAAQAAAygDA9QgCAWgTAAIgSAAIgBgPIAQAAQAJAAAAgNQAEg1AAglIgZAAQgBA9gIASQgPAcgkANgAgoAnQgMAAAAgLIAAgpIgRAEIgDgPIAUgEIAAgsIANAAQAHACgGAEIAAAkIAjgJIADAOIgmAJIAAAlQAAAFAEAAIAMAAQALAAACgUIALAFQgDAcgRAAg");
	this.shape_67.setTransform(-290.2,29.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AhKA6QA9gVADg8Ig7AAIAAgOIA9AAIAAgkIAOAAQAGACgGAEIAAAeIBAAAIAAAOIg/AAQAOA2A2AYIgIAQQgvgWgTgxQgLA1g6AVg");
	this.shape_68.setTransform(-306.7,29);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AhMBEQATgeAOgvIgcADIgBgOIAhgCQAGgVAEgVIAOAFQAIADgJADIgIAdIARgBQAIAAAFAFQAIAIAAAbQAAAmgMALQgFAHgJAAQgNAAgMgPIAIgLQALAKAFAAQAEAAACgDQAHgHAAghQAAgSgDgEQgCgCgGAAIgRACQgOAwgTAjgAAVgdIAMgIQAcAbAKAnIgPAGQgMgrgXgVgAAdgxIAIgIQAMAHAPAMIgJAIQgPgMgLgHgAArhAIAIgIQAMAHAOAMIgIAIQgOgMgMgHg");
	this.shape_69.setTransform(301.1,10.3);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgOBFQgWAAgIgJQgJgIAAgLQAAgPALgLQAIgIASgJQgEgKAAgMIgDgsIAOAAQAHABgGAEIACAgQAAAOAEAJQASgIAfgJIAHARQg+ALgWAVQgHAHAAAIQAAAGAFAFQAEAEAPAAIA/AAIAAAPg");
	this.shape_70.setTransform(286,10.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("Ag/ApQgEgLAAgkQAAgbACgbIAPADQAHACgHAFQgCAZAAAUQAAAaADALQADALAHAAQAHAAAFgKQAEgHADgJIAOAJQgHAPgGAIQgKAMgJAAQgRAAgIgUgAARgrIAOgIQAeAgAHArIgSAFQgIgugZgag");
	this.shape_71.setTransform(257.9,11.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgXBDQgGgGAAgLQAAgJAGgGQAJgJAQAAQALAAAHACIAAgnIALAAQAIABgGAEIAAAmQAQAEASAKIgIANQgOgJgMgEQgCAOgGAGQgJAIgOAAQgRABgIgIgAgMAqQgDADAAAFQAAAEACADQAFAEAJAAQAJAAAEgEQAGgGAAgKQgIgDgKAAQgKAAgEAEgAhEAlQAVglAIgbQgKABgQAAIgCgOIAigCIAIgfIALADQAHADgHADIgFAVQAKgBALgDIAEANQgRAFgNAAQgKAhgVAogAATgiIAGgNIAsAPIgGAPQgcgNgQgEg");
	this.shape_72.setTransform(242,10.9);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgTBHIgGgPIARAAQAfAAAJgIQAHgIAAgJQAAgIgGgHQgGgGgOAAQgcAAgZAdIgMgBIAHhGIANACQAIADgIADIgEAqQAYgTAcAAQASAAALAJQAIAJABAOQAAAPgMAMQgNANgkAAgAgng6IAGgMQATAFAfALIgHAOQgWgKgbgIg");
	this.shape_73.setTransform(227.6,10.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgXBDQgGgGAAgLQAAgJAGgGQAKgJAPAAQALAAAHACIAAgnIAMAAQAHABgGAEIAAAmQAQAEATAKIgIANQgPgJgMgEQgCAOgGAGQgJAIgOAAQgRABgIgIgAgLAqQgEADAAAFQAAAEADADQADAEAJAAQAKAAAEgEQAGgGAAgKQgIgDgKAAQgKAAgDAEgAhEAlQAUglAKgbQgLABgQAAIgCgOIAhgCIAIgfIAMADQAHADgHADIgFAVQAKgBALgDIAEANQgRAFgNAAQgKAhgVAogAATgiIAGgNIAsAPIgGAPQgcgNgQgEg");
	this.shape_74.setTransform(212.9,10.9);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AhFAwQBGgtAUgtIhIAEIgCgPIBNgEIAIgCIAKALQAFAEgHACQgNAWgOASQAcAVAdAdIgOALQgcgdgagUQgYAcghAWg");
	this.shape_75.setTransform(181.5,11.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AguA8QAqgWAAgpIAAgMIhCAAIAAgPIBBAAIAAgnIAMAAQAIAAgGAFIAAAiIA+AAIAAAPIg9AAIAAAMQAAAwgpAZg");
	this.shape_76.setTransform(165.9,11.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAGBGIAAhMQgWAQgfAPIgMgNQBFgcAkg2IAMAMQAGADgKACQgNARgUARIAABZg");
	this.shape_77.setTransform(150.9,11.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgkABIAKgLQAMAIAOAMQAUgSAUgeIhoAEIgCgQIBzgDIAHgCIAKALQADAFgGAAQgQAVgjAmQAOANAIAKIgMAMQgZgeghgYg");
	this.shape_78.setTransform(136.3,11.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgKAtQgQgPAAgWQABgeAYgSIg/AJIgFgPQBBgEBCgMIACAPQgYAAgNAFQgOAFgNANQgLANAAATQAAAQAKAKQAMANAlABIgEAPQgogCgOgQgAAYgLIAGgIIAaAQIgGAHIgagPgAAlgbIAHgIIAaAQIgIAIIgZgQg");
	this.shape_79.setTransform(109.9,11.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AhLA6QAHgCAPgKIAAgrIgVAAIAAgLIAjAAIAAA2QANAMAVAAIBSAAIgEAOIhRAAQgUAAgSgQQgHAKgRAJgAgYA0IAAhVIAwAAIghgNIAJgKIAWAGIAMgJIg8AAIAAgNIBLAAIADgCIAKAIQAFADgIABIgaARIAJAEIgIAIIAeAAIAABLQAAAJgKAAIgOAAIgBgNIAJAAQABAAAAAAQABAAAAAAQAAgBAAAAQABgBAAAAIAAgNIgaAAIAAAaIgNAAIAAgaIgXAAIAAAdgAAZAMIAaAAIAAgMIgaAAgAgLAMIAXAAIAAgMIgXAAgAAZgKIAaAAIAAgMIgaAAgAgLgKIAXAAIAAgMIgXAAgAhCg+IAJgLQASALAHALIgMAMQgKgNgMgKg");
	this.shape_80.setTransform(93.4,11.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AguBNIAAhGIBcAAIAABDIgMAAIAAgDIhEAAIAAAGgAgiA5IBEAAIAAgMIhEAAgAgiAgIBEAAIAAgMIhEAAgAhLAAIAAgNIA4AAIAAggIguAAIAAgNIAkAAIgJgLIAPgFIALAQIAXAAIAKgSIAPAFQADACgFABIgHAKIAnAAIAAANIgtAAIAAAgIA3AAIAAANgAgGgNIAOAAIAAggIgOAAgAAbgWQAGgKAFgLIAOAFQACADgEABQgEAIgHAKgAg0gjIAMgHQAIAHAEAKIgOAHQgEgLgGgGg");
	this.shape_81.setTransform(76.5,11);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AhMBEQATgeAOgvIgcADIgBgOIAhgCQAGgVAEgVIAOAFQAIADgJADIgIAdIARgBQAIAAAFAFQAIAIAAAbQAAAmgMALQgFAHgJAAQgNAAgMgPIAIgLQALAKAFAAQAEAAACgDQAHgHAAghQAAgSgDgEQgCgCgGAAIgRACQgOAwgTAjgAAVgdIAMgIQAcAbAKAnIgPAGQgMgrgXgVgAAdgxIAIgIQAMAHAPAMIgJAIQgPgMgLgHgAArhAIAIgIQAMAHAOAMIgIAIQgOgMgMgHg");
	this.shape_82.setTransform(59.8,10.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAFAxQAXgHANgNQAMgMAAgSQAAgVgNgOQgPgNgdAAIALAHQAJADgJAEQgJBCgRAPQgIAJgKAAQgKAAgGgGQgQgQAAgYQAAgcAUgVQAXgWAfAAQAeAAAQAQQATATAAAZQAAAbgRAQQgMAMgWALgAglgfQgRARAAAZQAAAPAKAKQACACAEAAQAEgBAFgEQAPgPAIhCQgSAEgNANg");
	this.shape_83.setTransform(42.3,11.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgWA+QgIgJAAgMQAAgIAFgGQAHgGAIAAQAMAAAHAIQAKAJADAUQALgBAHgIQAIgIAAgNQAAgPgIgIQgJgIgTAAQgUAAgMAIQgMAIgSAUIgLgKQAvguAYggIgqAEIgFgPQAgAAAYgDIAGgDIAIAHQAHAHgKACIgoAtQAOgEAJAAQAZAAAMAMQAMALAAATQAAATgKALQgQAQgZAAQgXAAgKgLgAgQAjQgDADAAAEQAAAGAGAFQAGAHAKAAIAGAAQgCgRgGgGQgEgFgFAAQgEAAgEADg");
	this.shape_84.setTransform(26.4,11);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgWBDQgHgGAAgLQAAgJAHgGQAIgJAQAAQALAAAHACIAAgnIAMAAQAHABgGAEIAAAmQAQAEATAKIgIANQgPgJgMgEQgCAOgHAGQgIAIgNAAQgSABgHgIgAgLAqQgEADAAAFQAAAEADADQAEAEAIAAQAKAAAEgEQAGgGAAgKQgIgDgKAAQgKAAgDAEgAhEAlQAVglAJgbQgLABgQAAIgCgOIAhgCIAIgfIANADQAGADgGADIgHAVQAMgBALgDIADANQgSAFgLAAQgMAhgUAogAATgiIAFgNIAtAPIgGAPQgcgNgQgEg");
	this.shape_85.setTransform(11.5,10.9);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgdARQgKgJABgGQgBgHAIgGQAqgpANgUIALAJQAHAHgKgCQgKAPgqAoQgCACAAABQAAAEACACQAlAeAXAZIgNAMQgXgbghgdg");
	this.shape_86.setTransform(-1.1,10.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgTBFIgFgPIAOAAQABAAABAAQAAAAAAAAQABAAAAgBQAAAAAAgBIAAh4IAOAAQAHABgHAEIAAB8QAAAIgHAAgAhKAhQAYgiAFgoIAQAEQAFACgFACQgJAngVAlgAAagiIANgHQAXAgANAjIgQAHQgNgkgUgfg");
	this.shape_87.setTransform(-27.6,11.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgOBFQgWAAgIgJQgJgIAAgLQAAgPALgLQAIgIASgJQgEgKAAgMIgDgsIAOAAQAHABgGAEIACAgQAAAOAEAJQASgIAfgJIAHARQg+ALgWAVQgHAHAAAIQAAAGAFAFQAEAEAPAAIA/AAIAAAPg");
	this.shape_88.setTransform(-53.7,10.7);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgtA/QAegDATgKQgJgKgJgMIgTAAIAAgLIBNAAIACgCIAKAIQACAEgFgBQgLAOgQALQAXAIAaACIgDAPQgggEgYgNQgXAOggAEgAAQArQAHgFALgKIgiAAQAGAIAKAHgAhKBAQAPgVABgiIAAhDIA3AAIAAgSIAOAAQAFABgFADIAAAOIA8AAIAAAMIh1AAIAAA6QAAAlgQAZgAgPAIIAAgZIgbAAIAAgLIAbAAIAAgNIANAAQAEABgDADIAAAJIAbAAIAAgOIAMAAQAGABgEADIAAAKIAfAAIAAALIgfAAIAAAZIgOAAIAAgEIgbAAIAAAEgAgBgGIAbAAIAAgLIgbAAg");
	this.shape_89.setTransform(-69.1,11);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AguBLIAAg/QgKATgMAKIgIgNQAWgWAIgbIgYAAIAAgMIAYAAIAAgTIgVAEIgDgOQAfgFATgHIAJAMQACAFgGgDIgSAGIAAAVIAYAAIAAAMIgYAAIAAAOQALAHAOAOIgKAMIgPgRIAABCgAgQBHIAAgNIArAAIAAgSIgeAAIAAgMIAeAAIAAgSIggAAIAAgLIBOAAIAAALIghAAIAAASIAbAAIAAAMIgbAAIAAASIAlAAIAAANgAAAgLIAAg3IBEAAIAAA3IgNAAIAAgGIgqAAIAAAGgAANgeIAqAAIAAgYIgqAAg");
	this.shape_90.setTransform(-86.2,11);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AAWAyQgIgIAAgUQAAgUAIgHQAIgIANAAQAOAAAHAIQAIAHAAAUQAAAVgIAIQgHAIgOAAQgMAAgJgJgAAiAEQgEAEAAAOQAAAPAEAEQAEAEAFAAQAGAAAEgEQAEgEAAgPQAAgOgEgEQgEgEgGAAQgFAAgEAEgAguA0IBXhtIAIAHIhXBtgAg/AFQgIgHAAgUQAAgUAIgIQAIgIANAAQANAAAIAIQAIAIAAAUQAAAVgIAHQgIAIgNAAQgNAAgIgJgAgzgpQgEAEAAAPQAAAPAEAEQAEADAFAAQAFAAAEgDQAEgEAAgPQAAgPgEgEQgEgEgFAAQgFAAgEAEg");
	this.shape_91.setTransform(-102.9,11.2);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgfAvQgKgKgCgTIAQAAQACANAGAHQAIAHAPAAQAMAAAHgGQAGgGAAgIQAAgLgGgFQgGgHgWACIAAgNQAVgCAGgGQAFgEAAgHQAAgGgFgGQgFgFgNAAQgNAAgIAIQgFAFgBAJIgSAAQACgOAKgKQAMgLAVAAQAUAAAJAJQAJAJAAAMQAAAKgIAJQgEAEgHACQAIACAFADQAJAJgBAOQAAAOgKAJQgKALgUAAQgYAAgLgMg");
	this.shape_92.setTransform(-117.4,11.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgUBHIgEgPIAQAAQAfAAAJgIQAHgIAAgJQAAgIgGgHQgGgGgOAAQgdAAgYAdIgMgBIAHhGIANACQAIADgIADIgEAqQAYgTAcAAQASAAALAJQAIAJABAOQAAAPgMAMQgNANgkAAgAgng6IAGgMQATAFAfALIgHAOQgWgKgbgIg");
	this.shape_93.setTransform(-129.8,10.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AhJBAQATgeAOgvIgcADIgBgOIAhgCQAGgVAEgVIAOAFQAIADgJADIgIAdIARgBQAIAAAFAFQAIAIAAAbQAAAmgMALQgFAHgJAAQgNAAgMgPIAJgLQAKAKAFAAQAEAAACgDQAHgHAAghQAAgSgDgEQgCgCgGAAIgQACQgOAwgUAjgAAYghIANgIQAbAbAKAnIgPAGQgMgrgXgVg");
	this.shape_94.setTransform(-145.2,10.7);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AAWAyQgIgIAAgUQAAgUAIgHQAIgIANAAQAOAAAHAIQAIAHAAAUQAAAVgIAIQgHAIgOAAQgMAAgJgJgAAiAEQgEAEAAAOQAAAPAEAEQAEAEAFAAQAGAAAEgEQAEgEAAgPQAAgOgEgEQgEgEgGAAQgFAAgEAEgAguA0IBXhtIAIAHIhXBtgAg/AFQgIgHAAgUQAAgUAIgIQAIgIANAAQANAAAIAIQAIAIAAAUQAAAVgIAHQgIAIgNAAQgNAAgIgJgAgzgpQgEAEAAAPQAAAPAEAEQAEADAFAAQAFAAAEgDQAEgEAAgPQAAgPgEgEQgEgEgFAAQgFAAgEAEg");
	this.shape_95.setTransform(-162.2,11.2);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AACA5IAAhXIgSAAIAAgIIAFAAQAJAAAFgFQAGgGABgIIAIAAIAAByg");
	this.shape_96.setTransform(-175.7,11.1);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgVA9QgGgHAAgKQAAgJAFgGQAIgIAPAAQAJAAAIACQABgWgBgXIgwAEIAAgOIAvgDQAAgSgDgPIAOAAQAIABgGAEIABAbIAkgCIAAAOIgjACQACAYgCAZQAUAIASANIgIAMQgNgKgRgIQAAAMgHAHQgIAIgPAAQgPAAgIgIgAgMAlQgCAEAAADQAAAFACADQAFAEAIAAQAKAAADgEQAFgGgBgJQgLgEgGAAQgJAAgEAEgAhFAXQgBg1AIghIAPADQAFACgGADQgHAXAAA3QAAAZADAPIgPADQgCgTAAgYg");
	this.shape_97.setTransform(-187.3,10.9);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AhHBKIAAgNIAZAAIAAgwQgKAJgNAGIgGgNQAkgPAIgeIgmAAIAAgNIArAAQgCgIgKgMIAMgHQAKAMAEAPIAVAAQAHgMAGgSIAQAGQACADgFABQgHAPgFAFIAuAAIAAANIgoAAQAPAfAgAMIgIAOQgSgJgEgGIAAAxIAaAAIAAANgAATA9IAQAAIAAgpIgQAAgAgHA9IAOAAIAAgpIgOAAgAgiA9IAQAAIAAgpIgQAAgAgnAHIBPAAQgSgSgHgTIgfAAQgHAZgQAMg");
	this.shape_98.setTransform(-230.2,10.6);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgGBAQAcgRAAgeIAAhWIAyAAIAACFQAAAKgKAAIgPAAIgBgPIAKAAQABAAAAAAQABAAAAAAQAAgBAAAAQABgBAAgBIAAgkIgYAAQgBAjggAVgAAjAHIAYAAIAAgYIgYAAgAAjgeIAYAAIAAgaIgYAAgAhFA+QAPgNALgSIALAHQAGAEgIAAQgKARgOAOgAgWAoIAKgJQAMAJAGAHIgJALQgIgKgLgIgAhHAcIAAgLIAVAAIAAg7IgRAAIAAgKIARAAIAAgXIALAAQAGABgFADIAAATIAaAAIAAgXIALAAQAFABgFADIAAATIAQAAIAAAKIgQAAIAAA7IASAAIAAALgAgmARIAaAAIAAgOIgaAAgAgmgHIAaAAIAAgMIgaAAgAgmgeIAaAAIAAgMIgaAAg");
	this.shape_99.setTransform(-281.6,11.1);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AAxBHIAAgIIhvAAIAAgMIBvAAIAAgXIhnAAIAAgMIBnAAIAAgUIhvAAIAAgNIA3AAIAAg1IAOAAQAGABgFAEIAAAwIA2AAIAABYgAAYgdQAKgPAHgUIAPAHQAEADgGAAQgFAPgMASgAg3g0IANgJQAKALAJARIgOAJQgJgSgJgKg");
	this.shape_100.setTransform(-298.3,11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50,p:{x:-261.4}},{t:this.shape_49,p:{x:-249.4}},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46,p:{x:-202.9}},{t:this.shape_45,p:{x:-186.2}},{t:this.shape_44},{t:this.shape_43,p:{x:-152}},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23,p:{x:-175.1,y:29.1}},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17,p:{x:-83.1,y:34.6}},{t:this.shape_16},{t:this.shape_15,p:{x:-58.8,y:28.9}},{t:this.shape_14},{t:this.shape_13,p:{x:-29.4,y:30.8}},{t:this.shape_12},{t:this.shape_11,p:{x:0.4,y:28.5}},{t:this.shape_10,p:{x:14.8,y:28.9}},{t:this.shape_9,p:{x:28.8,y:29.4}},{t:this.shape_8,p:{x:43.3,y:29}},{t:this.shape_7},{t:this.shape_6,p:{x:74.8,y:29.2}},{t:this.shape_5,p:{x:88.4,y:29.4}},{t:this.shape_4,p:{x:101.2,y:28.8}},{t:this.shape_3,p:{x:114.1,y:28.6}},{t:this.shape_2,p:{x:128.3,y:28.9}},{t:this.shape_1,p:{x:143,y:29.2}},{t:this.shape,p:{x:154.8,y:34.2}}]},9).to({state:[]},138).to({state:[{t:this.shape_62},{t:this.shape_6,p:{x:-291.2,y:11.2}},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_17,p:{x:-214.3,y:16.6}},{t:this.shape_57,p:{x:-200.1}},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape,p:{x:-140.7,y:16.2}}]},28).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_23,p:{x:-273,y:11.1}},{t:this.shape_49,p:{x:-260.7}},{t:this.shape_15,p:{x:-248.3,y:10.9}},{t:this.shape_64},{t:this.shape_13,p:{x:-219,y:12.8}},{t:this.shape_11,p:{x:-206.2,y:10.5}},{t:this.shape_10,p:{x:-191.7,y:10.9}},{t:this.shape_9,p:{x:-177.8,y:11.4}},{t:this.shape_8,p:{x:-163.2,y:11}},{t:this.shape_63},{t:this.shape_6,p:{x:-131.8,y:11.2}},{t:this.shape_5,p:{x:-118.2,y:11.4}},{t:this.shape_4,p:{x:-105.4,y:10.8}},{t:this.shape_3,p:{x:-92.4,y:10.6}},{t:this.shape_2,p:{x:-78.2,y:10.9}},{t:this.shape_1,p:{x:-63.6,y:11.2}},{t:this.shape,p:{x:-51.8,y:16.2}}]},54).to({state:[]},50).to({state:[{t:this.shape_49,p:{x:-310.7}},{t:this.shape_100},{t:this.shape_99},{t:this.shape_46,p:{x:-264.2}},{t:this.shape_45,p:{x:-247.5}},{t:this.shape_98},{t:this.shape_43,p:{x:-213.3}},{t:this.shape_13,p:{x:-201,y:12.8}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_50,p:{x:-43.6}},{t:this.shape_87},{t:this.shape_2,p:{x:-12.6,y:10.9}},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_17,p:{x:121.2,y:16.6}},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_23,p:{x:197.6,y:11.1}},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_57,p:{x:272.6}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape,p:{x:-245.6,y:34.2}}]},10).to({state:[]},175).wait(1));

	// BG
	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("rgba(0,0,0,0.647)").s().p("Eg2rADIIAAmPMBtXAAAIAAGPg");
	this.shape_101.setTransform(0,20);

	this.timeline.addTween(cjs.Tween.get(this.shape_101).wait(465));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-350,0,700,40);


(lib.vjvQ操作txt1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AgkBCQgHgDgGgHQgEgFgEgIQgDgGgDgKIgDgPIgBgZIABgaIABgGIABgHIABgHQABgJAJAAQAEAAADADQACADAAAEIAAACIAAAFIgBAEIAAADIgBAIIAAADIAAACIgBACIAAAMIAAANIABALIACAMQABAJAEAHIADAGIAFAFQAGAFAGgDQAEgCAEgFQADgDACgFQADgGAFAAQAEAAADADQADADAAAEIgBAFQgEAIgGAHQgFAHgIADIgFABIgGABQgHAAgGgDgAA4AtQgIgCAAgIIAAgBIAAgBQABgTgDgRQgCgKgEgIQgDgJgFgIIgDgEIgDgEQgEgFAEgHQAEgHAIAEIADACIACACQAHAJAFAKQAFALADALQAGAVgBAXIAAAEIAAADIgBAFQgDAFgGAAIgCAAg");
	this.shape.setTransform(102.1,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0000").s().p("AgFBNIgHAAIgDAAIgEAAIgNgCQgOgEgGgOQgFgMADgMQADgNAKgHIAGgEQAGgBAEADQAEADAAAGQAAAEgFADIgCABQgFADgCAHQgBAJAEAFQADADAFABIAIABIALAAIA1AAQAEAAADADQADADAAAEQAAAEgDADQgDADgEAAIg1AAgAAfAZQgDAAgDgEIgNgVIgMgWIgFABIgFAAIgFAAIgFABIgFAAIgDAAIgEAAIgGAAIgOABIgCAAIgHAAQgDAAgDgDQgGgFAFgHQACgDAEgCIADAAIAEAAIACAAIAGAAIAGAAIALgBIAGAAIADAAIADAAIADgBIADAAIAFAAIgCgGIgCgFIgDgLQgBgEACgDQABgEAEgBQAIgDAEAJIAAABIABABIABADIABADIABADIABAEIAEAMIAYgCIALgBIAGgBIAFgBIACAAIAFABQAFADABAGQAAAGgFADIgEABIgEAAIgBABIgJABIgFAAIgEAAIgSACIAEAIIACADIABACIABACIABACIACAEIADADIAFAIQADADgBAFQAAAEgEADQgCABgDAAIgDAAg");
	this.shape_1.setTransform(86.7,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0000").s().p("AAJBNQgGAAgFgCQgGgCgGgEQgFgEgEgHQgDgGgBgJQABgPANgMQACgDAEAAQAEABADACQACADABAEIgBAEIgCAEIgCACIgCADIgCADIgBAEQAAAGAFAEQAEADAHABIAzAAQAEAAADACQADADAAAFQAAAEgCADQgDADgFAAgAhDBKQgDgDAAgEIAAgDIACgGIABgEIACgFIAJgnIAIgoIgRAAQgEAAgDgCQgDgDAAgFQAAgDACgEQADgDAFAAIAUAAIAAgCIABgDIAAgEIABgFQABgGACgEQACgCAGAAQAEAAACADQAEADAAAGIAAAEIgBAEIgBAEIgBACIAoAAQAEAAADADQADAEAAADQAAAEgDAEQgDACgEAAIgrAAQgEAbgGAXIgMAxQgBADgDADQgDACgDAAQgEAAgDgDgAAAAAQgCAAgEgCQgDgDAAgEQAAgEADgDQADgDADgBIA1AAQAEAAADAEQADADAAAFQAAADgCADQgDACgFAAgABAgxIgDgFIgDgGQgCgDgBgDQAAgDADgBIAEgDIAFABQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABIADAFIAEAGIABAEQAAADgCACQgCACgDAAQgEAAgCgCgAApgxIgDgFIgEgGQgBgDAAgDQAAgDABgBIAGgDIADABIADADIADAFIADAGIABAEQAAADgCACQgBACgEAAQgEAAgBgCg");
	this.shape_2.setTransform(70.5,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0000").s().p("AAtBKIgCgBIgKgIIgNgKIgHgFIgHgFIgNgJIgEgCIgDgCIgCgBIgCgBIgEgDIgUgLIgCAAIgFgCIgCgCIgCgBQgGgFAAgGQgBgHAFgFIAFgEIAEgCIAGgDIAGgDIADgCIADgCIAGgDIAWgOIAEgDIAFgDIAJgFIAEgDIAFgDIAIgHIADgCIADgDQAHgDAGAFQAGAHgGAGIgDADIgCACIgCABIgLAJIgMAIIgMAIIgDABIgCABIgCABIgFAEQgRALgSAIIAUAKIACABIADACIAEACIAJAGIALAIIALAHIAWAQIADACIAEADIACACIABABIACACQAEAGgFAGQgDAEgEAAIgBAAQgDAAgCgCg");
	this.shape_3.setTransform(56,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0000").s().p("AAZBDIgFgBIgFAAIgJgCQgKgCgHgGQgJgEgFgJQgGgIgCgKQgBgJACgLQACgJAFgJQAEgIAGgIQAIgIAJgIIgDAAIgEAAIgEABIgEAAIgQAAIgfABQgHABgDgHQgCgFADgEQACgEAGgBIALAAIAMAAIAGgBIAGAAIALAAIAugCIAfgBQAGAAADAFQADAGgEAFQgCACgDACIgCAAIgBAAIgEAAIgEAAQgIABgKADIgEACIgEADIgFACIgEACIgMAKIgKAMQgFAGgCAHQgDAIAAAHQAAATARAIQAGACAIABIAOABIADAAIAJABQAHAAACAHQACAIgHADIgFACIgSgBg");
	this.shape_4.setTransform(41.4,0.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0000").s().p("AgJBLIgMgBQgIgDgHgEQgKgGgHgNQgEgLAAgOIAAgXIAAhAQAAgEADgDQACgEAFAAQADAAAEAEQADADAAAEIAABAIAAAZQgBALAIAJQAEAEAFADQAGAEAHAAIANAAQAFgBAGgDQAHgCAGgJIAFgFIACgHIACgPQABgJAJAAQAEAAADADQAEADAAAEIAAABIgBAGIgCAGQgBAHgDAHQgDAIgHAIIgIAIQgFADgFACQgKAEgKAAIgNAAg");
	this.shape_5.setTransform(27.2,-0.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0000").s().p("AhDBPQgFgBgDgDQgCgDABgEQABgFADgCQAEgCAFABIADAAQADgBAAgEIAAgfIgIACQgEABgDgCQgEgCgBgEQAAgEABgEQACgDAFgBIAMgCIAAgiIgKAAQgFAAgCgDQgDgCAAgFQAAgEADgDQACgCAFAAIAKAAIAAgVQAAgFADgDQACgDAFAAQAEAAADADQACADAAAFIAAAVIAHAAQAFAAACACQADADAAAEQAAAEgDADQgCADgFAAIgHAAIAAAcIADgBQAEgCAEABQADABACADQACAEgBADQgBAEgEACIgMAFIAAApQAAAFgDAGQgCAEgFADIgIACIgDABIgIgCgAAWBOQgDgDAAgFIAAgoIgWAAQgHAAgEgEQgFgFAAgGIAAhJQAAgHAFgFQAEgEAHAAIBCAAQAHAAAEAFQAEAFAAAGIAABJQAAAGgEAFQgFAEgGAAIgZAAIAAAoQAAAEgCADQgDADgEAAQgEAAgDgCgAAmALIAOAAQADAAACgCQACgCAAgDIAAgPIgVAAgAAAAEQAAADABACQABACAEAAIANAAIAAgWIgTAAgAAmgeIAVAAIAAgTQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQgCgCgDAAIgOAAgAABg1QgBAAAAABQAAAAAAABQAAAAAAABQAAABAAAAIAAATIATAAIAAgZIgNAAIgCAAQAAAAgBAAQAAABgBAAQAAAAgBAAQAAABAAAAg");
	this.shape_6.setTransform(11.5,0);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0000").s().p("AgPBOIgKgBQgFgCgFgDQgEgDgDgFQgDgFAAgGQAAgLAGgIQAGgHAIgGIATgLIAQgJQgCgJgKAAQgGAAgFACIgNAGIgKAGIgHAJIgHAJQgDADgEAAQgEAAgEgCQgCgCAAgFIABgFIACgFIADgEIADgEIAGgKIAFgJIADgJIAEgKIgSAAQgEAAgDgDQgDgCAAgFQAAgEADgDQACgDAFAAIAYAAIABgCIABgDIABgEIABgCIAAgCIABgDIADgCIAFgBQAEAAAEADQACADAAAEIAAAFIgBAEIA5AAQADAAAEADQADADAAAEQAAAEgDADQgDADgEAAIhBAAQgDALgEAHIANgGQAHgCAGAAIAIABQAFABAEADQAEACADAEQADAEACAGIAHgDIAJgFIAIgDIAHgCQAEAAADADQADADAAADQAAAFgCACIgEADIgGACIgLAEIgJAFIgGADIAAAVQAAAEgEADQgCADgEABQgEAAgDgDQgDgDgBgFIAAgLIgJAFIgLAHIgKAIQgFAEAAAEQAAADAEACQADACAEAAIAOAAIAOAAIAPAAIAWAAQADAAAEADQACADAAAEQAAAEgCADQgDADgEAAg");
	this.shape_7.setTransform(-4.2,-0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0000").s().p("Ag5BGQgFgCgBgGQgBgFAFgEIAFgCIAEgBQAKgBALgEQAQgFANgJQANgJAKgMIAIgLIACgDIABgDIACgEIAAgBIABgCQAGgMADgPIAAgCIABgCQACgEAGgBQAFgBAEAFQACADAAAEIgBADQgDAPgHAQQgJAUgPAPQgMANgRAKQgOAJgTAFIgIACIgEAAIgEABIgDAAIgDABIgEgBgAgKgTIgXgSIgCAAIgCgBIgBgBIgCgBIgDgCIgDgCIgNgHQgHgDABgGQAAgFAFgDQAEgDAFACIACABIABABQAcANAWATQAGAFgDAIQgCAEgEABIgBAAQgEAAgEgCg");
	this.shape_8.setTransform(-19,0.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0000").s().p("AgtBPQgEAAgDgDQgDgCAAgGQAAgHAIgCIARgFQAVgIAPgLIgIgIQgSgPgHgHQgEgDAAgDQAAgIAKgCQAEAAAJAIIALAJIASAPQAKgLAGgLQAGgMADgPQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAIg+AAQgGAHgJAIIgSAOQgCACgEAAQgEAAgDgDQgDgCAAgFQAAgFAHgFIAPgMQAQgOAOgbQADgFAGAAQAEAAACACQADADAAAEQAAAFgIANIA5AAQAQABAAAQQgDAWgJASQgJATgSARQgSARgYAKQgYAKgIAAIAAAAg");
	this.shape_9.setTransform(-33.7,-0.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0000").s().p("AgJBOQgDgEAAgDIAAhkIg4AAQgEgBgDgDQgDgCAAgFQAAgEADgCQADgEAEAAIA4AAIAAgTQAAgEADgDQADgCAEgBQADABADACQADADAAAEIAAATIA5AAQAEAAADAEQADACAAAEQAAAFgDACQgDADgEABIg5AAIAABkQAAADgDAEQgDADgDAAQgEAAgDgDgAA1BBIgCgEIgDgFIgCgEIgCgFIgBgCIgCgCIgCgFIgDgKQgGgQgCgQIgBgBIAAgFQABgHAGgCQAHgCAEAGIACAEIAAADIABACIACAJIACAJIADAJIACAGIABADIADAGIABADIACADIADAGIADAHQADAFgDAEQgCAFgFABQgGAAgEgFgAhLBAQgDgEADgFIAEgHIACgDIABgDIAFgMIAGgSIADgJIABgEIAAgCIABgDIAAgBIABgEIABgEQAEgGAHACQAGABACAIIgBADIAAADIgEAQIgCAIIgDAIQgGATgLASQgDAFgGAAQgGgBgCgFgABBg6IAAgBIgBgCIgCgCIgBgEIgCgCIgBgDQAAgIAHAAQAEABADADIABADIACAEIADAEIABADQAAAIgHAAQgFAAgCgEgAAqg6IgDgFIgCgDIgBgDIgBgDQAAgIAHAAQAEABADADIABADIAFAIIAAAAIABADQAAAIgHAAQgFAAgCgEg");
	this.shape_10.setTransform(-49.4,0);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0000").s().p("AgGBMQgMAAAAgKQAAgKAMAAIAGAAIAAhvIgGAAQgMAAAAgKQAAgKAMAAIAIAAQARAAABARIAAB0QgBARgRABg");
	this.shape_11.setTransform(-64.1,0);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0000").s().p("AAYBOQgCgDAAgEIAAgSIgtAAIAAABQgDAHgFAFQgFAFgIAEQgIADgLACQgEABgDgCQgDgCgBgEQAAgEABgDQADgDAEgBIAMgDQAGgDACgDIABAAIgaAAQgEAAgBgDQgCgCAAgDQAAgEACgCQABgCAEAAIAfAAIAAgBIAAgIIgKAAQgMAAAAgMIAAguQAAgMAMAAIAPAAIgBgDIgBgDIgCgDIAAgBIgKAAIgCADQgGAHgFAEQgDADgEgBQgDAAgDgDQgDgDABgEQAAgEADgDIAJgIIAHgMQABgEAEgCQADgBAEABIAFAFQABADgBAEIAhAAQADAAADACQACACAAADQAAADgCACQgDACgDABIgMAAIABADQABAEgCADIAUAAQgCgDgBgDQABgEACgDQAEgEACgEIAFgKQABgEADgCQAEgCAEABQADACACADQABADgBAFIApAAQADAAADACQACACAAADQAAADgCACQgCACgEABIgNAAIABACQAAAEgBAEIAAABQAGACAAAJIAAAuQAAAMgMAAIgJAAIAAAJIAeAAQAEAAACACQACACAAAEQAAADgCACQgCACgEABIgeAAIAAASQAAAEgDADQgCADgFAAQgEAAgDgDgAgVAkIAAABIArAAIAAgJIgrAAgAgqAMQAAAEADAAIBOAAQAEAAAAgEIAAgEIhVAAgAgqgDIBVAAIAAgIIhVAAgAgqgaIAAADIBVAAIAAgDQAAgEgEAAIhOAAQgDAAAAAEgAANgqIAAAAIAcAAIgBgDIgCgEIgCgDIAAAAIgPAAIgIAKg");
	this.shape_12.setTransform(-75.7,0);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0000").s().p("AAdBOQgDgDAAgFIAAhGIgZAAQgEgBgCgCQgDgCAAgFQAAgEADgDQACgCAEAAIAZAAIAAgzQAAgEADgDQACgDAFAAQAEABACACQADADABAEIAAAzIAXAAQAEAAADACQADADgBAEQABAEgDADQgDACgEABIgXAAIAABGQgBAFgDADQgCACgEABQgEgBgDgCgAg9BMQgMABAAgMIAAgfQAAgMAMAAIAlAAQALAAAAAMIAAAfQAAAMgLgBgAg2ArIAAANQAAABAAABQAAAAABABQAAAAABAAQABABABAAIAQAAQADAAAAgEIAAgNQAAgEgDAAIgQAAQgBAAgBABQgBAAAAAAQgBABAAAAQAAABAAABgAhBAQQgEAAgCgDQgCgCgBgEQABgDACgDQACgCAEABIAtAAQADAAADAAQACADAAAEQAAADgCADQgDADgDAAgAhBgIQgEAAgCgCQgCgCgBgFQABgDACgDQACgCAEAAIAtAAQADAAADACQACADAAADQAAAEgCADQgDACgDAAgAhEggQgFAAgDgDQgBgCAAgEQAAgEABgCQADgDAFAAIA0AAQAEAAACADQADABAAAFQAAADgDADQgCADgEAAgAhBg4QgEgBgCgCQgCgCgBgEQABgDACgDQACgCAEAAIAtAAQADAAADACQACACAAAEQAAADgCADQgDADgDAAg");
	this.shape_13.setTransform(-92.7,0);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0000").s().p("AgCBMQgQgBgBgRIAAh0QABgRAQAAIAJAAQANAAAAAKQAAAKgNAAIgGAAIAABvIAGAAQANAAAAAKQAAAKgNAAg");
	this.shape_14.setTransform(-104,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.2,-10.5,224.5,21);


(lib.vjvQ操作txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AgkBCQgHgDgGgHQgEgFgEgIQgDgGgDgKIgDgPIgBgZIABgaIABgGIABgHIABgHQABgJAJAAQAEAAADADQACADAAAEIAAACIAAAFIgBAEIAAADIgBAIIAAADIAAACIgBACIAAAMIAAANIABALIACAMQABAJAEAHIADAGIAFAFQAGAFAGgDQAEgCAEgFQADgDACgFQADgGAFAAQAEAAADADQADADAAAEIgBAFQgEAIgGAHQgFAHgIADIgFABIgGABQgHAAgGgDgAA4AtQgIgCAAgIIAAgBIAAgBQABgTgDgRQgCgKgEgIQgDgJgFgIIgDgEIgDgEQgEgFAEgHQAEgHAIAEIADACIACACQAHAJAFAKQAFALADALQAGAVgBAXIAAAEIAAADIgBAFQgDAFgGAAIgCAAg");
	this.shape.setTransform(98.1,9.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0000").s().p("AgFBNIgHAAIgDAAIgEAAIgNgCQgOgEgGgOQgFgMADgMQADgNAKgHIAGgEQAGgBAEADQAEADAAAGQAAAEgFADIgCABQgFADgCAHQgBAJAEAFQADADAFABIAIABIALAAIA1AAQAEAAADADQADADAAAEQAAAEgDADQgDADgEAAIg1AAgAAfAZQgDAAgDgEIgNgVIgMgWIgFABIgFAAIgFAAIgFABIgFAAIgDAAIgEAAIgGAAIgOABIgCAAIgHAAQgDAAgDgDQgGgFAFgHQACgDAEgCIADAAIAEAAIACAAIAGAAIAGAAIALgBIAGAAIADAAIADAAIADgBIADAAIAFAAIgCgGIgCgFIgDgLQgBgEACgDQABgEAEgBQAIgDAEAJIAAABIABABIABADIABADIABADIABAEIAEAMIAYgCIALgBIAGgBIAFgBIACAAIAFABQAFADABAGQAAAGgFADIgEABIgEAAIgBABIgJABIgFAAIgEAAIgSACIAEAIIACADIABACIABACIABACIACAEIADADIAFAIQADADgBAFQAAAEgEADQgCABgDAAIgDAAg");
	this.shape_1.setTransform(82.6,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0000").s().p("AAJBNQgGAAgFgCQgGgCgGgEQgFgEgEgGQgDgHgBgIQABgPANgMQACgDAEAAQAEAAADACQACADABAFIgBADIgCAEIgBACIgDACIgCAEIgBAEQAAAGAFAEQAEAEAHAAIAzAAQAEAAADADQADACAAAFQAAADgCAEQgDACgFABgAhDBKQgDgCAAgEIAAgFIACgEIABgFIACgEIAJgpIAIgmIgRAAQgEAAgDgEQgDgCAAgEQAAgFACgCQADgDAFAAIAUAAIAAgDIABgDIAAgDIABgGQABgGACgDQACgDAGAAQADAAADADQAEADAAAGIAAADIgBAFIgBAEIgBADIAoAAQAEAAADADQADACAAAFQAAADgDADQgDAEgEAAIgrAAQgEAagGAXIgMAxQgBADgDACQgDADgDAAQgEAAgDgDgAAAAAQgCAAgEgCQgDgDAAgEQAAgEADgDQADgDADAAIA1AAQAEAAADADQADADAAAEQAAAEgDADQgCACgFAAgABAgxIgDgFIgDgGQgCgDgBgCQAAgEADgCIAEgCIAFABQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABIADAFIAEAGIABAEQAAADgCACQgCACgEAAQgDAAgCgCgAApgxIgDgFIgEgGQgBgDAAgCQAAgEABgCIAGgCIADABIADADIADAFIADAGIABAEQAAADgCACQgBACgEAAQgEAAgBgCg");
	this.shape_2.setTransform(66.4,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0000").s().p("AAtBKIgCgBIgKgIIgNgKIgHgFIgHgFIgNgJIgEgCIgDgCIgCgBIgCgBIgEgDIgUgLIgCAAIgFgCIgCgCIgCgBQgGgFAAgGQgBgHAFgFIAFgEIAEgCIAGgDIAGgDIADgCIADgCIAGgDIAWgOIAEgDIAFgDIAJgFIAEgDIAFgDIAIgHIADgCIADgDQAHgDAGAFQAGAHgGAGIgDADIgCACIgCABIgLAJIgMAIIgMAIIgDABIgCABIgCABIgFAEQgRALgSAIIAUAKIACABIADACIAEACIAJAGIALAIIALAHIAWAQIADACIAEADIACACIABABIACACQAEAGgFAGQgDAEgEAAIgBAAQgDAAgCgCg");
	this.shape_3.setTransform(51.9,9.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0000").s().p("AAZBDIgFAAIgFgBIgJgCQgKgCgHgFQgJgGgFgIQgGgJgCgJQgBgJACgLQACgJAFgJQAEgIAGgJQAIgHAJgIIgDAAIgEAAIgEAAIgEAAIgQABIgfABQgHAAgDgGQgCgEADgFQACgEAGgBIALgBIAMAAIAGAAIAGAAIALgBIAugBIAfgBQAGAAADAGQADAFgEAFQgCACgDABIgCABIgBAAIgEAAIgEAAQgIAAgKAFIgEACIgEACIgFACIgEADIgMAJIgKAMQgFAHgCAGQgDAIAAAHQAAATARAHQAGADAIABIAOACIADAAIAJAAQAHAAACAIQACAHgHAEIgFABIgSgBg");
	this.shape_4.setTransform(37.4,9.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0000").s().p("AgJBMIgMgCQgIgCgHgEQgKgIgHgNQgEgKAAgOIAAgXIAAhAQAAgEACgEQADgCAFAAQADAAAEACQADADAAAFIAABAIAAAZQgBALAIAJQAEAFAFACQAGADAHAAIANAAQAFAAAGgDQAHgCAGgIIAFgHIACgHIACgOQABgJAJAAQAEAAADADQAEADAAAEIAAABIgBAGIgCAGQgBAGgCAIQgEAJgHAHIgIAHQgFAEgFACQgKAEgKABIgNAAg");
	this.shape_5.setTransform(23.1,9.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0000").s().p("AhDBPQgFgBgDgDQgCgDABgEQABgFADgCQAEgCAFABIADAAQADgBAAgEIAAgfIgIACQgEABgDgCQgEgCgBgEQAAgEABgEQACgDAFgBIAMgCIAAgiIgKAAQgFAAgCgDQgDgCAAgFQAAgEADgDQACgCAFAAIAKAAIAAgVQAAgFADgDQACgDAFAAQAEAAADADQACADAAAFIAAAVIAHAAQAFAAACACQADADAAAEQAAAEgDADQgCADgFAAIgHAAIAAAcIADgBQAEgCAEABQADABACADQACAEgBADQgBAEgEACIgMAFIAAApQAAAFgDAGQgCAEgFADIgIACIgDABIgIgCgAAWBOQgDgDAAgFIAAgoIgWAAQgHAAgEgEQgFgFAAgGIAAhJQAAgHAFgFQAEgEAHAAIBCAAQAHAAAEAFQAEAFAAAGIAABJQAAAGgEAFQgFAEgGAAIgZAAIAAAoQAAAEgCADQgDADgEAAQgEAAgDgCgAAmALIAOAAQADAAACgCQACgCAAgDIAAgPIgVAAgAAAAEQAAADABACQABACAEAAIANAAIAAgWIgTAAgAAmgeIAVAAIAAgTQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQgCgCgDAAIgOAAgAABg1QgBAAAAABQAAAAAAABQAAAAAAABQAAABAAAAIAAATIATAAIAAgZIgNAAIgCAAQAAAAgBAAQAAABgBAAQAAAAgBAAQAAABAAAAg");
	this.shape_6.setTransform(7.5,9.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0000").s().p("AgPBOIgKgBQgFgCgFgDQgEgDgDgFQgDgFAAgGQAAgLAGgIQAGgHAIgGIATgLIAQgJQgCgJgKAAQgGAAgFACIgNAGIgKAGIgHAJIgHAJQgDADgEAAQgEAAgEgCQgCgCAAgFIABgFIACgFIADgEIADgEIAGgKIAFgJIADgJIAEgKIgSAAQgEAAgDgDQgDgCAAgFQAAgEADgDQACgDAFAAIAYAAIABgCIABgDIABgEIABgCIAAgCIABgDIADgCIAFgBQAEAAAEADQACADAAAEIAAAFIgBAEIA5AAQADAAAEADQADADAAAEQAAAEgDADQgDADgEAAIhBAAQgDALgEAHIANgGQAHgCAGAAIAIABQAFABAEADQAEACADAEQADAEACAGIAHgDIAJgFIAIgDIAHgCQAEAAADADQADADAAADQAAAFgCACIgEADIgGACIgLAEIgJAFIgGADIAAAVQAAAEgEADQgCADgEABQgEAAgDgDQgDgDgBgFIAAgLIgJAFIgLAHIgKAIQgFAEAAAEQAAADAEACQADACAEAAIAOAAIAOAAIAPAAIAWAAQADAAAEADQACADAAAEQAAAEgCADQgDADgEAAg");
	this.shape_7.setTransform(-8.3,9.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0000").s().p("Ag5BGQgFgCgBgGQgBgFAFgEIAFgCIAEgBQAKgBALgEQAQgFANgJQANgJAKgMIAIgLIACgDIABgDIACgEIAAgBIABgCQAGgMADgPIAAgCIABgCQACgEAGgBQAFgBAEAFQACADAAAEIgBADQgDAPgHAQQgJAUgPAPQgMANgRAKQgOAJgTAFIgIACIgEAAIgEABIgDAAIgDABIgEgBgAgKgTIgXgSIgCAAIgCgBIgBgBIgCgBIgDgCIgDgCIgNgHQgHgDABgGQAAgFAFgDQAEgDAFACIACABIABABQAcANAWATQAGAFgDAIQgCAEgEABIgBAAQgEAAgEgCg");
	this.shape_8.setTransform(-23,9.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0000").s().p("AgtBPQgEAAgDgDQgDgCAAgGQAAgHAIgCIARgFQAVgIAPgLIgIgIIgZgWQgEgDAAgDQAAgIAKgCQAEAAAJAIIALAJIASAPQAKgLAGgLQAGgMADgPQAAgBAAAAQAAgBAAAAQAAAAgBgBQAAAAgBAAIg+AAQgGAHgJAIIgSAOQgCACgEAAQgEAAgDgDQgDgCAAgFQAAgFAHgFIAPgMQAQgOAOgbQADgFAGAAQAEAAACACQADADAAAEQAAAFgIANIA5AAQAQABAAAQQgDAWgJASQgJATgSARQgSARgYAKQgYAKgIAAIAAAAg");
	this.shape_9.setTransform(-37.8,9.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0000").s().p("AgJBNQgDgCAAgFIAAhkIg4AAQgEAAgDgCQgDgDAAgEQAAgFADgDQADgCAEAAIA4AAIAAgUQAAgEADgDQADgCAEAAQADAAADACQADADAAAEIAAAUIA5AAQAEAAADACQADADAAAFQAAAEgDADQgDACgEAAIg5AAIAABkQAAAFgDACQgDADgDAAQgEAAgDgDgAA1BBIgCgFIgDgDIgCgFIgCgFIgBgCIgCgDIgCgEIgDgJQgGgRgCgPIgBgBIAAgHQABgGAGgCQAHgBAEAFIACAEIAAACIABAEIACAIIACAKIADAJIACAEIABAFIADAGIABACIACACIADAIIADAGQADAEgDAGQgCAEgFABQgGAAgEgFgAhLBBQgDgFADgFIAEgGIACgEIABgEIAFgKIAGgSIADgKIABgEIAAgCIABgCIAAgCIABgEIABgEQAEgGAHACQAGACACAGIgBAEIAAAEIgEAPIgCAIIgDAJQgGASgLASQgDAFgGAAQgGgBgCgEgABBg6IAAAAIgBgDIgCgDIgBgCIgCgDIgBgEQAAgGAHAAQAEAAADADIABADIACAEIADAEIABAEQAAAHgHAAQgFAAgCgEgAAqg6IgDgGIgCgCIgBgDIgBgEQAAgGAHAAQAEAAADADIABADIAFAIIAAAAIABAEQAAAHgHAAQgFAAgCgEg");
	this.shape_10.setTransform(-53.4,9.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0000").s().p("AgGBLQgMAAAAgKQAAgJAMgBIAGAAIAAhtIgGAAQgMAAAAgKQAAgKAMAAIAIAAQARAAABAQIAAB1QgBAQgRAAg");
	this.shape_11.setTransform(-68.2,9.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0000").s().p("AAYBOQgCgDAAgEIAAgSIgtAAIAAABQgDAHgFAFQgFAFgIAEQgIADgLACQgEABgDgCQgDgCgBgEQAAgEABgDQADgDAEgBIAMgDQAGgDACgDIABAAIgaAAQgEAAgBgDQgCgCAAgDQAAgEACgCQABgCAEAAIAfAAIAAgBIAAgIIgKAAQgMAAAAgMIAAguQAAgMAMAAIAPAAIgBgDIgBgDIgCgDIAAgBIgKAAIgCADQgGAHgFAEQgDADgEgBQgDAAgDgDQgDgDABgEQAAgEADgDIAJgIIAHgMQABgEAEgCQADgBAEABIAFAFQABADgBAEIAhAAQADAAADACQACACAAADQAAADgCACQgDACgDABIgMAAIABADQABAEgCADIAUAAQgCgDgBgDQABgEACgDQAEgEACgEIAFgKQABgEADgCQAEgCAEABQADACACADQABADgBAFIApAAQADAAADACQACACAAADQAAADgCACQgCACgEABIgNAAIABACQAAAEgBAEIAAABQAGACAAAJIAAAuQAAAMgMAAIgJAAIAAAJIAeAAQAEAAACACQACACAAAEQAAADgCACQgCACgEABIgeAAIAAASQAAAEgDADQgCADgFAAQgEAAgDgDgAgVAkIAAABIArAAIAAgJIgrAAgAgqAMQAAAEADAAIBOAAQAEAAAAgEIAAgEIhVAAgAgqgDIBVAAIAAgIIhVAAgAgqgaIAAADIBVAAIAAgDQAAgEgEAAIhOAAQgDAAAAAEgAANgqIAAAAIAcAAIgBgDIgCgEIgCgDIAAAAIgPAAIgIAKg");
	this.shape_12.setTransform(-79.7,9.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0000").s().p("AAdBOQgDgDAAgFIAAhHIgZAAQgEAAgCgCQgDgDAAgEQAAgEADgCQACgEAEAAIAZAAIAAgxQAAgFADgCQACgDAFAAQAEAAACACQADADABAFIAAAxIAXAAQAEABADACQADADgBAEQABAEgDADQgDACgEAAIgXAAIAABHQgBAEgDADQgCADgEAAQgEAAgDgCgAg9BNQgMgBAAgLIAAgfQAAgMAMAAIAlAAQALAAAAAMIAAAfQAAALgLABgAg2ArIAAANQAAABAAABQAAAAABABQAAAAABAAQABAAABAAIAQAAQADAAAAgDIAAgNQAAgDgDAAIgQAAQgBAAgBAAQgBAAAAAAQgBABAAAAQAAABAAABgAhBAPQgEAAgCgBQgCgDgBgEQABgDACgDQACgCAEAAIAtAAQADAAADACQACACAAAEQAAADgCADQgDADgDgBgAhBgIQgEAAgCgDQgCgCgBgDQABgEACgCQACgDAEAAIAtAAQADAAADACQACADAAAEQAAADgCACQgDADgDAAgAhEggQgFAAgDgCQgBgDAAgEQAAgEABgDQADgCAFAAIA0AAQAEAAACACQADACAAAFQAAAEgDACQgCADgEAAgAhBg5QgEAAgCgBQgCgDgBgEQABgEACgCQACgCAEgBIAtAAQADAAADACQACADAAAEQAAADgCADQgDADgDgBg");
	this.shape_13.setTransform(-96.7,9.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0000").s().p("AgCBLQgQAAgBgQIAAh1QABgQAQAAIAJAAQANAAAAAKQAAAKgNAAIgGAAIAABtIAGAAQANABAAAJQAAAKgNAAg");
	this.shape_14.setTransform(-108.1,9.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0000").s().p("AAZBDIgGAAIgEgBIgJgCQgKgCgHgFQgJgGgFgIQgGgJgCgJQgBgJACgLQACgJAFgJQAEgIAGgJQAIgIAJgHIgDAAIgEAAIgEAAIgEAAIgQABIggABQgGAAgDgFQgCgFACgFQADgEAGgBIAMgBIALAAIAGAAIAGAAIALgBIAugBIAfgBQAGAAADAFQADAGgEAFQgCACgEABIgBABIgBAAIgEAAIgEAAQgIAAgKAFIgEACIgEACIgFACIgEADIgMAJIgKAMQgFAGgCAHQgDAIAAAHQAAATARAHQAGADAIABIAOACIADAAIAJAAQAHAAACAIQACAHgGAEIgGABIgSgBg");
	this.shape_15.setTransform(106.3,-9.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0000").s().p("AAABLIAAgBQgDgEABgFIADgGIAGgBIACgBIACAAIAGgBQAGAAAFgCIAFgCIACgBIABAAIAEgDIAHgHIAEgGIAAgCIABgEQADgJAAgJQgBgKgDgHQgDgGgIgGQgJgGgMgCIgFAAIAAAEIgBAEIgBADIgBAEIgEAOIgBAEIgBADIgBACIgBACIAAABIAAABIgBACIgEAOIgDAFIgCAFIgDAFIgDAEQgHAKgJAFQgRAJgNgKIgGgGIgEgHQgDgHgBgJQgBgMAFgPIAGgMIACgDIACgDIACgCIACgDIgEgLIgCgFIgBgCIgBgDIgCgHIAAgCIgBgCQAAgFADgDQADgDAFABQAGAAADAGIADALIAEAKQAJgHAJgEQAJgEAMgBIAAgHIABgEIABgEIABgFIABgEQABgFAFgCQAFgCAEADQAFADAAAFIgBAEIgEARIADABIAEAAIACABIACAAIAEABIACABIABAAQANAFAIAIIACACIACACIABABIAAABQAFAIAEAJQAHAXgLAbIgDAGIgDAGIgFAEIgFAFIgBAAIgBABIgCABIgEACIgDABIgRAGIgQABIgBAAQgDAAgEgCgAg0ATIgCAOIACAJQABAFADACQAEADAGgDQAEgCAEgFIgFgJIgDgGIgBgDIgCgEIgFgNQgEAGgCAGgAgggKIAEALIACAEIACAEIABAFIAEAJIACgGIACgGIACgGIACgFIABgGIACgGIADgMQgPADgMALg");
	this.shape_16.setTransform(90.4,-9.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0000").s().p("AhEBGIAAgEIgBgEIAAgBIgBgHIAAgHIAAgFIgBgEIAAgFIAAgJIAAgIIAAgEIgBgEIAAgFIAAgEIABgDIAAgFIAAgIIAAgGIAAgEIAAgDIABgFIAAgFIAAgFIABgJIABgEIAAgFQABgJAJgBQAEAAADAEQADADAAAEIAAABIAAAEIgBACIAAAEIgCAcIgBAaIABAcIACAcIAAAEIABAFIAAABQAAAEgDAEQgDACgEAAQgJAAgBgJgAgRBJQgKgEgGgKQgEgGAAgKIABgKQACgFAFgGQAFgHAHgDQAJgDAKgBQAJAAAKAEIAAgiIgxAAQgEAAgDgEQgDgDAAgDQAAgFADgCQADgDAEAAIAxAAIAAgaQAAgEACgDQADgDAEAAQAEAAAEADQACADAAAEIAAAaIAXAAQADAAAEADQADACAAAFQAAADgDADQgDAEgEAAIgXAAIAAAtIABABIADACIAMAMIAGAGIAFAGIAAAAQADADAAAEQAAAEgDADQgDADgEAAQgEAAgEgEIAAAAIAAAAIgEgEIgDgDIgHgHQgFAPgMAHQgKAFgLABIgCAAQgIAAgHgEgAgEAdIgHADQgIAFACAJQABAEAFADQAEADAEAAQAJABAIgGQAEgDABgFQACgEAAgFQgJgFgIAAIgIAAg");
	this.shape_17.setTransform(74.4,-9.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0000").s().p("AAZBDIgGAAIgEgBIgJgCQgKgCgHgFQgJgGgFgIQgGgJgBgJQgCgJACgLQACgJAEgJQAFgIAHgJQAHgIAJgHIgDAAIgEAAIgEAAIgEAAIgQABIggABQgGAAgDgFQgCgFACgFQADgEAGgBIAMgBIALAAIAGAAIAGAAIAMgBIAtgBIAfgBQAGAAADAFQADAGgEAFQgCACgEABIgBABIgBAAIgEAAIgEAAQgIAAgKAFIgEACIgFACIgEACIgEADIgMAJIgKAMQgFAGgCAHQgDAIAAAHQAAATARAHQAGADAIABIAOACIADAAIAJAAQAHAAACAIQACAHgGAEIgGABIgSgBg");
	this.shape_18.setTransform(58.3,-9.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0000").s().p("AAKBLQgDgDAAgEQAAgEADgDQADgDAEAAIAHgBIAGgBQAJgCAGgHQADgEACgHQACgGgBgJQgCgHgFgFIgIgHIgDAKIgEAJQgIAQgMAMQgFAGgHAFIgHAEIgHAEQgKAEgLAAQgMAAgIgHQgIgFgDgMQgCgJACgLQADgNAJgLQAIgJAPgIIgBgUIgVAAQgJAAgBgKQAAgDADgEQADgDAEAAIAVAAIAAgOQAAgJAKgBQAEAAADAEQADADAAADIAAAOIBHAAQAEAAADADQADADAAAEQAAAFgDADQgDACgEAAIhHAAIABANIAPgCQANAAAMACIAMADIALAFQAKAGAGAJQAHAMgBANQAAAOgGAMQgIANgQAHQgGADgGAAIgMAAQgEAAgDgCgAglALIgFAGQgEAFgDAGQgCAFAAAFQAAAHADADQAEAFAIgBQAFAAAGgDIgCgKIgFgfIgFADgAgNAAIABANIACAPIABAEIACAGQAFgEAEgHIAIgNIAGgNIABgDIgMgBQgIAAgKADg");
	this.shape_19.setTransform(42.7,-9.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0000").s().p("AgPBOIgKgBQgFgCgFgDQgEgDgDgFQgDgFAAgGQAAgLAGgIQAGgHAIgGIATgLIAQgJQgCgJgKAAQgGAAgFACIgNAGIgKAGIgHAJIgHAJQgDADgEAAQgEAAgEgCQgCgCAAgFIABgFIACgFIADgEIADgEIAGgKIAFgJIADgJIAEgKIgSAAQgEAAgDgDQgDgCAAgFQAAgEADgDQACgDAFAAIAYAAIABgCIABgDIABgEIABgCIAAgCIABgDIADgCIAFgBQAEAAAEADQACADAAAEIAAAFIgBAEIA5AAQADAAAEADQADADAAAEQAAAEgDADQgDADgEAAIhBAAQgDALgEAHIANgGQAHgCAGAAIAIABQAFABAEADQAEACADAEQADAEACAGIAHgDIAJgFIAIgDIAHgCQAEAAADADQADADAAADQAAAFgCACIgEADIgGACIgLAEIgJAFIgGADIAAAVQAAAEgEADQgCADgEABQgEAAgDgDQgDgDgBgFIAAgLIgJAFIgLAHIgKAIQgFAEAAAEQAAADAEACQADACAEAAIAOAAIAOAAIAPAAIAWAAQADAAAEADQADADgBAEQAAAEgCADQgDADgEAAg");
	this.shape_20.setTransform(27.3,-9.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0000").s().p("ABEBQQgDAAgEgEIgLgJQgEgDgBgEQgBgEADgDIACgDIgYAAIACACQADADAAAEQAAADgEAEQgHAGgKAGQgFACgDgBQgDgBgCgEQgCgDABgEQABgDAEgDIANgKIACgBQgEgBgDgDQgFgFAAgFIAAhEQAAgFAFgFQAEgEAGAAIAJAAIAAgCIACgHIAAgBIgWAAQgEAAgCgCQgCgCAAgFQAAgDACgDQACgDAEAAIA/AAQAEAAADADQACACAAAEQAAAEgCADQgDACgEAAIgVAAIgBAFIgCAFIAOAAQAGgBAEAFQAEAFAAAFIAABEQAAAFgEAFQgEAEgGAAIABABQAGAEAIAIQADAEAAADQAAAEgDADQgCADgEAAIgBAAgAAWAaIABAFQABAAAAAAQABABAAAAQABAAAAAAQABAAABAAIAVAAQADAAACgBQACgCAAgDIAAgDIgiAAgAAWAGIAiAAIAAgIIgiAAgAAXgbQgBACAAADIAAADIAiAAIAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQgCgCgDAAIgVAAQgBAAgBAAQAAAAgBABQAAAAgBAAQAAAAgBABgAg3BMQgMAAAAgLIAAgeIABgFIgGAAQgDgBgCgEQgCgDABgEQABgDAEgCIALgEIALgFIgEgBQgEgCgCgCIAAgDIgBAAQgEACgDAAQgDgBgCgCQgCgDAAgEQABgDADgCQAEgCACgCIAFgIQABgEAEgDQADgDAHgBIAVAAIAIAAIAAgBIAAgEQgBgEgDAAIghAAQAAAAgBAAQgBAAAAABQgBAAAAAAQAAABgBAAQAAABgBAAQAAAAAAABQgBAAAAABQAAABAAAAIAAAFQAAAEgCADQgCACgEAAQgEAAgCgCQgDgDAAgEIAAgMQAAgFAFgFQAFgFAGAAIAOAAIAAgEQAAgFACgCQADgDAEAAQADAAADADQADACAAAFIAAAEIAPAAQAEAAAEACQADADACAEIABAHQAAAGAAAGQgBAEgDACIgEABIgCAKQgEAKgFAIIgCACIATAKQADACABAEQABAEgCADQgCADgDABQgEABgEgDIgWgNQgIAGgJAFIAfAAQAMAAAAAMIAAAeQAAALgMAAgAgxArIAAAOQAAADADABIAQAAQAEAAAAgEIAAgOQAAgEgEAAIgQAAQgBAAAAAAQgBABAAAAQgBABAAAAQAAABAAABgAgvgWIgFAIIADABIAOAGIAGgJQACgDgCgDQAAgBAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgHAAQgFAAgCACg");
	this.shape_21.setTransform(11,-9.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0000").s().p("AhEBOQgEAAgDgDQgCgDAAgEQAAgEACgDQADgDAEABIAUAAIgCgEIgFgIQgDgDABgEQAAgEAEgDQADgDAEABQADAAAEAEIAHANQACAEgBADIgCAEIAXAAIAAggIg0AAQgFAAgCgDQgDgCAAgFQAAgDADgEQACgCAFAAIA0AAIAAgRIgdAAQgEAAgDgCQgDgDAAgEIAAgCIgPAIQgEABgEgBQgEgBgBgFQgCgDABgFQACgDAEgCQAYgJANgKQAPgKAMgNQAEgDAEAAQAEAAAEACQANAOAPALQANAJAYAJQAEACABAEQABADgBAEQgCAFgEACQgDAAgFgBIgQgJIAAADQAAAEgDADQgCACgEAAIgeAAIAAARIA2AAQAEAAACACQADADAAAEQAAAFgDACQgCADgEAAIg2AAIAAAgIAQAAIAAgBIAHgMIAFgJQACgEAEgBQADgBAEABQAEABABAEQABAEgCAEIgGALIgBADIAWAAQAEgBADADQADADAAAEQAAAEgDADQgCACgFABgAgEg1QgKALgQALIgGADIBJAAIgFgCQgSgMgKgMQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAQgCABgCACg");
	this.shape_22.setTransform(-5.9,-9.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#CC0000").s().p("AgKBOIgFgDIgGgEQgJgIgCgLQAAgJABgGQADgHAFgGQAFgGAIgDIAHgDQALgCANAEIAAAAIAAgcQAAgEADgDQADgDAEAAQAEAAADADQADACAAAFIAAAlIADABIABABIABABIAFADQAJAGAJAIQADADAAAFQAAAEgDADQgEADgFgBQgCAAgDgCIgDgEIgEgDIgDgCIgEgDQgCAQgMAKQgIAGgKACIgGAAQgFAAgIgCgAgDAhQgFADgCAEQgDAFACAFQABAFAFADQAFACAEAAQAKAAAGgKQABgDAAgEIABgGIAAgCIgEgBIgDgBIgHgBIgEgBQgEAAgDACgAg+BJQgFgCgBgFIAAgEIABgDIABgDIABgEIACgFQAKgnAHgoIgRAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIAUAAIADgSQABgJAJAAQAEAAADADQADADAAAEIAAACIgBADIAAAEIgBAIIAdAAQAEAAADADQADACAAAFQAAAEgDADQgDADgEAAIggAAIgBACIAAADIgBAEIAAADIgBACIgBAFIAAACIAAADIgBAEIgCAJIgCAHIgCAIIgBAHIgBAEIgBADIgBAEIgBAEIgBAEIgBADIgBAEIgBAEIgBADIgBAEIgBACQgBAEgDACQgDACgDAAIgEgBgAA4gVIgMgNIgPgOIAAAAQgEgDAAgEQAAgEADgEQADgCAEAAQADAAADABIAAAAIACACIACACIAEADIAIAHIAEAEIAEAEIAHAJIAAAAQACADAAADQAAAEgDADQgDADgEAAQgFAAgDgEg");
	this.shape_23.setTransform(-22.3,-9.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CC0000").s().p("AgbBPQgDAAgDgEQgBgDAAgEQABgEAFgDQANgFAIgIQAHgIAFgMQAEgLACgMQACgQAAgbIAAgNIgQAAQgFAAgDgDQgCgDgBgEQABgEACgDQADgCAFAAIA9AAQAGAAAFACQAFACACAFQACAGAAAGQgBAxgCAfQgCAUgEAKQgEAIgHAFQgGAEgKAAQgLABgKgCQgFgCgCgDQgCgDABgEQABgFADgCQADgBAFAAIAQACQAFAAACgDQAEgDACgJQACgIABgcIABgyQAAgFgCgCQgCgCgEAAIgSAAIAAANQAAAggDAQQgDARgGANQgGAOgKAKQgKAJgNAFQgDABgDAAIgCAAgAgsAzQgIgBgDgFQgFgFAAgHIAAgtIgEABQgFABgDgCQgDgCgBgEQgBgEACgEQADgDAEgBIAIgBIAAgkQAAgFADgDQADgDAEAAQAEAAADADQACADABAFIAAAhIAbgFQAFgBADACQADACABAFQABADgCAEQgDADgEABIgfAFIAAArIAAADIADABIAKgBQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAABgBIACgOQAAgFADgDQACgCAFAAQAEAAACADQADADAAAFIgEAWQgBAFgDADQgEAEgHABIgLAAIgLAAg");
	this.shape_24.setTransform(-39.1,-9.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#CC0000").s().p("AhIBQQgEgBgCgEQgBgDABgEQACgDAEgCQAJgGADgFIABgFIAAgwQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAgBgBQAAAAgBAAQAAAAgBgBQAAAAgBAAIgDAAQgEAAgEgDQgCgCgBgEQABgEACgDQAEgDAEAAIAMAAQAIAAAEAFQAFAEgBAHIAAA0QABADAEAEQAFAGAJADQAIACARAAIBAgBQAFAAADACQADADABAEQAAAEgDADQgDADgEABIhLgBQgPAAgNgEQgKgEgEgGQgCAEgFAFQgFAEgFACIgGABIgCAAgAgcA1QgEgDAAgFIAAhIQAAgFAFgEQADgEAFAAIAIAAIgDgKIgMAAQgEAAgCgCQgCgCAAgDQAAgEACgCQACgCAEAAIAlAAIAAgEQABgFACgCQACgDAFAAQAEAAADACQACADAAAFIAAAEIApAAQADAAACACQACACABAEQgBADgCACQgCACgDAAIgPAAIgBAHIgBADIAKAAQAEAAAEADQAEAEgBAFIAAA+QABAMgKAHIgEACIgKAAQgGAAgCgDQgCgDgBgEQABgEADgDQADgCAFAAIABAAIAAAAQABAAAAAAQABgBAAAAQAAAAAAgBQAAgBAAAAIAAg3QAAgDgDgBIgWAAIAAAJIAPAAQADAAACABQACACAAADQAAABgBABQAAAAAAABQAAAAAAABQgBAAAAABQgCACgDAAIgPAAIAAAHIAIAAQAMAAgBALIAAANQABALgMAAIgjAAQgLAAAAgLIAAgNQAAgLALAAIAIAAIAAgHIgNAAQgBAAgBAAQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAgBgBAAQAAAAgBgBQAAgBAAAAQAAgBAAgBQAAgDACgCQAAAAABAAQAAgBABAAQAAAAABAAQABAAABAAIANAAIAAgJIgTAAQgBAAAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQAAABgBAAQAAABAAAAQAAAAAAABQgBAAAAABIAABBQAAAFgCADQgDACgEABQgEgBgCgCgAAKAUIAAACQAAABAAAAQAAABABAAQAAABABAAQABAAAAAAIAQAAQABAAABAAQAAAAABgBQAAAAAAgBQAAAAAAgBIAAgCQAAgEgDAAIgQAAQgDAAAAAEgAAIgpIAAABIAaAAIABgBIACgHIAAgCIggAAgAg3gsQgIgHgGgCQgDgDgCgDQgBgEACgEQACgDADgCQAEgBAEADQAIAEAKAIQADADAAAEQABADgDAEQgDADgEAAQgEAAgDgDg");
	this.shape_25.setTransform(-55.9,-9.6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#CC0000").s().p("AhDBDIAAgEIAAgEIAAgBIgBgHIgBgHIAAgFIAAgSIgBgMIAAgEIAAgFIAAgEIAAgDIAAgEIAAgGIABgDIAAgSIAAgFIABgFIABgJIAAgEIABgFQAAgJAKgBQAEAAADAEQADADAAAEIAAABIAAAEIgBACIgBAEIgCAcIAAAaIAAAcIACAcIABAEIABAFIAAABQAAAEgDAEQgDACgFAAQgIAAgCgJgAATBIIgKAAIgMgBQgMgDgJgIQgHgGgDgKQgCgKADgKQADgIAGgIIAJgIQADgCADgBQAJABABAIQgBAFgCADIgDADQgFADgCAGQgCAEAAAFQAAAFABADQAEAGAJACIACAAIACAAIAEAAIALAAIABAAIApAAIABAAQAEABACADQADACAAAFQAAADgDADQgDAEgEAAgAgKgrQgFAAgCgEQgDgDgBgEQABgDADgDQACgDAFAAIBBAAQAKgBAAAKQAAAKgKABg");
	this.shape_26.setTransform(-72.1,-9.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#CC0000").s().p("AgWBPQgDgCAAgDIAAg2IgCACQgDAAgDgBQgCgBgCgEIgDgJIAABAQAAAEgDACQgCADgEAAQgEAAgDgCQgCgDAAgEIAAgxIgDAJQgBAEgEABQgCABgEgBQgDgBgBgDQgBgCABgFQALgdAEgVIgGAAQgEAAgCgDQgDgCAAgFQAAgDADgDQACgDAEAAIAJAAIAAgbQAAgEACgCQACgCAFgBQADAAADADQACACABAEIAAAbIAFAAQAEABADACQACACAAAEQAAAEgCADQgDADgEAAIgFAAIAAANQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAQADABACADQAEAFADAIIAAhEQAAgMAMAAIAZAAQALAAAAAMIAAAhQAAALgLAAIgUAAIAABdQAAADgCACQgCABgEAAIgGgBgAgIgfIAKAAQAEAAAAgFIAAgEIgOAAgAgIg6IAAAFIAOAAIAAgFQAAgEgEAAIgGAAQgEAAAAAEgAAzBOQgFgBgBgCQgCgDABgEIAAgBIgCgBIgHgEIgCgBIAAAIQAAAEgCACQgCACgDAAQgDAAgCgCQgCgCAAgEIAAgKIgDADQgGAGgFACQgDACgCgBQgDAAgBgDIgBgGQABgDAEgBIAIgHIAFgFIgEAAQgLAAAAgMIAAgSQAAgLALAAIAKAAIAAgFIgSAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAIACgFQAAAAABAAQAAAAABgBQAAAAAAAAQAAAAABAAIASAAIAAgCQAAgEACgCQACgCADAAQADAAACACQACACAAAEIAAACIASAAQAAAAABAAQABAAAAAAQABABAAAAQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQAAABgBAAQAAAAgBAAQgBAAAAAAIgSAAIAAAFIALAAQALAAAAALIAAASQAAAMgLAAIgLAAIAAAEIACAAQACgBADABIAKAEQACADABACIAAACIACAAIADAAQADgBAAgDIAAhMIgVAAQgLAAAAgLIAAghQAAgMALAAIAaAAQAMAAAAAMIAAAgIAAAAIAABcQAAAFgDAFQgDAEgEACQgDACgEAAIgDAAIgHgBgAAhAjIAFAAQAEABAAgEIAAgBIgJAAgAAKAgQAAABAAABQABAAAAABQABAAAAAAQABAAABAAIAFAAIAAgEIgJAAgAAhAVIAJAAIAAgDQAAgDgEAAIgFAAgAAKASIAAADIAJAAIAAgGIgFAAQgBAAgBAAQAAAAgBABQAAAAgBABQAAABAAAAgAAugkQAAAEAEABIAHAAQAEAAAAgFIAAgEIgPAAgAAug6IAAAFIAPAAIAAgFQAAgEgEAAIgHAAQgEAAAAAEg");
	this.shape_27.setTransform(-89.1,-9.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#CC0000").s().p("AhEBPQgFAAgCgDQgCgDgBgEQABgDACgDQACgDAFAAIA8AAIAAgbIgwAAQgGAAgBgDQgDgDAAgEQAAgDADgDQABgDAGAAIBwAAQAFAAACADQACADAAADQAAAEgCADQgBADgGAAIgvAAIAAAbIA8AAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAgAhIAHQgDgDAAgEQAAgDACgCIAFgDIAGgCIAEAAQAGgCAGgEQAGgEAEgFIACgEIADgEIAEgEQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIADABIADACIADADIABAEQAAADgDAFIgFAIIgGAGIgFAEIgGADIgJAEIgJAEIgKACQgEAAgCgDgAAaAHQgIAAgFgFQgEgEAAgHIAAgUQAAgFACgDQADgDAEAAQADAAAEADQACADAAAFIAAAMIABAGQABAAAAAAQABABAAAAQABAAABAAQAAAAABAAIANAAIADAAIACgFQAAgEADgCIAGgCQADAAACADQADACABAFIAAAHQgBAGgEADQgEAEgIAAgAA6gZIgDgEIAAgFIAAgFQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAgBAAAAIgEAAIhmAAIgCABIgCACIAAADIAAADQAAAEgDADQgDADgEAAQgFAAgCgDQgDgCAAgFIAAgLIACgHQABgDACgDIAFgDIAGgBIAzAAIAAgHQAAgFACgDQADgCAEAAQADAAADADQADACAAAFIAAAHIAzAAQAGAAAEAEQAFAFAAAJIgBAIQABAEgCADIgDAEQgCABgEAAQgDAAgDgCg");
	this.shape_28.setTransform(-105.8,-9.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.3,-20,232.6,40);


(lib.vjv202解答消し = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("AogEdIAAo5IRBAAIAAI5g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.251)").s().p("AogEdIAAo5IRBAAIAAI5g");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.502)").s().p("AogEdIAAo5IRBAAIAAI5g");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.749)").s().p("AogEdIAAo5IRBAAIAAI5g");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AogEdIAAo5IRBAAIAAI5g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.5,-28.5,109,57);


(lib.vjv202tマイナスにならない = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC0000").s().p("AgSBKQgUAAgJgKQgLgJABgQQgBgOAMgLQALgLAQgHQgCgKgBgWIgBglIAQAAQAGgBABADQAAACgCADQAAAcACAaQAZgJAbgGIAHAUQgmADgfAPQgbAOAAANQAAALAGADQAEADANAAIBHAAIgCATg");
	this.shape.setTransform(53.8,10.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC0000").s().p("AgYA+QgoAAAEgnIAEgQIAWAFQgFAIAAAJQAAAMASAAIBSAAIAAAVgAgxgoIAAgVIBgAAIAAAVg");
	this.shape_1.setTransform(36.2,11.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CC0000").s().p("AgpBDQgggDgBhBQAAgkADgeIATAFQAFABAAADQACACgFADQgDATAAAaQgBAXAEASQADAKAFAAQAFAAAHgMIAIgRIASANIgKAXQgLASgPAAIgBgBgAAqgFQgIgUgQgUIAPgLQASASALAXQAKAWADATIgYAGQgCgTgHgSg");
	this.shape_2.setTransform(18.7,11.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CC0000").s().p("AgXBKQgLgIABgOQAAgOAOgIQAQgJAVAEIAAgoIARAAQAFAAAAACIgCAEIAAAnQAVAHARAMIgKARQgQgKgNgFQgBANgIAIQgJAJgTAAQgMAAgLgHgAgLAvQgDACAAAFQAAAEAFADQAEACAHAAQAGAAAGgEQAEgFAAgJIgHgBIgKgBQgIAAgEAEgAhLAmIATgjQAIgOAEgPIgbACIgCgVIAjgBIAKgiIAQAFQAFACAAACQAAABAAAAQAAABgBAAQAAABgBAAQgBAAgBAAIgFAUIAWgFIADAUIggAFIgPAmQgLAZgIAOgAARgmIAIgQQAcAJAXAOIgIARQgQgKgjgOg");
	this.shape_3.setTransform(0.1,10.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC0000").s().p("AgdA5QAdAAAKgBQAQgCAIgIQAFgEAAgJQAAgJgFgFQgGgGgNABQgLAAgLADQgTAHgMAOIgBAGIgUgBIAHgsIADgjIAQACQAGAAABAEQAAAAAAAAQAAABgBAAQAAAAgBABQgBAAgBAAIgFAoQAXgQAZAAQAaAAAKAKQALAKAAAQQAAARgLAMQgLAMgXACQgSADgUAAgAgOgzQgQgGgNgCIAHgSQAhAIAYALIgIASIgbgLg");
	this.shape_4.setTransform(-17.5,10.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC0000").s().p("AgXBKQgLgIABgOQAAgOAOgIQAQgJAVAEIAAgoIARAAQAFAAAAACIgCAEIAAAnQAVAHARAMIgKARQgQgKgNgFQgBANgIAIQgJAJgTAAQgMAAgLgHgAgLAvQgDACAAAFQAAAEAFADQAEACAHAAQAGAAAGgEQAEgFAAgJIgHgBIgKgBQgIAAgEAEgAhLAmIATgjQAIgOAEgPIgbACIgCgVIAjgBIAKgiIAQAFQAFACAAACQAAABAAAAQAAABgBAAQAAABgBAAQgBAAgBAAIgFAUIAWgFIADAUIggAFIgPAmQgLAZgIAOgAARgmIAIgQQAcAJAXAOIgIARQgQgKgjgOg");
	this.shape_5.setTransform(-35.9,10.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC0000").s().p("AhBhHIASAEQAGABABAEQAAAAAAAAQAAABgBAAQAAABgBAAQgBAAgBAAQgMBBAHBCIgVABQgHhMAMhDgAAWA7QgNAAgKgGQgMgHgLgKIANgPQAIAIAHAEQAIAFANAAIAxAAIAAAVgAgTgtQApgGAqABIAAAUQgrgBgoAGg");
	this.shape_6.setTransform(-53.8,11);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC0000").s().p("AgYBMQAhghgBgrQABgqghghIANgLQAkAkAAAyQAAAzgkAkg");
	this.shape_7.setTransform(128.8,-9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#CC0000").s().p("AhLAyQA/gmAdg2IhKAFIgDgVIBVgEIAFgDIANAMQAEAEAAABIgEADQgIAOgHAJIgNAUQAZARAkAkIgQANQgmglgUgPQgNAPgQAPQgPANgTALg");
	this.shape_8.setTransform(116.9,-8.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#CC0000").s().p("AgwA+QAsgbgDgvIhEAAIAAgVIBEAAIgCgrIARAAQAGAAABADQABADgEABIABAkIA/AAIAAAVIg/AAQACAigPAVQgOAUgSAOg");
	this.shape_9.setTransform(99,-8.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#CC0000").s().p("AACBNIAAhNQgZARgdAOIgOgTQAhgOAfgWQAcgWAVgdIAQAMQAKAJgOgBQgTAXgRAPIAABeg");
	this.shape_10.setTransform(80.4,-8.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#CC0000").s().p("AgFAeQgSgPgTgNIAMgOQARAKANALQAYgWAPgZIhtAEIgCgUIB8gFIAHgCIAKAJQAIAIgIgBQgWAjggAfIANANQAHAGAFAHIgQAPQgNgQgQgQg");
	this.shape_11.setTransform(62.8,-8.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#CC0000").s().p("AhUBGQALgPAKgaQAMgbADgKIgdADIgBgVIATgBIARgBQAHgVADgYIARAHQAMAGgKABIgIAdIANgBIAIABQAGABAFAFQAFAFABAKIAAAVQAAANgCAPQgCANgDAJQgEAMgJADIgJAAQgNABgQgUIAMgQQAJAMAIAAQAFABADgJQADgNAAgUQABgTgDgDQgEgDgFAAIgPABQgEAOgLAeQgNAegKARgAAVggIAPgMQAiAdAJAuIgWAHQgHgogdgegAAcg1IAMgLQAVAKAKAMIgLALQgTgQgNgGgAArhFIAKgLIAQAJQAIAEAIAJIgLALQgNgNgSgJg");
	this.shape_12.setTransform(45.4,-9.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#CC0000").s().p("AhLBRIAAgSIAYAAIAAgrQgKAIgMAGIgKgSQAPgHALgJQAQgMAFgSIgmAAIAAgSIAqAAQgFgIgHgLIAQgKQANAPAFAOIARAAQAJgNAGgTIAQAGQADABABADQAAAAAAAAQABAAAAABQAAAAgBAAQAAAAAAABIgDABIgLATIAtAAIAAASIgnAAQAQAeAiANIgNATQgIgFgMgJIAAAtIAYAAIAAASgAAXA/IAKAAIAAgoIgKAAgAgFA/IAJAAIAAgoIgJAAgAghA/IAKAAIAAgoIgKAAgAglAFIBLAAIgIgJQgJgKgGgQIgeAAQgJAagNAJg");
	this.shape_13.setTransform(27,-9.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#CC0000").s().p("AgmBQIAAg9QgOATgOAMIgMgSQAKgHAHgJQAOgPAIgSIgkAAIAAgSIAlAAIAAgRIgeABIgFgSQApgBAggJIALAPQADAFgCACIgGgBIgYADIAAAUIAiAAIAAASIgiAAIAAAMIAHADQANAHAOAOIgNAQQgKgMgLgIIAABBgAAqBPIgCgUIAMAAQABAAABAAQAAAAABAAQAAAAAAgBQABAAAAAAIAAgEIAAiCIARAAQAJABgGAFIAACGIgBAGQgCAJgLAAgAAVAtIAAhnIAQAAQAJABgGAFIAABhg");
	this.shape_14.setTransform(8.8,-8.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#CC0000").s().p("Ag0BTIAAhHIgTACQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQgDAAgBgFIgEgPIAQAAIALgMQgLgNgNgKIAJgNIAHAFIAWgkIAOAJIACADQABAAAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQgBABAAAAQgBAAgBAAIgWAeIAHAIIATgdIAOAJQASgBASgDIAAgbIAQAAQAIABgGAFIAAATQARgCAOgGIAKAPQADAFgDACQgCAAgEgCIgjAGIAAA4IAMAAIAAg1IAQAAQAIABgFAFIAABAIgfAAIAAAVIABAEQAAAAABAAQAAABAAAAQABAAABAAQAAAAABAAIALAAIADAAIABgDIADgNIASAIIgEANIgBAEQgDAEgDACQgEACgFAAIgZAAQgOAAAAgPIAAgcIgKAAIAAAMIgRAAIAAhLIAOAAQAJAAgGAFIAAApIAKAAIAAg1IghAEIgDgQIgjArIATgCIgHgMIAOgGQAMASAFAOIgPAHIgDgHIgLABIAABJgAhUBAIAGgOQAFgRAAgNIAPACQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABIABACQAAABAAAAQAAAAAAABQgBAAAAAAQgBABgBAAIgCAQQgDASgHANgAgcAYIARgCQAGAOAAAYIgSADQABgUgGgTg");
	this.shape_15.setTransform(-8.9,-9.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#CC0000").s().p("AgIBEQALgJAHgIQAMgOAAgPIAAhhIA6AAIAACOIgBAFQgDAKgKAAIgTAAIgCgWIALAAQAAAAABAAQABAAAAAAQABAAAAAAQABgBAAAAIAAgDIAAghIgTAAIAAACQAAAIgDAJQgFAVgdAVgAApAEIATAAIAAgVIgTAAgAApgjIATAAIAAgWIgTAAgAhNBDQAIgHAKgMQAHgKADgGIgeAAIAAgRIAVAAIAAg4IgQAAIAAgRIAQAAIAAgYIAQAAQAIABgFAFIAAASIAVAAIAAgZIAQAAQAHABgFAFIAAATIAPAAIAAARIgPAAIAAA4IARAAIAAARIgcAAIASARIgNAOIgUgVIANgKIgfAAIAOAIIgJAPQgLAQgMALgAgnAPIAVAAIAAgJIgVAAgAgngKIAVAAIAAgIIgVAAgAgngiIAVAAIAAgHIgVAAg");
	this.shape_16.setTransform(-27.3,-9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CC0000").s().p("AAxBOIAAgIIh1AAIAAgUIB1AAIAAgRIhsAAIAAgTIBsAAIAAgPIh0AAIAAgUIA5AAIAAg4IARAAQAIAAgCADIgCADIAAAyIAbAAIgQgJQAMgUAIgVIAQAIIACABQAEADAAACQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAgBgBQgHAQgMATIAdAAIAABjgAg9g3IARgMQAMANALAUIgSAMQgLgUgLgNg");
	this.shape_17.setTransform(-45,-9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#CC0000").s().p("AgXAAQAAgyAjgkIAMALQgfAhAAAqQAAArAfAhIgMALQgjgkAAgzg");
	this.shape_18.setTransform(-56.6,-9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CC0000").s().p("AhLAyQA/gmAdg2IhKAFIgDgVIBVgEIAFgDIANAMQAEAEAAABIgEADQgIAOgHAJIgNAUQAZARAkAkIgQANQgmglgUgPQgNAPgQAPQgPANgTALg");
	this.shape_19.setTransform(-72.1,-8.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#CC0000").s().p("AgwA+QAsgbgDgvIhEAAIAAgVIBEAAIgCgrIARAAQAGAAABADQABADgEABIABAkIA/AAIAAAVIg/AAQACAigPAVQgOAUgSAOg");
	this.shape_20.setTransform(-90,-8.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#CC0000").s().p("AACBNIAAhNQgZARgdAOIgOgTQAhgOAfgWQAcgWAVgdIAQAMQAKAJgOgBQgTAXgRAPIAABeg");
	this.shape_21.setTransform(-108.6,-8.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CC0000").s().p("AgFAeQgSgPgTgNIAMgOQARAKANALQAYgWAPgZIhtAEIgCgUIB8gFIAHgCIAKAJQAIAIgIgBQgWAjggAfIANANQAHAGAFAHIgQAPQgNgQgQgQg");
	this.shape_22.setTransform(-126.2,-8.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-137.1,-20,274.2,42);


(lib.vjv202t通常1から3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3366CC").s().p("Ag5BOIBnilIAMAKIhlClgAAaBLQgMgMAAgZQAAgZAJgJQAMgLAOAAQAQAAAKAJQALALAAAZQAAAagLALQgKAJgQABQgNgBgKgJgAAmAUQgDAGAAAMQgBAMAFAIQAEAFAHAAQAIAAAEgFQADgHAAgNQAAgNgDgHQgEgGgIAAQgJAAgDAIgAhJgBQgMgLAAgaQAAgZAJgJQAMgMAOAAQAQAAAKAKQALALAAAZQAAAagLALQgKAJgQAAQgNAAgKgJgAg9g4QgDAHAAALQgBANAFAHQAEAGAHAAQAIAAAEgGQADgHAAgNQAAgNgDgGQgEgGgIgBQgJABgDAHg");
	this.shape.setTransform(48,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3366CC").s().p("Ag3AcIAbAAQAAAgAfAAQAQAAAHgHQAGgGAAgLQAAgMgHgHQgKgKgZABIAAgWQAmAEAAgaQAAgWgcAAQgbAAACAbIgaAAQABgWAOgOQANgNAXAAQAaAAAMAMQAPAPAAARQAAALgGAIQgFAHgKAHQAYANAAAaQAAAUgNANQgMAMgcAAQg3AAgDg1g");
	this.shape_1.setTransform(28.8,-0.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3366CC").s().p("AgLAIQgMgIgMAAQgOABgQAWIgOgTQAWgdAXAAQAOAAATAMQAYANAMAAQANABAOgWIASARQgUAegZAAQgSAAgcgSg");
	this.shape_2.setTransform(10.2,-0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3366CC").s().p("AAFBPIAAh3IgiAAIAAgSQAjgCAFgSIATAAIAACdg");
	this.shape_3.setTransform(-10.3,-0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3366CC").s().p("AgJBcIAAgxIgmAAIAAAmIgWAAIAAg5IA8AAIAAgIIgoAAIAAgvIBkAAIAAAvIgnAAIAAAIIA/AAIAAAqIAAAGQgEAKgLAAIgYAAIgCgVIAPAAQAAAAABAAQABgBAAAAQABAAAAAAQAAgBAAAAIABgEIAAgMIgpAAIAAAxgAgcgCIA5AAIAAgLIg5AAgAhWgNIAAgrIApAAIgQgSIARgMQAOALAJAMIgLAHIAXAAIAAgjIASAAQAJABgGAFIAAAdIAVAAIgKgHIATgZIAQAKQACAEAAABQAAABAAAAQAAABAAAAQgBAAgBABQAAAAgBAAIgLAOIApAAIAAAqIgVAAIAAgYIiDAAIAAAZg");
	this.shape_4.setTransform(-28.1,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3366CC").s().p("AhdBEIAdgNIAAgxIgYAAIAAgTIAuAAIAABCQALANAWAAIBnAAIgDAWIhkAAQgXAAgUgSIgdAVgAAvBAIgDgWIAKAAQABAAABAAQABAAAAAAQAAgBABAAQAAAAAAgBIABgEIAAgGIgaAAIAAAcIgVAAIAAgcIgWAAIAAAfIgVAAIAAhnIAwAAIgcgMIAPgPIglAAIAAgTIBdAAIACgCIARAMQABABAAAAQAAAAAAABQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBABIgDAAIgfATIAIAEIgJAHIAiAAIAABZIAAAHQgEAKgLAAgAAhALIAaAAIAAgIIgaAAgAgKALIAWAAIAAgIIgWAAgAAhgPIAaAAIAAgJIgaAAgAgKgPIAWAAIAAgJIgWAAgAAbg+IAJgHIgcAAgAhRhIIAPgRQARANAPAQIgSASQgMgRgRgNg");
	this.shape_5.setTransform(-47.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59.1,-12,118.2,24);


(lib.vjv202q範囲 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("AtSFpIAArRIalAAIAALRg");
	this.shape.setTransform(85.1,36.1);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.vjv202q誤答メッセージ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		playSound("vjvq_wWAV");
	}
	this.frame_19 = function() {
		this.gotoAndStop(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(4).call(this.frame_5).wait(14).call(this.frame_19).wait(1));

	// レイヤー 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#990000").s().p("AgkBCQgHgDgGgHQgEgFgEgIQgDgGgDgKIgDgPIgBgZIABgaIABgGIABgHIABgHQABgJAJAAQAEAAADADQACADAAAEIAAACIAAAFIgBAEIAAADIgBAIIAAADIAAACIgBACIAAAMIAAANIABALIACAMQABAJAEAHIADAGIAFAFQAGAFAGgDQAEgCAEgFQADgDACgFQADgGAFAAQAEAAADADQADADAAAEIgBAFQgEAIgGAHQgFAHgIADIgFABIgGABQgHAAgGgDgAA4AtQgIgCAAgIIAAgBIAAgBQABgTgDgRQgCgKgEgIQgDgJgFgIIgDgEIgDgEQgEgFAEgHQAEgHAIAEIADACIACACQAHAJAFAKQAFALADALQAGAVgBAXIAAAEIAAADIgBAFQgDAFgGAAIgCAAg");
	this.shape.setTransform(85.1,9.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#990000").s().p("AgFBNIgHAAIgDAAIgEAAIgNgCQgOgEgGgOQgFgMADgMQADgNAKgHIAGgEQAGgBAEADQAEADAAAGQAAAEgFADIgCABQgFADgCAHQgBAJAEAFQADADAFABIAIABIALAAIA1AAQAEAAADADQADADAAAEQAAAEgDADQgDADgEAAIg1AAgAAfAZQgDAAgDgEIgNgVIgMgWIgFABIgFAAIgFAAIgFABIgFAAIgDAAIgEAAIgGAAIgOABIgCAAIgHAAQgDAAgDgDQgGgFAFgHQACgDAEgCIADAAIAEAAIACAAIAGAAIAGAAIALgBIAGAAIADAAIADAAIADgBIADAAIAFAAIgCgGIgCgFIgDgLQgBgEACgDQABgEAEgBQAIgDAEAJIAAABIABABIABADIABADIABADIABAEIAEAMIAYgCIALgBIAGgBIAFgBIACAAIAFABQAFADABAGQAAAGgFADIgEABIgEAAIgBABIgJABIgFAAIgEAAIgSACIAEAIIACADIABACIABACIABACIACAEIADADIAFAIQADADgBAFQAAAEgEADQgCABgDAAIgDAAg");
	this.shape_1.setTransform(69.7,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#990000").s().p("AAJBNQgGAAgGgCQgFgCgGgEQgFgEgEgGQgEgHAAgIQAAgPAOgMQACgDAFAAQADAAADACQADADAAAFIgBADIgCAEIgCACIgCACIgCAEIAAAEQgBAGAFAEQAEAEAHAAIAzAAQAEAAADADQADACAAAFQAAADgCAEQgDACgFABgAhDBKQgDgCAAgEIABgFIABgEIABgFIABgEIAKgpIAIgmIgRAAQgEAAgDgEQgDgCAAgEQAAgFACgCQADgDAFAAIAUAAIAAgDIABgDIAAgDIABgGQAAgGADgDQACgDAGAAQADAAADADQAEADAAAGIAAADIgBAFIgBAEIAAADIAnAAQAEAAADADQADACAAAFQAAADgDADQgDAEgEAAIgrAAQgDAagHAXIgMAxQgBADgDACQgDADgDAAQgEAAgDgDgAAAAAQgDAAgDgCQgDgDAAgEQAAgEADgDQADgDADAAIA1AAQAEAAADADQADADAAAEQAAAEgDADQgCACgFAAgABAgxIgDgFIgDgGQgCgDAAgCQAAgEACgCIAEgCIAFABQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABIADAFIAEAGIABAEQAAADgCACQgCACgEAAQgDAAgCgCgAApgxIgDgFIgEgGQgCgDABgCQgBgEACgCIAGgCIADABIADADIADAFIADAGIABAEQAAADgCACQgBACgDAAQgEAAgCgCg");
	this.shape_2.setTransform(53.5,9.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#990000").s().p("AAtBKIgCgBIgKgIIgNgKIgHgFIgHgFIgNgJIgEgCIgDgCIgCgBIgCgBIgEgDIgUgLIgCAAIgFgCIgCgCIgCgBQgGgFAAgGQgBgHAFgFIAFgEIAEgCIAGgDIAGgDIADgCIADgCIAGgDIAWgOIAEgDIAFgDIAJgFIAEgDIAFgDIAIgHIADgCIADgDQAHgDAGAFQAGAHgGAGIgDADIgCACIgCABIgLAJIgMAIIgMAIIgDABIgCABIgCABIgFAEQgRALgSAIIAUAKIACABIADACIAEACIAJAGIALAIIALAHIAWAQIADACIAEADIACACIABABIACACQAEAGgFAGQgDAEgEAAIgBAAQgDAAgCgCg");
	this.shape_3.setTransform(39,9.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#990000").s().p("AAVBDIgFgBIgFAAIgJgCQgJgCgIgGQgIgFgGgIQgGgJgBgJQgCgJACgLQACgKAFgIQAEgIAHgJQAHgIAKgHIgfABIgEAAIgEAAIgIAAIgEAAIgEAAIgEAAIgEAAQgHABgDgGQgCgFADgEQACgFAGAAIAFAAIAGAAIAMgBIAXAAIAtgCIAggBQAGAAACAGQADAFgDAFQgCACgDABIgGABIgDAAIgCAAQgIABgKADIgEACIgEADIgFACIgEACIgDADIgBABIgCABIgGAFQgFAFgFAHQgFAHgCAGQgDAIAAAHQAAATARAHQAGADAIABIAOABIAJAAIACABQAIAAACAHQACAHgGAEIgGACIgSgBgAA/gIIgBgBIgBgCIgBgCIgCgDIgCgDIAAgDQAAgIAHAAQAEAAACAEIAFAIIABADIAAAAIABABIAAADQAAAHgHAAQgEAAgCgEgAAogIIAAAAIgHgLIgBgDQAAgIAIAAQAEAAACAEIAFAIIABADIAAAAIABAEQAAAHgHAAQgEAAgCgEg");
	this.shape_4.setTransform(24,9.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#990000").s().p("AATBLQgGgCgEgEQgEgEgCgGQgCgGgBgGIACgNIABgTQAAgGgDgEQgCgEgFAAQgGAAgHADQgGADgEAHIgFAIIgFAJIgDAIIgEAJIgCAEIgBAFIgCAFIgCAEQgBADgDACIgGACQgJAAgBgLIABgFIAFgJIAEgLIAGgOIAIgXIAIgXIAHgXIAHgXQACgFADgBIAFgCQAEAAADADQADADAAAEIgCAIIgDAMIgFAQIgGARQAJgDAIAAQAHAAAFACQAGADAEAEQAEAFACAFQACAGAAAIIgBAQIgCAOQABAGADADQADADAEAAQAGAAAEgFQAFgEACgGIAFgMIABgIIABgFIACgEIACgDIAGgCQAEAAADADQADADAAAEQAAAKgDAKQgDAKgFAJQgGAJgIAFQgIAGgLAAQgGAAgGgDg");
	this.shape_5.setTransform(7.8,9.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#990000").s().p("AhMBMQgCgDgBgDQAAgFAHgEIAFgEIAFgEIACgDIABgEIAAgxQAAgGgDAAIgGAAQgEAAgEgCQgDgDAAgEQAAgFADgCQAEgDAEAAIAMAAQAIAAAEAFQAFAEgBAHIAAA0QACAFAFAEQAFAFAHACQAIACARAAIAlAAIAcgBQAEAAADADQADACABAFQAAAEgEADQgCACgEABIgoAAIgjgBIgMgBQgHAAgGgCQgGgCgEgDQgFgCgCgEIgFAGIgGAFIgGAEIgGABQgDAAgDgCgABAA3IgNgGIgKgEIgHgDQgDgCAAgDIABgFIADgDIgcAAIACADIABAEQAAADgEAEIgIAFIgLAEIgJACQgEAAgCgDQgDgCAAgEQAAgEADgCIAFgDIAIgCQAFgBAGgEIgVAAQgEAAgCgCQgCgCgBgEQAAgDACgCQADgCAEgBIARAAIAAgHIgOAAQgDAAgDgCQgCgCAAgDQAAgDACgDQACgCAEAAIAOAAIAAgCIAAgCIABgCIABAAIgJgBQgEAAgEgCQgDgBgCgDQgDgDAAgGIAAgNQAAgFAEgEQADgDAGgBIAOAAIAEAAQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAgBIAAgCIgDgBIgVAAQgEAAgCgCQgCgCAAgDQAAgDACgCQADgCADAAIAdAAQAFAAADADQAEACAAAGIAAAMIgBAFIgEADIgDADIgFABIgNAAIgEAAQAAAAgBABQAAAAAAAAQAAABAAAAQgBABAAABIAAADIABACIAEABIAGAAIADAAIACAAIACgBIABgCQAAgDADgDQABgCAEgBQAEAAADACQACACAAAEQAAAIgCAEQgCADgCACIgFACIgFABIADADIABAEIAZAAIABgEIACgDQgEAAgDgCIgDgEIgCgEIgBgFIAAgNQAAgFAEgEQADgDAGgBIAPAAIADAAQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAAAAAIgDgBIgWAAQgDAAgCgCQgDgCAAgDQAAgDADgCQACgCADAAIAfAAQAEAAADADQAEACAAAGIAAAMIgBAFIgDADIgEADIgDABIgQAAIgEAAQAAAAAAABQAAAAAAAAQAAABAAAAQgBABAAABIAAADIABACIAEABIAGAAIADAAIACAAIADgBIACgCQAAgDABgDQACgCAEgBQADAAADACQACACAAAEIgBAJIgCAGQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAAAAAIgEACIgGABIgLABIABAAIACACIABACIAAACIAOAAQADAAADACQACACAAAEQAAACgCADQgCACgEAAIgOAAIAAAHIASAAQADAAACACQACACABAEQAAADgDADQgCACgDAAIgUAAIAIADIAIAEIAIAEQADADAAADQAAADgCACIgDAEIgFABIgEgBgAAJANIAZAAIAAgHIgZAAgAgygrQgCgBgCgCIgIgFIgHgEIgEgEQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAgBQAAgDADgEQACgDAEAAIAGACIAJAFIAJAHQADAEAAADQAAAEgCACIgDADIgEABIgCAAg");
	this.shape_6.setTransform(-8.7,9.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#990000").s().p("AAPAXQgFgBgCgDQgKgRgQgIQgEgCgBgEQgBgEADgDQADgDAEAAQADAAAFACQAQAJALAQQADAGAAAEQAAAEgDADQgCABgDAAIgBAAg");
	this.shape_7.setTransform(-26.1,13.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#990000").s().p("ABCBQQgWgEgWgIIgEgCIgSAGQgRAEgZAEQgEAAgDgDQgCgDAAgEQAAgEADgDQACgDAFABQAXgDANgDIgRgLQgEgCgBgEQAAgEABgDIgHAAQgDAAgDgCQgCgDAAgDQAAgEACgCQACgCAEAAIBVAAQAGAAAEADQADADABAFQABAEgDAGIgLALIgLAIQAMADAQADQAFAAACAEQACADAAAEQgBAFgEACQgDACgDAAIgCgBgAATAvIAPgIIAHgFIAAgCIgEgBIgtAAQAOAKANAGgAhJBMQgEgDAAgDQgBgDADgFQADgKACgMQACgOAAgPIAAg7QAAgHAFgFQAEgFAIAAIAzAAIAAgFQAAgEACgDQADgDAEAAQAEAAADADQADADAAAEIAAAFIAxAAQAEAAADACQADADAAADQAAAFgDACQgDACgEAAIgSAAIABAEIAAAHIAPAAQAEAAADADQACACAAAFQAAADgCADQgDADgEAAIgPAAIAAALQAAAHgEADQgEAEgHAAIgtAAQgGAAgEgDQgDgEAAgFIAAgNIgPAAQgEAAgDgDQgDgCAAgEQAAgEADgDQACgDAFAAIAPAAIAAgIIAAgDIgVAAQgBAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAABQgBAAAAABQAAAAgBABQAAAAAAABQAAABAAAAIAAA7IgBAVQgBALgDAJIgFAPQgDAEgEABIgBAAIgGgCgAgDgOQAAADACACQABACADAAIAVAAIAGgCQACgCAAgEIAAgDIgjAAgAgDgtIAAAIIAjAAIAAgHIAAgEIgjAAIAAADg");
	this.shape_8.setTransform(-38.2,9.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#990000").s().p("AhDAKQgFAAgCgDQgDgDAAgEQAAgDADgDQACgDAFAAICHAAQAFAAACADQADADAAADQAAAEgDADQgCADgFAAg");
	this.shape_9.setTransform(-55.2,9.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#990000").s().p("AgSBMIgFAAQgFAAgEgFIAAgBQgCgDABgDIAAgBQACgEAEgCIABgBIAAAAIACAAIAAAAIAEAAIANgBIALgBIAEgBIAEgBIAEgBIAEgBIAKgFQAFgDADgEIACgHIACgGQABgGAAgIQAAgIgDgGIgDgEQgEgHgIgCIgIgBIgEABIgEAAIgBAAIgGABIgEABIgNABIgEAAIgFABIgJABIgEABIgEAAIgFABIgEAAIgFAAQgGgCgBgFQgBgGAFgDIAFgDIAZgDIAMgCIADAAIADgBIAGAAIAEgCIAHgBIAIAAQAIAAAHABIAAAAIAFACIAEACQALAFAGALQAEAIACAIQAEAVgIAUQgCAFgDAEIgIAJIgKAGIgLAEIgLAEIgKABIgIABIgEAAIgFABIgEAAgAAbgvQgLgEgPgBIgQgCIgFAAIgEAAIgJAAQgEAAgDgDQgDgDAAgFQAAgDADgEQADgDAEAAIASABIADAAIACAAIAFAAIAEABIAEAAIAXAFIAEABIAEABQAGADAAAGQAAAFgEAEQgDACgDAAIgDgBg");
	this.shape_10.setTransform(-70.8,9.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#990000").s().p("AAUBMIgEAAIgEAAIgEAAIgCAAIgDgBQgKAAgIgFQgFgDgEgHQgEgEgDgHQgCgHgBgJIAAgJIAAgHIgZAAQgEAAgDgDQgDgDAAgFQAAgDADgDQADgDAEAAIAZAAIAAgZIgZAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIAZAAIAAgSQAAgDADgEQADgDAFAAQAEAAADADQADAEAAADIAAASIAuAAQAEAAADADQADACAAAFQAAAEgDADQgDADgEAAIguAAIAAAZIAoAAQAEAAADADQADADAAADQAAAEgDAEQgDADgEAAIgoAAIAAANIAAAFQAAAHAEAGQADAFAHACIADABIADAAIAAAAIADAAIADAAIALAAQAHAAAFgCQAEgDAEgDQADgEABgFIACgMIgBgLIAAgBIAAgBIAAgCIABgBIAAgBIADgDIABgBIABAAIAFgBIABAAIAEACIABAAIACAFIABABIAAAGIABAMIgCAMIgDAKQgDAFgDADQgGAGgIAFQgKAEgLAAIgEAAg");
	this.shape_11.setTransform(-85.5,9.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#990000").s().p("AgIAVQgEgCgDgDQgDgDgCgEIgCgJQAAgDACgFQACgEADgDQADgDAEgCQAEgCAEAAIAJACIAHAFIAFAHIACAIQAAAFgCAEQgCAEgDADIgHAFQgEABgFAAQgEAAgEgBgAgGgGQgCADAAADQAAAEACADQADACADABQAEAAACgDQADgDAAgEQAAgDgDgDQgCgCgEAAQgDAAgDACg");
	this.shape_12.setTransform(24.5,-5.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#990000").s().p("AglBNQgDgCAAgFQAAgFACgDQACgCAFgBIAJgBIAMgEQAFgBAFgEQADgDADgFQgGACgHAAQgHAAgIgCQgGgDgFgFQgFgEgDgHQgDgGAAgIQAAgHADgGQACgHAGgFQAFgFAGgDQAHgDAIAAQAHAAAGADIAAgIIhHAAQgDAAgDgDQgEgDAAgEQAAgEADgDQADgDAEAAIBHAAIAAgPQAAgEADgDQADgDAFAAQADAAADACQACADABAFIAAAPIAoAAQAEAAADACQACADAAAFQAAAEgCADQgDADgEAAIgoAAIAAAfIADAKIAAANQAAAIgBAHQgBAHgDAGQgDAGgEAFQgFAFgHAEIgHAEIgKADIgKACIgHABQgEAAgEgCgAgOgHIgGAEIgDAEIgBAGQgBAEACADIAEAGIAFADIAHABIAHgBQABgBADgCQADgDAAgEIABgIIAAgCIAAgCQgDgEgEgDQgEgCgFgBIgGACg");
	this.shape_13.setTransform(12.8,-9.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#990000").s().p("AAVBDIgFgBIgFAAIgJgCQgJgCgIgGQgIgFgGgIQgGgJgBgJQgCgJACgLQACgKAFgIQAEgIAHgJQAHgIAKgHIgfABIgEAAIgEAAIgIAAIgEAAIgEAAIgEAAIgEAAQgHABgDgGQgCgFADgEQACgFAGAAIAFAAIAGAAIAMgBIAXAAIAtgCIAggBQAGAAACAGQADAFgDAFQgCACgDABIgGABIgDAAIgCAAQgIABgKADIgEACIgEADIgFACIgEACIgDADIgBABIgCABIgGAFQgFAFgFAHQgFAHgCAGQgDAIAAAHQAAATARAHQAGADAIABIAOABIAJAAIACABQAIAAACAHQACAHgGAEIgGACIgSgBgAA/gIIgBgBIgBgCIgBgCIgCgDIgCgDIAAgDQAAgIAHAAQAEAAACAEIAFAIIABADIAAAAIABABIAAADQAAAHgHAAQgEAAgCgEgAAogIIAAAAIgHgLIgBgDQAAgIAIAAQAEAAACAEIAFAIIABADIAAAAIABAEQAAAHgHAAQgEAAgCgEg");
	this.shape_14.setTransform(-3.6,-9.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#990000").s().p("ABEBQQgDAAgEgEIgLgJQgEgDgBgEQgBgEADgDIACgDIgYAAIACACQADADAAAEQAAADgEAEQgHAGgKAGQgFACgDgBQgDgBgCgEQgCgDABgEQABgDAEgDIANgKIACgBQgEgBgDgDQgFgFAAgFIAAhEQAAgFAFgFQAEgEAGAAIAJAAIAAgCIACgHIAAgBIgWAAQgEAAgCgCQgCgCAAgFQAAgDACgDQACgDAEAAIA/AAQAEAAADADQACACAAAEQAAAEgCADQgDACgEAAIgVAAIgBAFIgCAFIAOAAQAGgBAEAFQAEAFAAAFIAABEQAAAFgEAFQgEAEgGAAIABABQAGAEAIAIQADAEAAADQAAAEgDADQgCADgEAAIgBAAgAAWAaIABAFQABAAAAAAQABABAAAAQABAAAAAAQABAAABAAIAVAAQADAAACgBQACgCAAgDIAAgDIgiAAgAAWAGIAiAAIAAgIIgiAAgAAXgbQgBACAAADIAAADIAiAAIAAgDQAAgBAAgBQAAAAgBgBQAAAAAAgBQAAAAgBgBQgCgCgDAAIgVAAQgBAAgBAAQAAAAgBABQAAAAgBAAQAAAAgBABgAg3BMQgMAAAAgLIAAgeIABgFIgGAAQgDgBgCgEQgCgDABgEQABgDAEgCIALgEIALgFIgEgBQgEgCgCgCIAAgDIgBAAQgEACgDAAQgDgBgCgCQgCgDAAgEQABgDADgCQAEgCACgCIAFgIQABgEAEgDQADgDAHgBIAVAAIAIAAIAAgBIAAgEQgBgEgDAAIghAAQAAAAgBAAQgBAAAAABQgBAAAAAAQAAABgBAAQAAABgBAAQAAAAAAABQgBAAAAABQAAABAAAAIAAAFQAAAEgCADQgCACgEAAQgEAAgCgCQgDgDAAgEIAAgMQAAgFAFgFQAFgFAGAAIAOAAIAAgEQAAgFACgCQADgDAEAAQADAAADADQADACAAAFIAAAEIAPAAQAEAAAEACQADADACAEIABAHQAAAGAAAGQgBAEgDACIgEABIgCAKQgEAKgFAIIgCACIATAKQADACABAEQABAEgCADQgCADgDABQgEABgEgDIgWgNQgIAGgJAFIAfAAQAMAAAAAMIAAAeQAAALgMAAgAgxArIAAAOQAAADADABIAQAAQAEAAAAgEIAAgOQAAgEgEAAIgQAAQgBAAAAAAQgBABAAAAQgBABAAAAQAAABAAABgAgvgWIgFAIIADABIAOAGIAGgJQACgDgCgDQAAgBAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgHAAQgFAAgCACg");
	this.shape_15.setTransform(-20.5,-9.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#990000").s().p("AhEBOQgEAAgDgDQgCgDAAgEQAAgEACgDQADgDAEABIAUAAIgCgEIgFgIQgDgDABgEQAAgEAEgDQADgDAEABQADAAAEAEIAHANQACAEgBADIgCAEIAXAAIAAggIg0AAQgFAAgCgDQgDgCAAgFQAAgDADgEQACgCAFAAIA0AAIAAgRIgdAAQgEAAgDgCQgDgDAAgEIAAgCIgPAIQgEABgEgBQgEgBgBgFQgCgDABgFQACgDAEgCQAYgJANgKQAPgKAMgNQAEgDAEAAQAEAAAEACQANAOAPALQANAJAYAJQAEACABAEQABADgBAEQgCAFgEACQgDAAgFgBIgQgJIAAADQAAAEgDADQgCACgEAAIgeAAIAAARIA2AAQAEAAACACQADADAAAEQAAAFgDACQgCADgEAAIg2AAIAAAgIAQAAIAAgBIAHgMIAFgJQACgEAEgBQADgBAEABQAEABABAEQABAEgCAEIgGALIgBADIAWAAQAEgBADADQADADAAAEQAAAEgDADQgCACgFABgAgEg1QgKALgQALIgGADIBJAAIgFgCQgSgMgKgMQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBgBAAQgCABgCACg");
	this.shape_16.setTransform(-37.4,-9.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#990000").s().p("AAUBNIgCAAIgFAAIgEAAQgHgBgFgDIgEgCIgFgDQgJgHgCgMQgCgJAEgJQADgIAHgGQADgDAEAAQAEAAADADQACACAAAFQABADgDADIAAABIgDADIgBACQgCADgBAEQABAHAEADQAFADAHABIAHAAIAsAAQAEAAACADQADACAAAEQAAAKgKABgAg9BMQgFgCgBgFIAAgHIABgDIACgFIABgEIAKgoIACgKIABgEIABgFIADgUIgQAAQgEAAgDgEQgDgDAAgDQAAgFADgCQADgDAEgBIAUAAIABgGIAAgHIABgBIAAgBIAAgDQACgIAIAAQAFAAACADQADADAAAEIAAACIgBAHIgBAHIAoAAQAEABADADQADACAAAFQAAADgDADQgDAEgEAAIgrAAIgBAJIgBACIgBACIAAAGIgBAEIgBAFIgCAJQgCAPgFAOIgBAEIgBADIAAAEIgBAEIgBADIgBAFIgDAGIAAACIgBABQAAAEgDACQgDACgDAAIgEgBgAADAAQgDAAgDgCQgDgDAAgEQAAgEADgEQADgCADAAIA1AAQAEAAADACQADADAAAFQAAAEgDADQgDACgEAAg");
	this.shape_17.setTransform(-53.9,-9.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#990000").s().p("AgJA3IgGAAIgDAAIgCgBIgCgBIgCgBIgBgBIgBgCIgBgCIAAgFIABgBQADgFAGAAIADAAIAGAAIAGAAIACAAIADgBIAGAAIABAAIABAAQARgDALgOQADgDACgGIACgKQABgGgBgGQgBgGgDgFQgFgIgLgCIgKAAIgKABIgeAGIgPADIgHABIgEABIgEAAIgEAAIgBAAQgDgCgCgDIAAgBQgBgDABgDIAAgBQADgFAEAAIAfgHIAEAAIACgBIACAAIAEgBIAEAAIAEgBIACAAIACgBIADgBIACAAIABAAQAMgCAMABQAPACAKAKQAHAIAEAMQACALgBALIgDAOQgCAHgDAFIgCACIgBACQgJAKgMAGQgMAGgOABIgBAAIgFAAIgDABIgHAAg");
	this.shape_18.setTransform(-69,-7.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#990000").s().p("AgPBNQgEgCAAgEQgCgEACgDQABgEAFgBIAJgFIAJgIQADgEAEAAQAEAAADADQADADAAADQAAAFgDADQgIAIgHADQgFAFgGACIgEABIgEgBgAA8BKQgKgJgHgEQgEgCgCgEQgBgEACgDQACgEAEgBQADgBAFACQAKAFALALQAEADAAAEQAAAEgDADQgDADgDAAQgEAAgEgDgAg+BLQgNAAAAgMIAAgfQAAgLANAAIAcAAQAMAAAAALIAAAfQAAAMgMAAgAg5ApIAAANQAAABABABQAAABAAAAQABAAAAABQABAAABAAIAKAAQAAAAABAAQABgBAAAAQABAAAAgBQAAgBAAgBIAAgNQAAAAAAgBQAAgBgBAAQAAgBgBAAQgBAAAAAAIgKAAQgBAAgBAAQAAAAgBABQAAAAAAABQgBABAAAAgAgKAoQgEAAgCgDQgDgCAAgFQAAgDADgDQACgDAEAAIBAAAIAAgGQAAgHgHABIgsAAQgGgBgFgEQgFgFgBgHIAAgsQABgEACgDQACgCAEgBQAEAAACADQADADAAAEIAAAkQAAADABACQACACADAAIAtAAQAIAAAFAGQAEADAAAIIAAAOQADAAACACQADACAAAEQAAAEgDADQgDADgEAAgAhCAOQgEAAgCgCQgCgDgBgEQAAgDADgCQACgCAEAAIAjAAQAEAAADACQACABAAAEQAAAEgCACQgDADgEAAgAhCgKQgEAAgCgCQgCgCgBgEQAAgEADgCQACgDAEAAIAjAAQAEAAADACQACADAAAEQAAADgCADQgDACgEAAgAAVgUQgMAAABgMIAAghQgBgMAMAAIAkAAQAMAAAAAMIAAAhQAAAMgMAAgAAcg3IAAANQAAAEADAAIAQAAQAEAAABgEIAAgNQgBgEgEAAIgQAAQgDAAAAAEgAhGgiQgDAAgDgCQgCgDgBgEQABgEACgCQADgDADAAIAsAAQAEAAACADQACACABAEQgBAEgCACQgCADgEAAgAhCg6QgEAAgCgCQgCgDgBgEQAAgDADgDQACgCAEAAIAjAAQAEAAADACQACACAAAEQAAAEgCACQgDADgEAAg");
	this.shape_19.setTransform(-84.7,-9.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},3).wait(17));

	// レイヤー 7
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#CC3333").ss(1,1,1).p("AwFDwIAAnfMAgLAAAIAAHfg");

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFCCCC").s().p("AwFDwIAAnfMAgLAAAIAAHfg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_21},{t:this.shape_20}]},3).wait(17));

	// レイヤー 8
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#CCCCCC").s().p("AwFDwIAAnfMAgLAAAIAAHfg");
	this.shape_22.setTransform(4,4);
	this.shape_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_22).wait(3).to({_off:false},0).wait(17));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.vjv202Q選択Box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF9900").ss(2,1,1).p("AFFhjIAADHIqJAAIAAjHg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AlEBkIAAjHIKJAAIAADHg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33.5,-11,67,22);


(lib.vjv202括線 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000066").s().p("AobAKIAAgTIQ3AAIAAATg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-1,108,2);


(lib.vjv202キャラB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgLAHIgBgHQAAgOAKAAQARAAgCAOQAAAPgNAAQgJAAgCgIg");
	this.shape.setTransform(27.9,-33.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgLAHIgBgHQAAgOAKAAQARAAgCAOQAAAPgNAAQgJAAgCgIg");
	this.shape_1.setTransform(6.2,-32.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAeAQQgVgGgXACQgeADgHAEQgJABgBgJQAAgEAcgJIAIgEQAXgHASgEIAFgBIANgCQAQgBAIAPQADAGABAIQABAMgJABQgEAAgUgFg");
	this.shape_2.setTransform(27.3,-40.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag9AKQAAgJADgGQAGgPAQAAIANAAIAGABQASACAXAFIAJADQAdAIAAADQAAAIgJAAQgJgDgdAAQgYAAgTAHQgUAHgEAAQgJAAAAgLg");
	this.shape_3.setTransform(3.2,-38.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1.5,1,1).p("AgTg8QgdAxAFAwQAMAWAfACQAcgGAQga");
	this.shape_4.setTransform(15.3,-26.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1.5,1,1).p("Ag4AHQAygSA/AH");
	this.shape_5.setTransform(19.3,-5.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1.5,1,1).p("AEKAEIAAB9QgBBUg5AuIhaBGQhIAahKgGIiFg3QhJgogHhNIgWiPQgPj5B4hrQCagzCdArQBeBxATDdg");
	this.shape_6.setTransform(16,-29.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFD9B2").s().p("AgcFdIiFg3QhJgogHhNIgWiPQgPj5B4hrQCagzCdArQBeBxATDdIAAB9QgBBUg5AuIhaBGQg6AWg8AAIgcgCg");
	this.shape_7.setTransform(16,-29.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1.5,1,1).p("AEghhQBAAWgXBSQgdA4g8AIIAAh5QAVgpAbgGgAkAgWQghgwgbADQgmAYAoBfQAjA6ArgPg");
	this.shape_8.setTransform(17.3,-24.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFD9B2").s().p("Ak6A0QgohfAmgYQAbgDAhAwIAUB1QgJADgIAAQghAAgcgugADwgyQAVgpAbgGQBAAWgXBSQgdA4g8AIg");
	this.shape_9.setTransform(17.3,-24.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1.5,1,1).p("Ahni2QAwgnAqAZQCOgTBTA7QA9BCApBaIgaAFIAfAvIgZAHIAaAmIgXAMQAUAYgOA4IoVASQg7g5ABhHIgfgFQBukPBqAPg");
	this.shape_10.setTransform(15.3,-49.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AkfBPIgggFQBukPBqAPQAwgnAqAZQCOgTBSA7QA+BCApBaIgaAFIAfAvIgZAHIAZAmIgWAMQATAYgNA4IoVASQg7g5AChHg");
	this.shape_11.setTransform(15.3,-49.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1.5,1,1).p("AgiATQAGgogFgpQAvgSAVAWIgFBAQgMAnguAag");
	this.shape_12.setTransform(20.2,7.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFD9B2").s().p("AgiATQAGgogFgpQAvgSAVAWIgFBAQgMAnguAag");
	this.shape_13.setTransform(20.2,7.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1.5,1,1).p("AAsg5IAThQQAMhagXgIIg0gBQgNARgMAjIgSBfIAVgaIAAA+IASABIgPDFQAnhfAYhrgAgWhzIAUgYIAWApIgYAuAgWg1QgTA8gZBvQgBA3ADBAQAYgsAVgwAgrhZQgUBTgDB8AAUhiIAYAp");
	this.shape_14.setTransform(17.7,28.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFE47F").s().p("AgqBFQAYhtASg+IATACIgTgCIAAg9IAVgZIAXApIgZAvIgQDEQgTAwgZAtQgChAABg4g");
	this.shape_15.setTransform(15.4,33.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgEgGIAYguIgWgpIgUAYIgVAaIAShfQAMgjANgRIA0ABQAXAIgMBbIgTBQIgYgqIAYAqQgYBqgnBfgAgrgrIAVgaIAAA+QgTA8gZBvQADh9AUhSg");
	this.shape_16.setTransform(17.7,24.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1.5,1,1).p("AgBjmQgrATgrBPIAUAYIgbALQgVCvAwCZQCHipAah6IgegZIAmgWQgLhuglgNg");
	this.shape_17.setTransform(18.1,29.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#596580").s().p("AhehhIAbgLIgUgYQArhPArgTIA3AAQAlANALBuIgmAWIAeAZQgaB6iHCpQgwiZAVivg");
	this.shape_18.setTransform(18.1,29.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1.5,1,1).p("AgRk8IA+AZQAhAHAvgBQAgAMAHBeQAeBuAyBcQgPA3iXB5IAeB0ABLBYIAvhKQgOgXgMgbQgUgogQguABLBYQAHhGAOg2ABODHIgJgjQACgoAEgkAjkE+QgijVAqkU");
	this.shape_19.setTransform(26,39.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#596580").s().p("AjcisIDLiRIA+AaQAhAHAvgBQAgAMAHBeQAeBtAyBdQgPA2iXB6IAeB0IlQADQgijVAqkVgABFCkIAJAjIgJgjQACgoAEglQgEAlgCAoIAAAAgABggkQgOA2gHBFIAvhJQgOgXgMgbQgUgpgQgtQAQAtAUApg");
	this.shape_20.setTransform(26,39.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1.5,1,1).p("AgLBiIA5ipAB0j+Qg7Agg0AGQgjAJABAuIhWEEQAYBaBNBBIA4gfIg1h9QgggPgeAN");
	this.shape_21.setTransform(4.2,33.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#596580").s().p("AhzBjIBWkEQgBgtAjgJQA0gHA7gfIhGC2Ig5CpIgDgBIAAAAQgQgHgPAAIAAAAIAAAAQgNAAgMAFIgBAAIAAAAIgBAAIgBABIABgBIABAAIAAAAIABAAQAMgFANAAIAAAAIAAAAQAPAAAQAHIAAAAIADABIA1B+Ig4AeQhNhBgYhag");
	this.shape_22.setTransform(4.2,33.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgCAPQgJgCgBgIIAAgHQACgNAKABQARADgFANQgBANgLAAIgCAAg");
	this.shape_23.setTransform(27.8,-34.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgCAPQgJgCgBgIIAAgHQACgNAKABQARADgFANQgBANgLAAIgCAAg");
	this.shape_24.setTransform(6.2,-36.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AA0AWQgEgBgTgIQgUgIgXgCQgegBgIADQgJgBAAgHQAAgEAegHIAJgCQAWgEAUgBIAFAAIANAAQAQABAFAQQADAGgBAJQAAALgIAAIgBAAg");
	this.shape_25.setTransform(30.3,-38.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AA0AWQgIgFgdgEQgYgDgUAEQgVAEgEgBQgJgBACgLQABgHAEgIQAIgOAQADIAOACIAFABQARAFAXAJIAHAEQAdALgBAEQgBAHgHAAIgCAAg");
	this.shape_26.setTransform(6.3,-41.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1.5,1,1).p("AgGg9QgjAsgCAxQAJAXAfAGQAbgBAUgX");
	this.shape_27.setTransform(16.1,-25.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#000000").ss(1.5,1,1).p("AhYgJQBCAuBvgx");
	this.shape_28.setTransform(18.1,-10.3);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1.5,1,1).p("AEHArIgRB7QgNBTg/AmIhjA4QhKAPhKgQIh7hKQhDgyAFhNIgCiQQAVj6CGhYQCegcCXBBQBNB9gODeg");
	this.shape_29.setTransform(17.5,-28.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFD9B2").s().p("AhNFWIh7hKQhDgyAFhNIgCiQQAVj6CGhYQCegcCXBBQBNB9gODeIgRB7QgNBTg/AmIhjA4QgkAIgjAAQgnAAgmgJg");
	this.shape_30.setTransform(17.5,-28.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(1.5,1,1).p("AEngzQA8AfgjBOQglAzg8AAIASh4QAagmAcgCgAj+g3Qgag0gbgBQgpASAaBkQAaA+AsgIg");
	this.shape_31.setTransform(18.6,-23.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFD9B2").s().p("ADxgLQAagmAcgCQA8AfgjBOQglAzg8AAgAlCAKQgahkApgSQAbABAaA0IACB3IgJABQgmAAgXg3g");
	this.shape_32.setTransform(18.6,-23.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1.5,1,1).p("AhDjMQA1ggAlAfQCQACBJBGQAzBKAcBeIgbADIAZAyIgaADIATAqIgYAIQAQAbgVA2IoSg7QgzhBAMhGIgegKQCTj8BoAeg");
	this.shape_33.setTransform(19,-47.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("Aj5CjQgzhBAMhGIgegKQCTj8BoAeQA1ggAlAfQCQABBJBHQAzBKAcBeIgbADIAYAyIgaADIAUAqIgYAIQAQAbgWA1g");
	this.shape_34.setTransform(19,-47.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1.5,1,1).p("AAkg1QgGgIgGgDQgJgOgMAFQgCgDgMgJQgHgIgZAHQgYAGgBAsQgBAqAMA8QATAdAfgGQAXgNAIgQQAIgRAEgKQAFgKAMgFQAMgFACgFQAGgHgJgMQgCgDgFgDQgFgHgGgPQgGgJgEgFIgjAMAADhJIgXAIAA5gRIgbAI");
	this.shape_35.setTransform(2.8,9.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFD9B2").s().p("Ag5BCQgMg8ABgqQABgsAYgGQAZgHAHAIQAMAJACADQAMgFAJAOQAGADAGAIIAKAOQAGAPAFAHIgbAIIAbgIQAFADACADQAJAMgGAHQgCAFgMAFQgMAFgFAKIgMAbQgIAQgXANIgLABQgYAAgPgYgAABgpIAjgMgAgUhBIAXgIg");
	this.shape_36.setTransform(2.8,9.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(1.5,1,1).p("AAegOQgjgngWAfQgJAkAgASQATAPAPgcg");
	this.shape_37.setTransform(-0.4,20.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgEAgQgggSAJgkQAWgfAjAnIAAAhQgKASgMAAQgGAAgGgFg");
	this.shape_38.setTransform(-0.4,20.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(1.5,1,1).p("AA8hoIAICfQgEA9glAWQgnALgTgTQgrglAHgoIAuiwQAzgsAeA/g");
	this.shape_39.setTransform(-2.2,31.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#596580").s().p("AgfCCQgrglAHgoIAuiwQAzgsAeA/IAICfQgEA9glAWQgOAEgMAAQgUAAgMgMg");
	this.shape_40.setTransform(-2.2,31.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(1.5,1,1).p("AArBUIijAFQgCAEAAAAQgJAVgBAXQAAAFAAAEQABAFACAFIAJATQAEAIADAFQACAEAFgBQAiAJAmAAQA5ACAsgIQAsgIAIgHQAIgIADgIQACgHABgZQABgUgBgXIgVi4QAUhUhpgTAArBUQAhAIATAeAAyhmQgOBXAHBj");
	this.shape_41.setTransform(26,30.3);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#596580").s().p("AgiDIQgmAAgigJQgFABgCgEIgHgNIgJgTIgDgKIAAgJQABgXAJgVIACgEICjgFQAhAIATAeQgTgeghgIQgHhjAOhXIgXhhQBpATgUBUIAVC4QABAXgBAUQgBAZgCAHQgDAIgIAIQgIAHgsAIQgjAGgrAAIgXAAg");
	this.shape_42.setTransform(26,30.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(1.5,1,1).p("AgKAkIAfAAIgKhDIgXgEQgQAaASAtg");
	this.shape_43.setTransform(12.9,44.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgKAkQgSgtAQgaIAXAEIAKBDg");
	this.shape_44.setTransform(12.9,44.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(1.5,1,1).p("AAkg6QgNgEgKABQgJAAgNADQgPAFgJAEQgJACgFAGQgCADgBADQgBADgEAHQgEAGAAAFIACAHQAAACgBAEQgCADAAADQAAAEADAHQABACgDALAgCAoQALgEAIgGQAGgEASgLQAqgqgvgeAgCAoQAAAAgBAAQgDABgFAAQgFAAgGAAQACADADACQADABAEADAgDAoQABAAAAAAAg6AfQACALAOAMQAHAFAGACQAEABALAAQADAAACgBQAGAAABgDQACgFABgFQACgHgFgBAgcApQgBAAgBAAQgDAAgDAAAgcApQAAAEgBAFAgWApQgDAAgDAA");
	this.shape_45.setTransform(6.7,45.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFD9B2").s().p("AgdA9QgGgCgHgFQgOgMgCgLIAAAAIgBgCQADgLgBgCQgDgHAAgEQAAgDACgDIABgGIgCgHQAAgFAEgGIAFgKIADgGQAFgGAJgCIAYgJQANgDAJAAQAKgBANAEIAAABQAvAegqAqIgYAPQgIAGgLAEQAFABgCAHIgDAKQgBADgGAAIgFABIgGAAIgJgBgAgWApIAFAFIAHAEIgHgEIgFgFIgGAAIAGAAgAgdAyIABgJIgCAAIgGAAIAGAAIACAAIgBAJgAgLApIgLAAIALAAIAIgBIgIABgAgDAoIABAAIgBAAg");
	this.shape_46.setTransform(6.7,45.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(1.5,1,1).p("AggAJIADhPIA/gFIgDBJQABA+gcAQQgpgXAFgsg");
	this.shape_47.setTransform(16.4,6.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFD9B2").s().p("AggAJIADhPIA/gFIgDBJQABA+gcAQQgpgXAFgsg");
	this.shape_48.setTransform(16.4,6.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#000000").ss(1.5,1,1).p("AAZjwQAXAeADAwQADAvABARAAADzQBLiLAhizIgbgdIAUgSQgZhPgzgnIgxgCQg2AmgUBHIAXATIggAaQAbChBQCqgAgwhUQAAgEgDg7QgDg7AegkAAMhSIAXgnQgQgQgOgKIgcAiAgDhSIAPAAAgDhSIgUgfIgZAdQADA6AMBSQANhOARg8gAApAvQgOhXgPgqAApAvQAKhEAEhNAAjh5QAJAKALANAghA4QAMBRAVBqQAahYAPhs");
	this.shape_49.setTransform(16.3,28.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFE47F").s().p("AgkAIQAMhNARg8IgUgfIAcgiQAOAKAQAQIgXAnIgPAAIAPAAQAQAqANBXQgPBsgaBXQgVhqgLhRg");
	this.shape_50.setTransform(16.7,33.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgxAJIAYgcIAUAeQgQA8gNBOQgNhSgCg6gAAKALIAXgmQgPgQgOgKIgdAiIgYAcIgDg+QgEg7AeglIAxACQAXAfAEAvIAEBAIgVgWIAVAWQgFBMgJBFQgOhXgQgqgAA2gFIAAAAg");
	this.shape_51.setTransform(16.5,19.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#596580").s().p("AAADzQAahYAPhsQAKhEAEhNIgEhAQgDgwgXgeQAzAnAZBPIgUASIAbAdQghCzhLCLIAAAAgAhrhXIAggaIgXgTQAUhIA2gmQgeAkADA7IADA/QADA6AMBSQAMBRAVBqQhQiqgbigg");
	this.shape_52.setTransform(16.3,28.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#000000").ss(1.5,1,1).p("AhwgfQgECugJC5IEcAAQAxjrgQl1IhwgvIhWgBQgwARhEAMQgYBVgxCLIBTAsQABgxAAgy");
	this.shape_53.setTransform(13,39.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#596580").s().p("Ah9FIQAJi5AEiuIABhiIgBBiIhTgsQAxiLAYhUQBEgNAwgQIBWABIBwAuQAQF1gxDsg");
	this.shape_54.setTransform(13,39.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#000000").ss(1.5,1,1).p("AAghAQgPAWgRALIARgBIA7gNQAOAFgMANIgvAWIAAAFQAdgCAZgFQAOAHgNAMQgcALgbAEIgBAGQAaAAAUgDQAMAJgPAKQgZAHgbAAIgCAGIAmAHQANAIgZAFQg+AFg9gSQgYgdAUgYIAngvIBBgzQARABgHARg");
	this.shape_55.setTransform(17.1,35.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFD9B2").s().p("AhOBFQgYgdAUgYIAngvIBBgzQARABgHARQgPAWgRALIARgBIA7gNQAOAFgMANIgvAWIAAAFQAdgCAZgFQAOAHgNAMQgcALgbAEIgBAGQAaAAAUgDQAMAJgPAKQgZAHgbAAIgCAGIAmAHQANAIgZAFIgcABQgwAAgvgOg");
	this.shape_56.setTransform(17.1,35.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#000000").ss(1.5,1,1).p("AAbATQAPgygmgEQgjALABAkQgEAYAggBg");
	this.shape_57.setTransform(7.9,40);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgeAMQgBgkAjgLQAmAEgPAyIgdAQIgCABQgdAAADgYg");
	this.shape_58.setTransform(7.9,40);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#000000").ss(1.5,1,1).p("ABehaQBAAXgoA6IiGBVQg3AbglgVQgegdAHgbQALg2AngOg");
	this.shape_59.setTransform(-2.4,45);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#596580").s().p("AhsBSQgegdAHgbQALg2AngOICvgwQBAAXgoA6IiGBVQgfAPgZAAQgUAAgQgJg");
	this.shape_60.setTransform(-2.4,45);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#000000").ss(1.5,1,1).p("AAWgCQgTARgYgT");
	this.shape_61.setTransform(23.1,-10);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#000000").ss(1.5,1,1).p("AgZgBQAdAYAWgf");
	this.shape_62.setTransform(3.6,-9.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#000000").ss(1.5,1,1).p("AAOANQgGAFgIAAQgHAAgGgFQgFgFAAgIQAAgHAFgFQAGgFAHAAQAIAAAGAFQAFAFAAAHQAAAIgFAFg");
	this.shape_63.setTransform(15,11.6);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#CC0000").s().p("AgNAMQgGgEAAgIQAAgHAGgFQAGgFAHAAQAIAAAFAFQAHAFAAAHQAAAIgHAEQgFAGgIAAQgHAAgGgGg");
	this.shape_64.setTransform(15,11.6);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#000000").ss(1.5,1,1).p("AgTg8QgdAxAFAwQAMAWAfACQAcgGAQgZ");
	this.shape_65.setTransform(13.7,-3.3);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AAiAVIgNgCIgFgBQgSgEgXgHIgIgEQgcgJAAgEQABgJAJABQAHAEAeADQAXACAVgGQAUgFAEAAQAJABgBAMQgBAHgDAHQgHAOgPAAIgCAAg");
	this.shape_66.setTransform(25.7,-16.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("Ag4AJQgEgHgBgHQgBgLAJgBQADgBAVAEQAVAFAXgDQAdgEAIgFQAJgBABAJQAAAEgcAKIgIAEQgVAJgTAEIgFABIgNADIgEAAQgNAAgHgNg");
	this.shape_67.setTransform(0.7,-15.9);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#000000").ss(1.5,1,1).p("AkDiDQAZhRBMhLQCVgqCYAgQBWBNAdBsQAFAqACAuIgEB8QgEBTg6AtIhdBDQhJAXhKgIIiCg8QhIgrgEhNIgRiPQgChAAHg2g");
	this.shape_68.setTransform(14,-11.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFD9B2").s().p("AgpE2IiCg8QhIgrgEhNIgRiPQgChAAHg2QAZhRBMhLQCVgqCYAgQBWBNAdBsQAFAqACAuIgEB8QgEBTg6AtIhdBDQg1ARg2AAQgUAAgUgCg");
	this.shape_69.setTransform(14,-11.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#000000").ss(1.5,1,1).p("AgqBPIgBhgQASg0AagJQA3AQgPBJQgaA/g5AFg");
	this.shape_70.setTransform(42.7,-11.9);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFD9B2").s().p("AgrgRQASg0AagJQA3AQgPBJQgaA/g5AFg");
	this.shape_71.setTransform(42.7,-11.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#000000").ss(1.5,1,1).p("AAdglQgfgwgcADQgmAYApBfQAiA6AqgPg");
	this.shape_72.setTransform(-14.7,-10.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFD9B2").s().p("AgbAlQgphfAmgYQAcgDAfAwIAUB1QgJADgIAAQggAAgbgug");
	this.shape_73.setTransform(-14.7,-10.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#000000").ss(1.5,1,1).p("Agkj9QCXg/B3CAQBFBVAVBQIgeAUIAkASIgfAjIAcANQgIAZgVAVQgBAKAEAcQAAAvgWAdIgpAoInAAMIg4gwQgzhvAThPIgfgIQA8imBWhUQAXgfAuAOQAfgrAvAcg");
	this.shape_74.setTransform(13.4,-29.3);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AkKDjQgzhvAThPIgfgIQA9imBVhUQAXgfAuAOQAfgrAwAcQCWg/B3CAQBEBVAXBQIgeAUIAjASIgfAjIAbANQgGAZgWAVQgBAKADAcQAAAvgVAdIgpAoInAAMg");
	this.shape_75.setTransform(13.4,-29.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#000000").ss(1.5,1,1).p("AAfkAIg6AAQgaAfgFAyQgDAygBASQAFBSALBJQAQhcASgsIASABAgmiCQASgQARgLIAgAmIgXAgQAUBAAPBTQAOhWADg9AAEEBQhZiXgZi3IASglIgRgUQAWhTA8gnAAfkAQA+ArASBKIgVAVIAUAgQgOCnhcCwAAdh3IAdAgQAAgEAEg/QAEg+gjgoAgMhYIgagqAg+hrQAMgNAMgKAApA8QgNBWgYBvQgghegShz");
	this.shape_76.setTransform(16,36.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFE47F").s().p("AgrgBQAQhdASgrIASABIgSgBIgbgqQATgQAQgMIAhAmIgXAhQATBAAQBSQgOBXgYBuQgghegRhyg");
	this.shape_77.setTransform(15.8,41.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#596580").s().p("AAEEBQAXhvAPhWQANhWADg9IAEhDQADg+gigoQA9ArATBKIgVAVIAUAgQgPCnhbCwIAAAAgAhuhNIASglIgRgUQAWhTA8gnQgbAfgDAyIgFBEQAGBSAKBJQASBzAgBeQhZiXgZi3g");
	this.shape_78.setTransform(16,36.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAHALIAXgfIghgmQgRALgSAQIgXAWIAEhDQAEgzAbgfIA5AAQAjAogEA/IgEBBIgcgeIAcAeQgDA9gNBYQgQhUgThAgAg9gJIAXgWIAbApQgSAsgQBcQgLhKgFhRgAA6AKg");
	this.shape_79.setTransform(16,27.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#000000").ss(1.5,1,1).p("AiuAOIgTAzIhbgwIA2iwQAEhUAvgNIBxgaICggEIBxAUQA/AEgGCGIAVGfIg+AAIgSmPAiuAOIAAh5ADfEfImNAAIAAkR");
	this.shape_80.setTransform(14,42.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#596580").s().p("ADfEfIgRmPIARGPImMAAIAAkRIgUAzIhbgwIA2ivQAFhVAugNIBxgaICggEIBwAUQBAAEgHCGIAWGfgAitAOIAAh5g");
	this.shape_81.setTransform(14,42.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23}]},1).to({state:[]},1).to({state:[{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.7,-70.8,69.5,142.6);


(lib.vjv202キャラA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgIAMIgDgGQgCgWAKgBQAPgCAAAVQACAPgMABIgCAAQgFAAgDgGg");
	this.shape.setTransform(9.6,-41);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgIAMIgDgGQgCgWAKgBQAPgCAAAVQACAPgMABIgCAAQgFAAgDgGg");
	this.shape_1.setTransform(-5.6,-38.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1.5,1,1).p("AA9iWIBpgbAAPhqQgBBlAMBQIAfAAAilh5IBvgTAgfCyQBbgdBigB");
	this.shape_2.setTransform(0.1,-30.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1.5,1,1).p("AEABTQAaAXALgpQAQg2gEgwQgHg6grgbIgUA1IhDjNQhPhRhRADIAgA6IhegoIAABGIg3hGIglBXIAAhcIh2CEQAPBeAKCHIgvg4QgnAMApBtQAmBmAsghIASA9QAUBAA6AaQArAaBTARQBAAOBAgqQA4grAkg7QAbgmgHg+IgEglIgNhwAjKCcIgghl");
	this.shape_3.setTransform(2.4,-31.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFD9B2").s().p("AAUFeQhTgRgrgaQg6gagUhAIgSg9IgghlIAgBlQgsAhgmhmQgphtAngMIAvA4QgKiHgPheIB2iEIAABcIAlhXIA3BGIAAhGIBeAoIggg6QBRgDBPBRIBDDNIAUg1QArAbAHA6QAEAwgQA2QgLApgagXIgNhwIANBwIAEAlQAHA+gbAmQgkA7g4ArQgwAfgvAAQgQAAgRgDgAjKCcg");
	this.shape_4.setTransform(2.4,-31.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1.5,1,1).p("AADj/QBxAaCCBNQA1BCgID4In4BfQhSiZAEh8QA9h8B8hdQAfgHARAdQAEgwA5AIg");
	this.shape_5.setTransform(-1.1,-51.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#333333").s().p("AkjgUQA9h8B8hdQAfgHARAdQAEgwA5AIQBxAaCCBNQA1BCgID4In4BfQhSiZAEh8g");
	this.shape_6.setTransform(-1.1,-51.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1.5,1,1).p("AAlgCQAEBCggASQgxgXAEgvIAAhVIBJgIg");
	this.shape_7.setTransform(4.9,4.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFD9B2").s().p("AgkAMIAAhVIBJgIIAABPQAEBCggARQgxgWAEgvg");
	this.shape_8.setTransform(4.9,4.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1.5,1,1).p("AgkkAIA5AAQA9AnAbBTIgRAUIAUAlQgSC3hSCXQAcheANhzQgUhcgUgsIAZgqQgTgQgRgLIgfAmIAYAgIASgBAA/hrQgCgSgGgyQgGgygcgfAAmiCQAMAKANANAA1AwQAIhJAChSAghA8QAMhTAQhAAghA8QARBWAcBvQhjiwgVinIASggIgVgVQAPhKA8grQgiAoAHA+QAGA/ABAEQAFA9ASBWgAg4hXIAbgg");
	this.shape_9.setTransform(5.6,28.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AA1AwQAIhJAChSIgIhEQgGgygcgfQA9AnAbBTIgRAUIAUAlQgSC3hSCXQAcheANhzgAhshWIASggIgVgVQAPhKA8grQgiAoAHA+IAHBDQAFA9ASBWQARBWAcBvQhjiwgVing");
	this.shape_10.setTransform(5.6,28.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E6E6A0").s().p("AgqALQALhUARhAIgZgfIAhgnQAPALAUAQIgZAqIgSABIASgBQATAsAVBdQgNBygcBeQgchvgRhVg");
	this.shape_11.setTransform(6.5,33.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag3AKIAbgeIgbAeIgHhBQgGg/AhgoIA6AAQAcAfAGAzIAHBDIgZgWIAZAWQgCBRgIBKQgUhcgTgsIAYgpQgTgQgQgLIggAmIAZAfQgRBAgMBUQgRhYgGg9g");
	this.shape_12.setTransform(5.4,18.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(1.5,1,1).p("AA9lHIiiBbQgjAMAaBhQAaEiCYClIA3hGIhChaQg7iRgkia");
	this.shape_13.setTransform(-5.8,38.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#333333").s().p("Ahuh/QgahhAjgMICihbIhjDEQAkCaA7CRIBCBaIg3BGQiYilgakig");
	this.shape_14.setTransform(-5.8,38.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1.5,1,1).p("AAggOIgWgWQgWAXgTAcIAVAWQAegTAMggg");
	this.shape_15.setTransform(4.3,67.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgfAPQATgcAWgXIAWAXQgMAggeASg");
	this.shape_16.setTransform(4.3,67.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1.5,1,1).p("Ag5gWQABAKABALQABAIAEAHQAEAKAAAHQgCANADAEQACAHAMgCQADAAADgDQAHgBANABQAQgDAHgFQANgBABgKQACgBALgGQAHgDAFgTQAFgTgdgQQgdgQgegDg");
	this.shape_17.setTransform(10.4,71.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFD9B2").s().p("AgtAwQgDgEACgNQAAgHgEgKQgEgHgBgIIgCgVIAfgeQAeADAdAQQAdAQgFATQgFATgHADQgLAGgCABQgBAKgNABQgHAFgQADQgNgBgHABQgDADgDAAIgEAAQgIAAgCgFg");
	this.shape_18.setTransform(10.4,71.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(1.5,1,1).p("AgWA3QAAgBAGgEQAGALADABQAJAGAHgLIAEADQAKAFAKgUQAEgHACgRQATgkgHgeQgSgTgTABQgkANgPASQgNARgBApQgCALAKAFQAEACACgCQAAAGAIAEQAGADABAAg");
	this.shape_19.setTransform(11.3,70.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFD9B2").s().p("AgHA+QgDgBgGgLIgGAFIgHgDQgIgEAAgGQgCACgEgCQgKgFACgLQABgpANgRQAPgSAkgNQATgBASATQAHAegTAkQgCARgEAHQgKAUgKgFIgEgDQgFAHgFAAQgDAAgDgCg");
	this.shape_20.setTransform(11.3,70.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1.5,1,1).p("AgMgiQAmgFAHAyIgPAYQgmgTgMgXg");
	this.shape_21.setTransform(15,65.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgggHIAUgbQAmgFAHAyIgPAYQgmgTgMgXg");
	this.shape_22.setTransform(15,65.7);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1.5,1,1).p("AAdiZQgWEag+CCQAEA3BFADQA/jUABj3QALhEgTgnIifhD");
	this.shape_23.setTransform(17.6,36.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#333333").s().p("Ag3EDQA+iCAWkaIhyijICfBDQATAngLBEQgBD3g/DUQhFgCgEg4g");
	this.shape_24.setTransform(17.6,36.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1.5,1,1).p("AAtlnIB4BrIAUJkIlfAAIAAmNIgSjHICQh3g");
	this.shape_25.setTransform(4.4,40.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#333333").s().p("AimFoIAAmMIgSjHICQh4IBVgEIB4BsIAUJjg");
	this.shape_26.setTransform(4.4,40.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#000000").ss(1.5,1,1).p("AgChJQACgDAMgJQAHgIAZAHQAYAGABAsQABAqgMA8QgTAdgfgGQgXgNgIgQQgIgRgEgKQgFgKgMgFQgMgFgCgFQgGgHAJgMQACgDAFgDQAFgHAGgPQAGgJAEgFIAjAMAgjg1QAGgIAGgDQAJgOAMAFIAXAIAg4gRIAbAI");
	this.shape_27.setTransform(18.2,7.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFD9B2").s().p("AAIBZQgXgNgIgQIgMgbQgFgKgMgFQgMgFgCgFQgGgHAJgMQACgDAFgDQAFgHAGgPIAKgOIAjAMIgjgMQAGgIAGgDQAJgOAMAFIAXAIIgXgIQACgDAMgJQAHgIAZAHQAYAGABAsQABAqgMA8QgPAYgYAAIgLgBgAgdgJIgbgIg");
	this.shape_28.setTransform(18.2,7.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#000000").ss(1.5,1,1).p("AgdgOQAjgnAWAfQAJAkggASQgTAPgPgcg");
	this.shape_29.setTransform(21.5,18.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgdATIAAghQAjgnAWAfQAJAkggASQgGAFgGAAQgMAAgKgSg");
	this.shape_30.setTransform(21.5,18.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#000000").ss(1.5,1,1).p("AhEA3QAEA8AmAXQAnALAUgTQAqglgHgoIguiwQgzgsgfA/g");
	this.shape_31.setTransform(23.3,29.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#333333").s().p("AgaCKQglgXgFg8IAIifQAfg/AzAsIAtCwQAIAogrAlQgMAMgUAAQgLAAgPgEg");
	this.shape_32.setTransform(23.3,29.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1.5,1,1).p("AgpBVICjAFQABADABABQAJAVABAXQAAAEAAAEQgBAFgCAGIgJASQgEAJgDAFQgCADgFAAQgiAIgmAAQg6ACgsgIQgsgIgIgHQgIgIgCgHQgDgHgBgZQgBgVACgWIAVi4QgUhVBogTAgpBVQgiAIgSAdAgwhmQAOBXgHBk");
	this.shape_33.setTransform(-5,28.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#333333").s().p("AhCDCQgsgIgIgHQgIgIgCgHQgDgHgBgZQgBgVACgWIAVi4QgUhVBogTIgWBhQAOBXgHBkQgiAIgSAdQASgdAigIICjAFIACAEQAJAVABAXIAAAIIgDALIgJASIgHAOQgCADgFAAQgiAIgmAAIgUAAQgtAAglgGg");
	this.shape_34.setTransform(-5,28.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1.5,1,1).p("AgUAkIAKhDIAXgEQAQAagSAtg");
	this.shape_35.setTransform(8.1,42.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgUAkIAKhDIAXgEQAQAagSAtg");
	this.shape_36.setTransform(8.1,42.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgJALIgCgGQAAgWALAAQAOAAgCAVQAAANgMAAQgGABgDgHg");
	this.shape_37.setTransform(16,-44.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgJALIgCgGQAAgWALAAQAOAAgCAVQAAAOgMgBQgGAAgDgGg");
	this.shape_38.setTransform(-2.8,-42.6,1,1,0,0,0,-0.1,0);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(1.5,1,1).p("AgNhYQgGBgAHBPIAdAC");
	this.shape_39.setTransform(1.5,-37.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#000000").ss(1.5,1,1).p("AA4iKQA5gaAtAKAidhmQAogeA+ABAhICWQBgAaBzg8");
	this.shape_40.setTransform(1.4,-33.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(1.5,1,1).p("ADvBvQAXAYAOgnQAVgyACgvQgCg5gmgeIgZAxIgtjOQhEhWhcgUIAUAqIhKgmIgSBDIgghDIgwBNIAOhFIh/B0QAFBdgECEIgog7QgnAHAdBuQAbBnAugcIALA9QANBAA2AgQAnAdBQAYQA7AUBCgiQA7gkApg2QAdghAAg+IAAgjIgBhvAjUCHIgVhl");
	this.shape_41.setTransform(3.1,-30.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFD9B2").s().p("AgPFZQhQgYgngdQg2gggNhAIgLg9IgVhlIAVBlQguAcgbhnQgdhuAngHIAoA7QAEiEgFhdIB/h0IgOBFIAwhNIAgBDIAShDIBKAmIgUgqQBcAUBEBWIAtDOIAZgxQAmAeACA5QgCAvgVAyQgOAngXgYIgBhvIABBvIAAAjQAAA+gdAhQgpA2g7AkQgqAVgnAAQgXAAgVgHgAjUCHg");
	this.shape_42.setTransform(3.1,-30.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(1.5,1,1).p("AAfjrQBqAkB3BYQAtBFghDwInyApQhAicAQh4QBIhyCBhOQAfgDANAeQAKgvA2AOg");
	this.shape_43.setTransform(1.4,-51.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#333333").s().p("AkWglQBIhyCBhOQAfgDANAeQAKgvA2AOQBqAkB3BYQAtBFghDwInyApQhAicAQh4g");
	this.shape_44.setTransform(1.4,-51.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(1.5,1,1).p("Agjg6QANgEAKABQAJAAANADQAPAFAJAEQAJACAFAGQACADABADQABADAEAHQAEAGAAAFIgCAHQAAACABAEQACADAAADQAAAEgDAHQgBACADALAADAoQgLgEgIgGQgGgEgSgLQgqgqAvgeAA7AfQgCALgOAMQgHAFgGACQgEABgLAAQgDAAgCgBQgGAAgBgDQgCgFgBgFQgCgHAFgBQAAAAABAAQADABAFAAQAFAAAGAAQgCADgDACQgDABgEADAAEAoQgBAAAAAAAAdApQABAAABAAQADAAADAAAAdApQAAAEABAFAAdApQgDAAgDAA");
	this.shape_45.setTransform(14.3,44);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFD9B2").s().p("AAPA+IgFgBQgGAAgBgDIgDgKQgCgHAFgBIABAAIAAAAIgBAAQgLgEgIgGIgYgPQgqgqAvgeIAAgBQANgEAKABQAJAAANADIAYAJQAJACAFAGIADAGIAFAKQAEAGAAAFIgCAHIABAGQACADAAADQAAAEgDAHQgBACADALIgBACIAAAAQgCALgOAMQgHAFgGACIgJABIgGAAgAAdApIABAJIgBgJIACAAIAGAAIgGAAIgCAAIgGAAIAGAAIAAAAgAASAuIgHAEIAHgEIAFgFIgFAFgAAMApIALAAIgLAAIgIgBIAIABg");
	this.shape_46.setTransform(14.3,44);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(1.5,1,1).p("AgegCQgBA+AcAQQApgXgFgsIgDhPIg/gFg");
	this.shape_47.setTransform(4.7,4.2);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFD9B2").s().p("AgegCIgDhJIA/AFIADBPQAFAsgpAXQgcgQABg+g");
	this.shape_48.setTransform(4.7,4.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#000000").ss(1.5,1,1).p("AAxhUQAAgEADg7QADg7gegkIgxACQgzAngZBPIAVASIgcAdQAhCzBLCLAghh5IAWAnIAPAAIAVgfIAYAdAAZjyQA2AmAUBHIgXATIAgAaQgbChhQCqAghh5QAPgQAOgKIAdAiAAiA4QAMhSADg6AgLhSQgPAqgOBXQAPBsAaBYQAVhqAMhRQgNhOgRg8Ag2hiQABgRADgvQADgwAXgeAg2hiQAEBNAKBEAg2hiQALgNAKgK");
	this.shape_49.setTransform(4.7,26.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#E6E6A0").s().p("AglAAQAOhXAQgqIAPAAIgPAAIgXgnQAPgQAPgKIAcAiIgUAfQAQA8AOBNQgMBRgVBqQgbhXgPhsg");
	this.shape_50.setTransform(4.4,31.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("AABDzQAVhqAMhRQAMhSADg6IADg/QADg7gegkQA2AmAUBIIgXATIAgAaQgbCghQCqIAAAAgAhrhLIAcgdIgVgSQAZhPAzgnQgXAegDAwIgEBAQAEBNAKBEQAPBsAaBYQhLiLghizg");
	this.shape_51.setTransform(4.7,26.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAFALIAVgeIgdgiQgOAKgPAQIAWAmQgPAqgOBXQgKhEgEhNIAVgWIgVAWIAEhAQADgvAXgfIAxgCQAeAlgDA7IgDA+IgYgcIAYAcQgDA5gMBTQgNhOgRg8g");
	this.shape_52.setTransform(4.6,17.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#000000").ss(1.5,1,1).p("ABxgfQAECuAIC5IkcABQgwjsAQl1IBwgvIBWgBQAvARBFAMQAXBVAyCKIhTAtQgCgxAAgy");
	this.shape_53.setTransform(8.1,37.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#333333").s().p("Ai/kXIBwgwIBWAAQAvAQBFAMQAXBVAyCKIhTAtQgCgxAAgxQAAAxACAxQAECtAIC6IkcABQgwjsAQl0g");
	this.shape_54.setTransform(8.1,37.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.3,-78,65.3,156);


(lib.vjv202白隠し = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AtvNSIAA6jIbfAAIAAajg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88,-84.9,176,170);


(lib.vjv202txtイコール = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000066").s().p("AhFAKIAAgTICLAAIAAATg");
	this.shape.setTransform(0,2.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000066").s().p("AhFAKIAAgTICLAAIAAATg");
	this.shape_1.setTransform(0,-2.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0066").s().p("AhFAKIAAgTICLAAIAAATg");
	this.shape_2.setTransform(0,2.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0066").s().p("AhFAKIAAgTICLAAIAAATg");
	this.shape_3.setTransform(0,-2.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF6600").s().p("AhFAjIAAgUICLAAIAAAUgAhFgOIAAgUICLAAIAAAUg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7,-3.5,14,7);


(lib.vjv202txt純利益率B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#006699").s().p("AgLBTIAAggIhGAAIAAgXIBGAAIAAgEIgZACIgCgMQgCACgLAEQgLADgGABIgIgXQAJgBANgCQANgEAFgDIAGAMIAEAAIAJgIIgWgPIgNANQgCgEgJgHQgIgHgHgCIASgRQAJAEANANIAJgNIAHAFIAHgLIhBAAIAAgXIBFAAIAAgNIAYAAIAAANIBDAAIAAAXIgSAAIAOAPIgNALQgIAHgGABIgPgTQARgEAJgLIgwAAIgPAWIADACIAPgTIARAOIgcAdIALgBIgBgCIATgHIAFAKIAKgNQAGABANAGQAKAFADADIgMAVQgFgEgJgGIgNgHIAEAKIgUAIIgBgGIgLABIAAAHIBFAAIAAAXIhFAAIAAAgg");
	this.shape.setTransform(36.7,9.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#006699").s().p("AhOBQIAAgXIAVAAIAAgmQgHAHgIAEIgLgaQAagMANgUIgkAAIAAgVIApAAQgEgLgIgIIAXgLQAJAJAIAQIgKAFIAcAAIAPgeIAZAHIgKAXIAtAAIAAAVIgkAAQAFAJAKAJQALAKAMAEIgNAZIgMgJIAAAlIAUAAIAAAXgAAbA5IAIAAIAAgfIgIAAgAgCA5IAHAAIAAgfIgHAAgAghA5IAHAAIAAgfIgHAAgAgmAEIBNAAQgIgHgPgZIgeAAQgNAZgLAHg");
	this.shape_1.setTransform(18.1,9.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#006699").s().p("AAfBSIgIgaIAYAAQAHABAAgHIAAh+IAZAAIAACNQAAAHgEAFQgFAFgIAAgAgrBSIAAg3IgLAQQgIALgFAFIgLgbQAIgIALgQQAJgOADgHIgdAAIAAgXIAhAAIAAgMIgWACIgKgXQARgBAWgEQAWgDALgEIALAWQgEADgXAEIAAAQIAbAAIAAAXIgZAAQAKANAPAMIgJAaQgJgGgJgKIAAA8gAAMAsIAAhvIAZAAIAABvg");
	this.shape_2.setTransform(-0.8,9.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006699").s().p("Ag3BTIAAhFIgWABIgEgUIASgBIAFgGIgYgZIANgUIAEAEIAQgdIASALIgSAkIADAEIASgeIARALIgBgFQATAAAPgEIAAgUIAYAAIAAAQQALgCAMgFIALAVQgQAHgRADIAAAuIAFAAIAAgjIAZAAIAAA5IgeAAIAAAZQgBAFAFAAIAHAAQACAAABgVIAWAGQgBAUgDAHQgDALgMgBIgaAAQgQAAAAgPIAAglIgGAAIAAALIgWAAIAAgZIgHAEIAFApIgTADIgDgpIAKgCIgCgKIgKACIAABHgAAQgcIAAAjIAGAAIAAgpQgMACgPACIgFgSIgbApIAIgBIgCgFIAOgIIALAWIAAgdgAhRBCQAFgXAAgYIASADQAAAbgEAWg");
	this.shape_3.setTransform(-19,9.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#006699").s().p("AhPBAQASgNAGgOIgXAAIAAgVIAPAAIAAg4IgNAAIAAgWIANAAIAAgTIAYAAIAAATIARAAIAAgTIAYAAIAAATIAHAAIAAAWIgHAAIAAA4IAIAAIAAAUQACgIAAgRIAAhUIBEAAIAACBQAAALgEAFQgEAIgMgBIgPAAIgJgXIAMAAQAIAAgBgGIAAgZIgTAAQAAAOgFAOQgFARgHAKIgUgPIgNAHIgPgbIAUgIIgqAAIASAJQgLAVgSAPgAADA1QAEgFADgLIgQAAQAAAFAJALgAgnAQIARAAIAAgJIgRAAgAAkAFIATAAIAAgSIgTAAgAgngJIARAAIAAgIIgRAAgAgnghIARAAIAAgHIgRAAgAAkgiIATAAIAAgSIgTAAg");
	this.shape_4.setTransform(-37.7,9.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#006699").s().p("AAvBRIAAgFIh1AAIAAgXIB1AAIAAgPIhuAAIAAgWIBuAAIAAgOIh1AAIAAgUIA8AAIAAg+IAZAAIAAA+IA3AAIAABjgAAZgjQAFgFAJgOQAIgNACgHIAVANQAAAHgKAOQgJAPgHAEgAg2gpQgJgNgFgEIAVgPQAFAFAIAOIAMAVIgUAMQgDgIgJgMg");
	this.shape_5.setTransform(-56.1,9.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0066").s().p("AgLBTIAAggIhGAAIAAgXIBGAAIAAgEIgZACIgCgMQgCACgLAEQgLADgGABIgIgXQAJgBANgCQANgEAFgDIAGAMIAEAAIAJgIIgWgPIgNANQgCgEgJgHQgIgHgHgCIASgRQAJAEANANIAJgNIAHAFIAHgLIhBAAIAAgXIBFAAIAAgNIAYAAIAAANIBDAAIAAAXIgSAAIAOAPIgNALQgIAHgGABIgPgTQARgEAJgLIgwAAIgPAWIADACIAPgTIARAOIgcAdIALgBIgBgCIATgHIAFAKIAKgNQAGABANAGQAKAFADADIgMAVQgFgEgJgGIgNgHIAEAKIgUAIIgBgGIgLABIAAAHIBFAAIAAAXIhFAAIAAAgg");
	this.shape_6.setTransform(36.7,9.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0066").s().p("AhOBQIAAgXIAVAAIAAgmQgHAHgIAEIgLgaQAagMANgUIgkAAIAAgVIApAAQgEgLgIgIIAXgLQAJAJAIAQIgKAFIAcAAIAPgeIAZAHIgKAXIAtAAIAAAVIgkAAQAFAJAKAJQALAKAMAEIgNAZIgMgJIAAAlIAUAAIAAAXgAAbA5IAIAAIAAgfIgIAAgAgCA5IAHAAIAAgfIgHAAgAghA5IAHAAIAAgfIgHAAgAgmAEIBNAAQgIgHgPgZIgeAAQgNAZgLAHg");
	this.shape_7.setTransform(18.1,9.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0066").s().p("AAfBSIgIgaIAYAAQAHABAAgHIAAh+IAZAAIAACNQAAAHgEAFQgFAFgIAAgAgrBSIAAg3IgLAQQgIALgFAFIgLgbQAIgIALgQQAJgOADgHIgdAAIAAgXIAhAAIAAgMIgWACIgKgXQARgBAWgEQAWgDALgEIALAWQgEADgXAEIAAAQIAbAAIAAAXIgZAAQAKANAPAMIgJAaQgJgGgJgKIAAA8gAAMAsIAAhvIAZAAIAABvg");
	this.shape_8.setTransform(-0.8,9.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF0066").s().p("Ag3BTIAAhFIgWABIgEgUIASgBIAFgGIgYgZIANgUIAEAEIAQgdIASALIgSAkIADAEIASgeIARALIgBgFQATAAAPgEIAAgUIAYAAIAAAQQALgCAMgFIALAVQgQAHgRADIAAAuIAFAAIAAgjIAZAAIAAA5IgeAAIAAAZQgBAFAFAAIAHAAQACAAABgVIAWAGQgBAUgDAHQgDALgMgBIgaAAQgQAAAAgPIAAglIgGAAIAAALIgWAAIAAgZIgHAEIAFApIgTADIgDgpIAKgCIgCgKIgKACIAABHgAAQgcIAAAjIAGAAIAAgpQgMACgPACIgFgSIgbApIAIgBIgCgFIAOgIIALAWIAAgdgAhRBCQAFgXAAgYIASADQAAAbgEAWg");
	this.shape_9.setTransform(-19,9.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF0066").s().p("AhPBAQASgNAGgOIgXAAIAAgVIAPAAIAAg4IgNAAIAAgWIANAAIAAgTIAYAAIAAATIARAAIAAgTIAYAAIAAATIAHAAIAAAWIgHAAIAAA4IAIAAIAAAUQACgIAAgRIAAhUIBEAAIAACBQAAALgEAFQgEAIgMgBIgPAAIgJgXIAMAAQAIAAgBgGIAAgZIgTAAQAAAOgFAOQgFARgHAKIgUgPIgNAHIgPgbIAUgIIgqAAIASAJQgLAVgSAPgAADA1QAEgFADgLIgQAAQAAAFAJALgAgnAQIARAAIAAgJIgRAAgAAkAFIATAAIAAgSIgTAAgAgngJIARAAIAAgIIgRAAgAgnghIARAAIAAgHIgRAAgAAkgiIATAAIAAgSIgTAAg");
	this.shape_10.setTransform(-37.7,9.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF0066").s().p("AAvBRIAAgFIh1AAIAAgXIB1AAIAAgPIhuAAIAAgWIBuAAIAAgOIh1AAIAAgUIA8AAIAAg+IAZAAIAAA+IA3AAIAABjgAAZgjQAFgFAJgOQAIgNACgHIAVANQAAAHgKAOQgJAPgHAEgAg2gpQgJgNgFgEIAVgPQAFAFAIAOIAMAVIgUAMQgDgIgJgMg");
	this.shape_11.setTransform(-56.1,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]},1).to({state:[]},1).wait(1));

	// レイヤー 1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAEAvQAWgIAMgMQAMgMAAgPQAAgVgMgMQgOgOgbACIALAFQAHADgHAEQgKA9gPAQQgJAHgIAAQgKABgGgGQgPgPAAgWQAAgbAUgUQAVgUAdgBQAcAAAPAQQASASAAAXQAAAZgQAQQgLALgVAJgAgigeQgRARAAAXQAAAOAKAJQACADAEAAQADAAAFgFQAOgOAHg+QgRAEgLALg");
	this.shape_12.setTransform(-25.9,-10.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgqBHIAAg+QgMAKgLAHIgGgMQAegQARgdIgpAAIAAgMIAXAAIAAgbIAMAAQAFABgFADIAAAXIANAAIADgDIAJAJIgEAEQgIAOgNAQQAQAEAMAIIgHAOQgLgJgKgFIAAA+gAgMA/IAAgNIAkAAIAAhAIgaAAIAAgOIAaAAIAAgmIANAAQAHABgGADIAAAiIAdAAIAAAOIgdAAIAABAIAiAAIAAANg");
	this.shape_13.setTransform(-42,-10.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgxA1IAAhpIA/AAQAPAAAIAIQAHAHAAAKQAAALgGAHQgFAFgJACQANABAGAGQAHAHAAALQAAAMgJAJQgJAJgRAAgAgjAoIAxAAQAJAAAFgFQAFgFAAgJQAAgIgEgEQgFgFgMAAIgvAAgAgjgJIAtAAQAJAAAEgEQAFgFAAgGQAAgHgDgDQgFgFgHAAIgwAAg");
	this.shape_14.setTransform(-55.8,-10.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12}]}).to({state:[]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66.8,-20.5,115.2,41);


(lib.vjv202txt純利益率A = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAEAvQAWgIAMgMQAMgMABgPQgBgVgNgMQgNgOgbACIAKAFQAIADgIAEQgKA9gPAQQgHAHgJAAQgKABgGgGQgPgPAAgWQAAgbATgUQAWgUAegBQAbAAAQAQQARASAAAXQAAAZgQAQQgLALgWAJgAgigeQgQARgBAXQAAAOAKAJQACADADAAQAEAAAEgFQAPgOAHg+QgQAEgMALg");
	this.shape.setTransform(-26.4,-10.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgqBHIAAg+QgMAKgLAHIgGgMQAegQARgdIgpAAIAAgMIAXAAIAAgbIAMAAQAFABgFADIAAAXIANAAIADgDIAJAJIgEAEQgIAOgNAQQAQAEAMAIIgHAOQgLgJgKgFIAAA+gAgMA/IAAgNIAkAAIAAhAIgaAAIAAgOIAaAAIAAgmIANAAQAHABgGADIAAAiIAdAAIAAAOIgdAAIAABAIAiAAIAAANg");
	this.shape_1.setTransform(-42.5,-10.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAmA2IgKgcIg2AAIgMAcIgQAAIAwhrIAOAAIAvBrgAgVANIAqAAIgUgxIgBAAg");
	this.shape_2.setTransform(-56,-10.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(2));

	// レイヤー 1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#006699").s().p("AgLBTIAAggIhGAAIAAgXIBGAAIAAgEIgZACIgCgMQgCACgLAEQgLADgGABIgIgXQAJgBANgCQANgEAFgDIAGAMIAEAAIAJgIIgWgPIgNANQgCgEgJgHQgIgHgHgCIASgRQAJAEANANIAJgNIAHAFIAHgLIhBAAIAAgXIBFAAIAAgNIAYAAIAAANIBDAAIAAAXIgSAAIAOAPIgNALQgIAHgGABIgPgTQARgEAJgLIgwAAIgPAWIADACIAPgTIARAOIgcAdIALgBIgBgCIATgHIAFAKIAKgNQAGABANAGQAKAFADADIgMAVQgFgEgJgGIgNgHIAEAKIgUAIIgBgGIgLABIAAAHIBFAAIAAAXIhFAAIAAAgg");
	this.shape_3.setTransform(36.7,9.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#006699").s().p("AhOBQIAAgXIAVAAIAAgmQgHAHgIAEIgLgaQAagMANgUIgkAAIAAgVIApAAQgEgLgIgIIAXgLQAJAJAIAQIgKAFIAcAAIAPgeIAZAHIgKAXIAtAAIAAAVIgkAAQAFAJAKAJQALAKAMAEIgNAZIgMgJIAAAlIAUAAIAAAXgAAbA5IAIAAIAAgfIgIAAgAgCA5IAHAAIAAgfIgHAAgAghA5IAHAAIAAgfIgHAAgAgmAEIBNAAQgIgHgPgZIgeAAQgNAZgLAHg");
	this.shape_4.setTransform(18.1,9.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#006699").s().p("AAfBSIgIgaIAYAAQAHABAAgHIAAh+IAZAAIAACNQAAAHgEAFQgFAFgIAAgAgrBSIAAg3IgLAQQgIALgFAFIgLgbQAIgIALgQQAJgOADgHIgdAAIAAgXIAhAAIAAgMIgWACIgKgXQARgBAWgEQAWgDALgEIALAWQgEADgXAEIAAAQIAbAAIAAAXIgZAAQAKANAPAMIgJAaQgJgGgJgKIAAA8gAAMAsIAAhvIAZAAIAABvg");
	this.shape_5.setTransform(-0.8,9.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#006699").s().p("Ag3BTIAAhFIgWABIgEgUIASgBIAFgGIgYgZIANgUIAEAEIAQgdIASALIgSAkIADAEIASgeIARALIgBgFQATAAAPgEIAAgUIAYAAIAAAQQALgCAMgFIALAVQgQAHgRADIAAAuIAFAAIAAgjIAZAAIAAA5IgeAAIAAAZQgBAFAFAAIAHAAQACAAABgVIAWAGQgBAUgDAHQgDALgMgBIgaAAQgQAAAAgPIAAglIgGAAIAAALIgWAAIAAgZIgHAEIAFApIgTADIgDgpIAKgCIgCgKIgKACIAABHgAAQgcIAAAjIAGAAIAAgpQgMACgPACIgFgSIgbApIAIgBIgCgFIAOgIIALAWIAAgdgAhRBCQAFgXAAgYIASADQAAAbgEAWg");
	this.shape_6.setTransform(-19,9.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#006699").s().p("AhPBAQASgNAGgOIgXAAIAAgVIAPAAIAAg4IgNAAIAAgWIANAAIAAgTIAYAAIAAATIARAAIAAgTIAYAAIAAATIAHAAIAAAWIgHAAIAAA4IAIAAIAAAUQACgIAAgRIAAhUIBEAAIAACBQAAALgEAFQgEAIgMgBIgPAAIgJgXIAMAAQAIAAgBgGIAAgZIgTAAQAAAOgFAOQgFARgHAKIgUgPIgNAHIgPgbIAUgIIgqAAIASAJQgLAVgSAPgAADA1QAEgFADgLIgQAAQAAAFAJALgAgnAQIARAAIAAgJIgRAAgAAkAFIATAAIAAgSIgTAAgAgngJIARAAIAAgIIgRAAgAgnghIARAAIAAgHIgRAAgAAkgiIATAAIAAgSIgTAAg");
	this.shape_7.setTransform(-37.7,9.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#006699").s().p("AAvBRIAAgFIh1AAIAAgXIB1AAIAAgPIhuAAIAAgWIBuAAIAAgOIh1AAIAAgUIA8AAIAAg+IAZAAIAAA+IA3AAIAABjgAAZgjQAFgFAJgOQAIgNACgHIAVANQAAAHgKAOQgJAPgHAEgAg2gpQgJgNgFgEIAVgPQAFAFAIAOIAMAVIgUAMQgDgIgJgMg");
	this.shape_8.setTransform(-56.1,9.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FF0066").s().p("AgLBTIAAggIhGAAIAAgXIBGAAIAAgEIgZACIgCgMQgCACgLAEQgLADgGABIgIgXQAJgBANgCQANgEAFgDIAGAMIAEAAIAJgIIgWgPIgNANQgCgEgJgHQgIgHgHgCIASgRQAJAEANANIAJgNIAHAFIAHgLIhBAAIAAgXIBFAAIAAgNIAYAAIAAANIBDAAIAAAXIgSAAIAOAPIgNALQgIAHgGABIgPgTQARgEAJgLIgwAAIgPAWIADACIAPgTIARAOIgcAdIALgBIgBgCIATgHIAFAKIAKgNQAGABANAGQAKAFADADIgMAVQgFgEgJgGIgNgHIAEAKIgUAIIgBgGIgLABIAAAHIBFAAIAAAXIhFAAIAAAgg");
	this.shape_9.setTransform(36.7,9.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF0066").s().p("AhOBQIAAgXIAVAAIAAgmQgHAHgIAEIgLgaQAagMANgUIgkAAIAAgVIApAAQgEgLgIgIIAXgLQAJAJAIAQIgKAFIAcAAIAPgeIAZAHIgKAXIAtAAIAAAVIgkAAQAFAJAKAJQALAKAMAEIgNAZIgMgJIAAAlIAUAAIAAAXgAAbA5IAIAAIAAgfIgIAAgAgCA5IAHAAIAAgfIgHAAgAghA5IAHAAIAAgfIgHAAgAgmAEIBNAAQgIgHgPgZIgeAAQgNAZgLAHg");
	this.shape_10.setTransform(18.1,9.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF0066").s().p("AAfBSIgIgaIAYAAQAHABAAgHIAAh+IAZAAIAACNQAAAHgEAFQgFAFgIAAgAgrBSIAAg3IgLAQQgIALgFAFIgLgbQAIgIALgQQAJgOADgHIgdAAIAAgXIAhAAIAAgMIgWACIgKgXQARgBAWgEQAWgDALgEIALAWQgEADgXAEIAAAQIAbAAIAAAXIgZAAQAKANAPAMIgJAaQgJgGgJgKIAAA8gAAMAsIAAhvIAZAAIAABvg");
	this.shape_11.setTransform(-0.8,9.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FF0066").s().p("Ag3BTIAAhFIgWABIgEgUIASgBIAFgGIgYgZIANgUIAEAEIAQgdIASALIgSAkIADAEIASgeIARALIgBgFQATAAAPgEIAAgUIAYAAIAAAQQALgCAMgFIALAVQgQAHgRADIAAAuIAFAAIAAgjIAZAAIAAA5IgeAAIAAAZQgBAFAFAAIAHAAQACAAABgVIAWAGQgBAUgDAHQgDALgMgBIgaAAQgQAAAAgPIAAglIgGAAIAAALIgWAAIAAgZIgHAEIAFApIgTADIgDgpIAKgCIgCgKIgKACIAABHgAAQgcIAAAjIAGAAIAAgpQgMACgPACIgFgSIgbApIAIgBIgCgFIAOgIIALAWIAAgdgAhRBCQAFgXAAgYIASADQAAAbgEAWg");
	this.shape_12.setTransform(-19,9.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0066").s().p("AhPBAQASgNAGgOIgXAAIAAgVIAPAAIAAg4IgNAAIAAgWIANAAIAAgTIAYAAIAAATIARAAIAAgTIAYAAIAAATIAHAAIAAAWIgHAAIAAA4IAIAAIAAAUQACgIAAgRIAAhUIBEAAIAACBQAAALgEAFQgEAIgMgBIgPAAIgJgXIAMAAQAIAAgBgGIAAgZIgTAAQAAAOgFAOQgFARgHAKIgUgPIgNAHIgPgbIAUgIIgqAAIASAJQgLAVgSAPgAADA1QAEgFADgLIgQAAQAAAFAJALgAgnAQIARAAIAAgJIgRAAgAAkAFIATAAIAAgSIgTAAgAgngJIARAAIAAgIIgRAAgAgnghIARAAIAAgHIgRAAgAAkgiIATAAIAAgSIgTAAg");
	this.shape_13.setTransform(-37.7,9.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FF0066").s().p("AAvBRIAAgFIh1AAIAAgXIB1AAIAAgPIhuAAIAAgWIBuAAIAAgOIh1AAIAAgUIA8AAIAAg+IAZAAIAAA+IA3AAIAABjgAAZgjQAFgFAJgOQAIgNACgHIAVANQAAAHgKAOQgJAPgHAEgAg2gpQgJgNgFgEIAVgPQAFAFAIAOIAMAVIgUAMQgDgIgJgMg");
	this.shape_14.setTransform(-56.1,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66.8,-20.5,115.2,41);


(lib.vjv2023 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAhBNQgMgMAAgfQAAgfAMgLQANgLAUgBQAVABAMALQALALABAfQgBAggLAMQgMAMgVAAQgTAAgOgNgAA0AFQgHAHABAWQgBAWAHAGQAGAHAIgBQAIABAHgHQAFgGAAgWQAAgWgFgHQgHgFgIAAQgIAAgGAFgAhHBQICFinIAMAKIiFCngAhhAHQgNgLAAgeQAAgeANgMQALgNAVAAQAUAAANANQAMAMgBAeQABAfgMAMQgNAMgUAAQgUAAgMgOgAhPg/QgGAGgBAXQABAWAGAHQAGAFAIAAQAIAAAGgFQAHgHAAgWQAAgXgHgGQgGgFgIAAQgIAAgGAFg");
	this.shape.setTransform(0.1,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgkBLQgPgPAAgTIAAgIIAYAAIAAAHQAAANAJAJQAHAHAKAAQAMAAAJgIQAHgIABgRQgBgOgHgIQgJgJgKAAIgHAAIAAgQIAGAAQAIAAAJgIQAHgIAAgPQAAgNgHgJQgHgGgKAAQgIAAgHAHQgIAJgBASIgXAAQAAgYAPgPQAOgNASAAQAXAAANANQAMAMgBAVQABAUgKAKQgIAHgIABQALADAGAGQANANAAAUQAAAWgOAPQgOAOgZAAQgWAAgNgOg");
	this.shape_1.setTransform(-19.6,0.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0066").s().p("AAhBNQgMgMAAgfQAAgfAMgLQANgLAUgBQAVABAMALQALALABAfQgBAggLAMQgMAMgVAAQgTAAgOgNgAA0AFQgHAHABAWQgBAWAHAGQAGAHAIgBQAIABAHgHQAFgGAAgWQAAgWgFgHQgHgFgIAAQgIAAgGAFgAhHBQICFinIAMAKIiFCngAhhAHQgNgLAAgeQAAgeANgMQALgNAVAAQAUAAANANQAMAMgBAeQABAfgMAMQgNAMgUAAQgUAAgMgOgAhPg/QgGAGgBAXQABAWAGAHQAGAFAIAAQAIAAAGgFQAHgHAAgWQAAgXgHgGQgGgFgIAAQgIAAgGAFg");
	this.shape_2.setTransform(0.1,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0066").s().p("AgkBLQgPgPAAgTIAAgIIAYAAIAAAHQAAANAJAJQAHAHAKAAQAMAAAJgIQAHgIABgRQgBgOgHgIQgJgJgKAAIgHAAIAAgQIAGAAQAIAAAJgIQAHgIAAgPQAAgNgHgJQgHgGgKAAQgIAAgHAHQgIAJgBASIgXAAQAAgYAPgPQAOgNASAAQAXAAANANQAMAMgBAVQABAUgKAKQgIAHgIABQALADAGAGQANANAAAUQAAAWgOAPQgOAOgZAAQgWAAgNgOg");
	this.shape_3.setTransform(-19.6,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.1,-15,43.2,30);


(lib.vjv2021 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAhBNQgMgMAAgfQAAgfAMgLQANgLAUgBQAVABAMALQALALABAfQgBAggLAMQgMAMgVAAQgTAAgOgNgAA0AFQgHAHABAWQgBAWAHAGQAGAHAIgBQAIABAHgHQAFgGAAgWQAAgWgFgHQgHgFgIAAQgIAAgGAFgAhHBQICFinIAMAKIiFCngAhhAHQgNgLAAgeQAAgeANgMQALgNAVAAQAUAAANANQAMAMgBAeQABAfgMAMQgNAMgUAAQgUAAgMgOgAhPg/QgGAGgBAXQABAWAGAHQAGAFAIAAQAIAAAGgFQAHgHAAgWQAAgXgHgGQgGgFgIAAQgIAAgGAFg");
	this.shape.setTransform(0.1,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AADBYIAAiGIgdAAIAAgMIAJAAQAPgBAHgHQAIgJACgMIAMAAIAACvg");
	this.shape_1.setTransform(-20.6,0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0066").s().p("AAhBNQgMgMAAgfQAAgfAMgLQANgLAUgBQAVABAMALQALALABAfQgBAggLAMQgMAMgVAAQgTAAgOgNgAA0AFQgHAHABAWQgBAWAHAGQAGAHAIgBQAIABAHgHQAFgGAAgWQAAgWgFgHQgHgFgIAAQgIAAgGAFgAhHBQICFinIAMAKIiFCngAhhAHQgNgLAAgeQAAgeANgMQALgNAVAAQAUAAANANQAMAMgBAeQABAfgMAMQgNAMgUAAQgUAAgMgOgAhPg/QgGAGgBAXQABAWAGAHQAGAFAIAAQAIAAAGgFQAHgHAAgWQAAgXgHgGQgGgFgIAAQgIAAgGAFg");
	this.shape_2.setTransform(0.1,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0066").s().p("AADBYIAAiGIgdAAIAAgMIAJAAQAPgBAHgHQAIgJACgMIAMAAIAACvg");
	this.shape_3.setTransform(-20.6,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.1,-15,43.2,30);


(lib.vjv23t売上高2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAkBKIgCgSIAIAAQABAAABAAQAAAAAAAAQABAAAAAAQAAgBAAAAIACgDIAAgjIheAAIAAA5IgRAAIAAhIICAAAIAAA7IgBAFQgCAIgKAAgAgiBAIAAgrIBEAAIAAAmIg0AAIAAAFgAgSAsIAjAAIAAgIIgjAAgAgqgCIAAgjIBUAAIAAAjgAgbgQIA1AAIAAgIIg1AAgAhFgqIAAgQIA8AAIAAgPIAPAAQAHAAgBADIgDACIAAAKIA9AAIAAAQg");
	this.shape.setTransform(17.9,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhFBAIAAgSIA4AAIAAhtIAQAAQAHAAgCACIgCADIAAAjIAxAAIAAAUIgxAAIAAAxIBAAAIAAASg");
	this.shape_1.setTransform(-2.1,-0.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhIA2QAWgCAJgHQALgHAAgVIAAgMIAQAAQAGAAgBADIgDACIAAASQgBAog1AHgAARBIQgLgBAAgNIAAg1IAPAAQAGAAgBADIgDACIAAAmIABAEQAAAAAAAAQAAAAABAAQAAABABAAQAAAAABAAIAUAAQAEAAABgFIACgKIATAFIgEAPQgDAOgKAAgAAwASIAAgQIhiAAIAAAQIgTAAIAAggICIAAIAAAggAg2gTIAAgPIAsAAIAAgJIg4AAIAAgQIA4AAIAAgPIAOAAQAHAAgCADIgCADIAAAJIA8AAIAAAQIg8AAIAAAJIAwAAIAAAPg");
	this.shape_2.setTransform(-22,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.1,-10,64.2,20);


(lib.vjv23t売上原価 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag0BBIAAg/IgIAJIgHAHQgFADADgHIAIgPQAMgZAGgqIASAHQAEADgDADIgDABQgDALgGAQIACABQADACgEADIgCABIAABUQAAAAAAABQAAABAAAAQgBABAAAAQgBAAAAABIgGABIgDAAQgEAAAAgEgAgYBEQgDAAAAgEIAAhYIASAKIAHAAIAAghIgWAAIgCgEIBGAAIALgNIANAMIACABQABAAAAABQAAABAAAAQAAABgBAAQAAAAgBABIgiAAIAAAhIALAAIAFgKIAOANQAFAEgGADIgCAAIAABAQAAAAAAABQAAABgBAAQAAABAAAAQgBABAAAAIgGACQgHABAAgGIAAgFIg7AAIAAAGQAAAEgFABIgGABIgBAAgAAjA0IAMAAIAAg+IgMAAgAANA0IAHAAIAAg+IgHAAgAgMA0IAKAAIAAg+IgKAAgAANgOIAHAAIAAghIgHAAg");
	this.shape.setTransform(22.5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgCBAIAAgFQgCgCgIgDIgJgEQAAgBAAAAQAAAAAAAAQABgBAAAAQABAAABAAIAOABQAHAAAAgEIAAgjIgSAAIAAADQAAADgDACIgKABQgBAAgBAAQAAAAgBAAQAAgBAAAAQAAAAAAgBIAAg3IASAHIAIAAIAEgSIgmAAIgBAqQAAANgDALQgDAPgHAMQgJAPgFAEQgDACABgFIAEgIQAIgUABgfQACgfgDggIAVAJIBQAAIALgNIAOAMQAEAEgFABIgwAAIgRASIAfAAIAFgJIAQANQAEADgGAEIgBABIAAAfQAAAAAAABQAAAAAAABQgBAAAAABQAAAAAAAAIgIACQgHABAAgEIAAgEIgSAAIAAArQAAAGgEADQgDACgHADIgEAAQAAAAAAAAQgBAAAAAAQAAgBgBAAQAAgBAAgBgAgPAGIAzAAIAAgOIgzAAgAgPgMIAzAAIAAgPIgzAAgAgxA8IAKgMIAHgKIAJgTIAPAKQAGAEgIADIgEABQgPAPgUAMIgCAAQgCAAAEgEgAAwA5QgGgMgEgGQgGgHgIgGQgGgEAHABQAiAIAFATQABAFgCAEQgCAEgFAAIgBAAQgEAAgDgGg");
	this.shape_1.setTransform(7.3,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhCA/IgCgEIA6AAIAAh5IAUADQAFABgEAHIgEACIAAApIAcAAIAJgNIAOAMQAEAEgFABIgyAAIAAA/IAjAAIAMgPIANANQAEAFgFABg");
	this.shape_2.setTransform(-7.6,-0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag4BAQASgIAIgNQAHgOAAgYIATADQADADgDAEIgDACQgBAKgCAHQgDANgHAGQgHAHgLADQgJAEgLACQgGAAAIgFgAAUBCIgLgDQgEgCAAgGIAAg0IAUADQAEACgDAFIgDADIAAAeQAAAFAEAAQANABAHgBQABgBAAAAQABAAAAAAQABgBAAAAQABAAAAgBQADgEAHgRQAAAAABgBQAAgBABAAQAAAAAAAAQABAAAAABIAAABIgBAQIAAAFIAEAFQAHAHgNAEIgMACIgPAAIgOAAgAAnASIAHgSIhdAAQABAJgCAEQgDAJgHABQgIACgCgHQgDgGAGgFIAFgFQAIgFgBgJQAAgBAAAAQABgBAAAAQAAAAABABQAAAAAAABQADADABAFIBdAAIAGgKIAQAPQAFAFgHACIgHABIgUAOIgCABQgBAAADgGgAg2gSIgBgFIAtAAIAAgSIg2AAIgDgEIA5AAIAAgXIAVADQADAAgCAFIgEADIAAAMIAfAAIAKgOIAPAOQAEADgGABIg2AAIAAASIAXAAIAJgNIAOAMQAEAEgFACg");
	this.shape_3.setTransform(-22.5,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.1,-9.5,64.2,19);


(lib.vjv23t売上総利益 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhDBIIAAgQIAVAAIAAgmQgIAHgKAFIgKgQQAOgGAKgIQANgLAGgPIgjAAIAAgQIAlAAQgDgIgHgJIAOgJQAMANAEANIAQAAQAHgMAFgRIAPAFQABABAAAAQABAAAAABQABAAAAABQAAAAAAABIAAABIgDACIgJARIAoAAIAAAQIgiAAQANAaAfAMIgLAQQgJgEgKgIIAAAoIAWAAIAAAQgAAUA4IAKAAIAAgjIgKAAgAgEA4IAIAAIAAgjIgIAAgAgdA4IAIAAIAAgjIgIAAgAggAFIBBAAIgHgIQgHgJgGgOIgaAAQgJAWgKAJg");
	this.shape.setTransform(34.9,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghBHIAAg2QgMARgOAKIgKgQQAJgFAGgJQANgNAHgQIghAAIAAgQIAiAAIAAgPIgbABIgEgQQAkgBAcgIIAKAOQADADgCACIgFAAIgVACIAAASIAeAAIAAAQIgeAAIAAAKIAGAEQALAFANANIgMAOQgJgKgJgHIAAA5gAAlBGIgCgRIAMAAQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIAAgDIAAhzIAPAAQAIABgFAEIAAB3IgBAFQgCAIgKAAgAATAoIAAhbIAPAAQAHAAgFAFIAABWg");
	this.shape_1.setTransform(16.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgyBLIAAhCIgPABIgCADIgCABIgBgBQgBgBgBgEIgCgNIAOAAIAIgLIgVgRIAJgMIAEADIAUggIANAHIADADIAAACIgDAAIgUAdIAFAEQAJgNAHgNIALAFIADADIAAACIgCABIgaAmIAMgBIgEgIIANgFQALARABAOIgPAEIgCgIIgIAAIAAAPIANgFIADAGIAEAQQACgHAAgHIAPAEQgBATgFARIgQgGIAEgOIgMAFQgCgNgFgNIAAAzgAATBGQgMgBAAgMIAAgmIALAAIAEABIgFgFIAMgIIAQATIgNAJQgDgGgFgFIgBABIAAAZIABAEQAAAAAAAAQAAAAABAAQAAABABAAQAAAAABAAIAJAAQABAAAAAAQABgBAAAAQAAAAABgBQAAAAAAgBIAAgJIAQACIgBgDQgFgIgEgEIAMgKQAMAOAGANIgNAKIgFgKIgCALIgBAHQgDAFgHAAgAhKA7QAFgQAAgaIAPADQAEACAAACIgCACQgBATgEASgAAsAFIgsAEIgCACQAAAAAAABQgBAAAAgBQAAAAgBAAQAAAAAAgBIgBgDIgEgNIANAAQAGgQACgRIANAEQAEABABABIAAACIgDABIgIAXIAQAAIgEgFIAKgIQAKAKAKAMIgMAKgAApgiQgIgLgDgPIAQgGQAGAcAWANIgMAPQgLgJgKgPgAgVgWQAGgFAFgKQAKgPACgNIAPAGQAFAEgDABIgCAAQgMAZgNASg");
	this.shape_2.setTransform(-1.1,-0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFBAIAAgSIA4AAIAAhtIAQAAQAHAAgCACIgCADIAAAjIAxAAIAAAUIgxAAIAAAxIBAAAIAAASg");
	this.shape_3.setTransform(-19.1,-0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhIA2QAWgCAJgHQALgHAAgVIAAgMIAQAAQAGAAgBADIgDACIAAASQgBAog1AHgAARBIQgLgBAAgNIAAg1IAPAAQAGAAgBADIgDACIAAAmIABAEQAAAAAAAAQAAAAABAAQAAABABAAQAAAAABAAIAUAAQAEAAABgFIACgKIATAFIgEAPQgDAOgKAAgAAwASIAAgQIhiAAIAAAQIgTAAIAAggICIAAIAAAggAg2gTIAAgPIAsAAIAAgJIg4AAIAAgQIA4AAIAAgPIAOAAQAHAAgCADIgCADIAAAJIA8AAIAAAQIg8AAIAAAJIAwAAIAAAPg");
	this.shape_4.setTransform(-37,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.1,-10,94.2,20);


(lib.vjv23t営業利益 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhDBIIAAgQIAVAAIAAgmQgIAHgLAFIgJgQQAOgGAKgIQAOgLAFgPIgjAAIAAgQIAlAAQgDgIgHgJIAPgJQAMANADANIAQAAQAHgMAGgRIAOAFQABABAAAAQABAAAAABQABAAAAABQAAAAABABIAAABIgEACIgJARIAoAAIAAAQIgiAAQAOAaAeAMIgLAQQgJgEgJgIIAAAoIAVAAIAAAQgAAUA4IAKAAIAAgjIgKAAgAgEA4IAIAAIAAgjIgIAAgAgeA4IAJAAIAAgjIgJAAgAggAFIBBAAIgHgIQgHgJgGgOIgaAAQgJAWgKAJg");
	this.shape.setTransform(27.9,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghBHIAAg2QgMARgOAKIgKgQQAJgFAGgJQANgNAHgQIghAAIAAgQIAiAAIAAgPIgbABIgEgQQAkgBAcgIIAKAOQADADgCACIgFAAIgVACIAAASIAeAAIAAAQIgeAAIAAAKIAGAEQALAFANANIgMAOQgJgKgJgHIAAA5gAAlBGIgCgRIAMAAQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIAAgDIAAhzIAPAAQAIABgFAEIAAB3IgBAFQgCAIgKAAgAATAoIAAhbIAPAAQAHAAgFAFIAABWg");
	this.shape_1.setTransform(7.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgIBKIAAggIgKAIQgTAMgaAHIgHgRQARgEAPgGQAOgGAIgHIg2AAIAAgPIA+AAIAAgFIgpAAIAAgOIApAAIAAgFIgwAAIAAgPIAfAAIgDgHIgqAAIAAgPIAdAAIgKgKIALgKQALAIAHAJIgFADIAGAAIAAgaIAPAAQAHABgEAEIAAAVIAGAAIAAgaIAPAAQAHABgFAEIAAAVIAIAAIgFgDQAHgHAIgLIALAIIADADQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAgBAAIgHAIIAcAAIAAAPIgpAAIgDAHIAeAAIAAAPIgvAAIAAAFIAoAAIAAAOIgoAAIAAAFIA9AAIAAAPIgyAAQAJAHAPAGQAQAHAMACIgFARQghgGgZgVIAAAhgAgIgZIARAAIACgHIgWAAg");
	this.shape_2.setTransform(-12,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Ag4BKIAAgzIAuAAIACgJIgPAAIAAADIgSAAIAAgpIBTAAIAAApIgRAAIAAgDIgRAAIgBAJIAzAAIAAAyIgRAAIAAgDIhQAAIAAAEgAgnA1IBQAAIAAgOIhQAAgAgXgBIAwAAIAAgIIgwAAgAA0gLIAAgSIhoAAIAAASIgRAAIAAgjIAgAAIgBgCQgDgEgHgHIAMgKQAMAJAEAJIgJAFIAdAAQgEgIgJgIIAMgKIAEADQAHAHAFAIIgMAIIAUAAQAHgLAFgQIAOAGIADACQAAABABAAQAAAAAAABQAAAAAAABQAAAAgBABIgCABIgJAOIAdAAIAAAjg");
	this.shape_3.setTransform(-32.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,-10,84.2,20);


(lib.vjv23t販売費及び一般管理費 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhABDQARgHAJgHQAGgEAGgHIAPAIQAFAEgHACIgEAAQgMAGgKADQgOAFgJAAIgBAAQgEAAADgDgAAwBEIgPgJQgIgFgPgFQgHgCAEgBIADAAQATAAAMADIAKACQAFADACAEQADAGgEADQgCACgDAAIgEgBgAguAsIAAgnQgIADgIABQgHACgBgCQAAAAAAAAQAAgBABAAQAAAAABgBQAAAAABAAIARgHQAQgKAGgKIgSAAIgBAHQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAIgFAAQgJAAACgGIAHgdIAQAIIAPAAIABgLIgqAAIgDgEIAtAAIAAgQIARACQAGACgFAEIgEACIAAAGIAQAAIAAgRIASACQAFACgEAEIgDACIAAAHIASAAIAEgHIAOALQAEACgFADIgCABIgDALQgBAEgLAAQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBgBAAAAIABgDIgPAAIAAAJIAcAAIAGgHIAMALQAEAEgFACIgDABQgEANgFACQgFAEgDgEQgEgFgIgEQgMgHAIABIAJACQAFAAABgCIADgHIgbAAIAAANQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAIgFABQgJACAAgEIAAgPIgUAAQgFAMgNAFIADADIA5AAIAFgHIAOAMQABAAAAABQABAAAAAAQAAABgBABQAAAAgBABIgCABIAAAeQAAADgGACQgJACAAgEIAAgCIg+AAIAAADQAAACgIACIgDAAQgEAAAAgEgAgfAlIA+AAIAAgKIg+AAgAgfAXIA+AAIAAgIIg+AAgAgfALIA+AAIAAgIIg+AAgAgLgYIASAAIAAgJIgRAAIgBAJgAgtgYIASAAQADgGAAgDIgTAAgAAXglIAQAAIACgLIgSAAgAgJglIAQAAIAAgLIgQAAIAAALg");
	this.shape.setTransform(67.3,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgXBAIgDgEIArAAIAAgaIgcAAIgCgEIAeAAIAAgUIgOAAIAAAFQAAAGgMAAQgBAAAAgBQgBAAAAAAQgBgBAAAAQAAgBAAAAIAAhPIAQAHIArAAIAFgJIAPANQAEADgGAFIgBABIAAAzQAAAEgDAAIgKACQgBAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIAAgDIgPAAIAAAUIAMAAIAJgMIAOAMQAEADgFABIgiAAIAAAaIANAAIALgNIAMALQAFAEgGACgAAhAFIAPAAIAAgZIgPAAgAADAFIAOAAIAAgZIgOAAgAAhgXIAPAAIAAgbIgPAAgAADgXIAOAAIAAgbIgOAAgAg8AzIgKgOIAUgFIAAglIgQAAIgCgEIASAAIAAgiIgRAAIgDgFIAlAAIAHgKIAMAKQADAEgEABIgTAAIAAAiIACAAIAIgLIAKALQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAIgSAAIAAAiIAVgGQAKgBgGAEIgNAHQgRAJgLAGIgCACQgCAEgCAAQAAAAgBAAQAAAAgBgBQAAAAgBgBQAAAAgBgBg");
	this.shape_1.setTransform(52.2,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgkBGQgCgBAAgEIAAhKIASAJIAnAAIAFgJIAOAKIACACIAGgPIhZAAQAAAMgIADQgGADgEgCQgHgFAHgHIAFgFQAFgDABgHIAAgEQAAAAAAgBQAAAAABAAQAAgBAAAAQAAAAABAAQAEADABAKIAkAAIAAgKIgHAEIgCABQgBABAAAAQgBAAAAgBQAAAAABgBQAAgBABgBIADgDIAMgQIgdAAQALAGAAAIQAAADgCADQgDAEgFgBQgFgCAAgIQABgIgEgGIgBAAIgPAPQgIAHgGADQgEACADgFQAIgJAGgKQAGgKAFgTIAPAHQAGAFgFACIgCABIgGAIIAPAAIAKgNIALAMQADgFAHgQIARAIQAFAEgHACIgEABIgFAHIAaAAIALgOIAOANQAEAEgFABIgnAAQAKAEACAGQADAKgKADQgHAAgBgJIgBgIQgBgDgDgDIgHAAIgLAJIAIACQAEADgEADIgDABIAAAJIAoAAIAHgKIAOAPQAEAFgFABIgIAAIgTALIgCACIgCABIAAANQAAABAAAAQAAABAAAAQAAABgBAAQAAAAgBABQgDABgJABQAAAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgCIgqAAIAAAOIAvAAIAFgJIAPANQAFAEgGADIgCAAIAAAQIgCADQgEACgIAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQAAAAAAgBIAAgEIgwAAIAAADQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBAAQgFADgEAAIgEgBgAgWA6IAwAAIAAgRIgwAAgAgWATIAqAAIAAgQIgqAAg");
	this.shape_2.setTransform(37.2,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhAA8QAGgOABgkIgCAAIgBADQgBABAAAAQgBABAAAAQgBgBAAAAQgBgBgBgBIgGgPIAPAAIAAgcIgBgUIAPAHIADgYIAPAFQAEACgDAEIgDACIgJALIANAAIAGgJIAMAMQACAEgDACIgCAAIAAAgIABAAIAHgMQAEgJAAgOIABgYIAOAHIALAAIAFgJIAMAMQAEACgEADIgDACIAAAVQAAABAAAAQAAABAAAAQABABAAAAQAAAAABAAQAGACADgFIAFgPQADgGABAHIgBAGIAAAGIABAFIACABQAEAFgEAEQgGAFgVgCQgFgBgCgBQgCgCAAgFIAAgiIgLAAIgBAUQgCAKgEAFQgFAHgIAGIABgBQAIABgJADIgHABIAAA0QAAAEgCADQgFAFgGACQgGACAAgFIAAgDIgCgCIgFgCIgKgEQAAgBAAAAQAAgBAAAAQABAAAAAAQABgBABAAIAPABQAGAAAAgFIAAgqIgHABIAAAjIgBADIgEACQgHACAAgFIAAgjIgFABQgBAZgFAMQgFAQgLAHIgBABQgCAAAEgJgAgsgCIAZgBIAAglIgZAAgAgIBBQAPgLANgPQgKgPgEgRIgIAAIgCgEIAqAAIAHgHIANALQAEADgIAEQgHAMgJAMQANAHAVADQgJAGgFALQgGgCgIgFQgIgEgHgHQgPANgQAGIgGACQgBAAAAAAQgBAAAAgBQAAAAABgBQAAAAABgBgAAbAeQAIgNADgKIgbAAQAFAPALAIgAglgOQgBgLgCgDQgEgIAFACQAMAFACAJQADALgKABQgEAAgBgGg");
	this.shape_3.setTransform(22.3,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhDALIgBgEIBpAAIAOgRIAQAPQAFAEgGACg");
	this.shape_4.setTransform(7.2,-0.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUBCQgSgDgIgLQgKgMABgSQABgOAIgPQAGgMAJgOIgHAEIgMAGIgFACQgDgBgGgHQgFgHABgGQABgBAAAAQAAgBABAAQAAgBABAAQAAgBAAAAQACAGAFACQADACAQgFQALgDAHgFQAEgDAHADQAIADgBAFQAAADgGAEIgFADQgVAQgHARQgHATAHAOQAKARAagEQASgDAGgUQAFgOgBgSQgBgKgFgOIgHgNQgBgDAEgDQAKgGAEAHIAFAOIAEAFQAIANAKAJIALAJQAGAFgDAJQgBADgDACQgEAEgGgIIgGgHQgKgNgMgXIAFAYQABAIAAAKQAAALgCAJQgGAUgTAIQgIADgKAAIgGAAgAArgjIgHgQIgDgCQgEgDAEAAQAGABAFADQAGADADAFQAFAIgGAEIgDABQgEAAgCgEgAA5gwIgCgFQgFgHgGgDQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQADgBAKADQALACACAIQAAADgCADQgCADgDAAQgCAAgDgEg");
	this.shape_5.setTransform(-7.5,-0.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgvA/QAXgJAKgHQALgHAJgKQgIgKgFgJQgGgJgHgQIgEAVQgGATgHALQgNAUgRAIQgGAFAJgNQASgTAHghQAFgXABgiIgZAAIgDgEIBIAAIAGgJIAOAMQAEADgFADIgEADIgIAXIAOAAIAGgIIAPAOQAEAEgFABIgEACQgLATgNARQAVANAZAFIgGAEQgGAEgEAIQgXgJgRgOQgJAIgMAHQgSAJgSADIgDAAQgFAAAEgDgAgTgVIAOAWQAHAKALAJQALgPAJgWIgRAAIgCAFQgBAGgKgCQgIgBAEgHIADgIIAJgcIgbAAg");
	this.shape_6.setTransform(-22.3,0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhABDQARgHAJgHQAGgEAGgHIAPAIQAFAEgHACIgEAAQgMAGgKADQgOAFgJAAIgBAAQgEAAADgDgAAwBEIgPgJQgIgFgPgFQgHgCAEgBIADAAQATAAAMADIAKACQAFADACAEQADAGgEADQgCACgDAAIgEgBgAguAsIAAgnQgIADgIABQgHACgBgCQAAAAAAAAQAAgBABAAQAAAAABgBQAAAAABAAIARgHQAQgKAGgKIgSAAIgBAHQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAIgFAAQgJAAACgGIAHgdIAQAIIAPAAIABgLIgqAAIgDgEIAtAAIAAgQIARACQAGACgFAEIgEACIAAAGIAQAAIAAgRIASACQAFACgEAEIgDACIAAAHIASAAIAEgHIAOALQAEACgFADIgCABIgDALQgBAEgLAAQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBgBAAAAIABgDIgPAAIAAAJIAcAAIAGgHIAMALQAEAEgFACIgDABQgEANgFACQgFAEgDgEQgEgFgIgEQgMgHAIABIAJACQAFAAABgCIADgHIgbAAIAAANQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAIgFABQgJACAAgEIAAgPIgUAAQgFAMgNAFIADADIA5AAIAFgHIAOAMQABAAAAABQABAAAAAAQAAABgBABQAAAAgBABIgCABIAAAeQAAADgGACQgJACAAgEIAAgCIg+AAIAAADQAAACgIACIgDAAQgEAAAAgEgAgfAlIA+AAIAAgKIg+AAgAgfAXIA+AAIAAgIIg+AAgAgfALIA+AAIAAgIIg+AAgAgLgYIASAAIAAgJIgRAAIgBAJgAgtgYIASAAQADgGAAgDIgTAAgAAXglIAQAAIACgLIgSAAgAgJglIAQAAIAAgLIgQAAIAAALg");
	this.shape_7.setTransform(-37.3,0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("Ag4BAQASgIAIgNQAHgOAAgYIATADQADADgDAEIgDACQgBAKgCAHQgDANgHAGQgHAHgLADQgJAEgLACQgGAAAIgFgAAUBCIgLgDQgEgCAAgGIAAg0IAUADQAEACgDAFIgDADIAAAeQAAAFAEAAQANABAHgBQABgBAAAAQABAAAAAAQABgBAAAAQABAAAAgBQADgEAHgRQAAAAABgBQAAgBABAAQAAAAAAAAQABAAAAABIAAABIgBAQIAAAFIAEAFQAHAHgNAEIgMACIgPAAIgOAAgAAnASIAHgSIhdAAQABAJgCAEQgDAJgHABQgIACgCgHQgDgGAGgFIAFgFQAIgFgBgJQAAgBAAAAQABgBAAAAQAAAAABABQAAAAAAABQADADABAFIBdAAIAGgKIAQAPQAFAFgHACIgHABIgUAOIgCABQgBAAADgGgAg2gSIgBgFIAtAAIAAgSIg2AAIgDgEIA5AAIAAgXIAVADQADAAgCAFIgEADIAAAMIAfAAIAKgOIAPAOQAEADgGABIg2AAIAAASIAXAAIAJgNIAOAMQAEAEgFACg");
	this.shape_8.setTransform(-52.3,0.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgZBEQAAAAAAgBQgBAAABAAQAAgBAAAAQAAgBAAAAIADgDQAKgNAEgTQADgPAAgXIAAg2IAQAIIAgAAIAKgNIAMAMQADAEgFABIg3AAIAAAhIAfAAIAHgJIANANQADADgEADIgCABQgIAYgIALQAKAKAUAJQgIAGgEAKQgRgMgJgLQgMAOgUAKQgQAHANgLQAOgIAOgXQgIgOgDgSIgCgLIgEAAIgBAXQAAAKgEALQgDAMgIAKIgIAJQgGAGgCAAIgBAAgAAVADQADAIAHAIQAHgRADgPIgaAAIAGAQgAhFBBQALgPAEgQQgIABAAgGIAAhdIAPAIIAQAAIAEgIIAPAMQABAAAAABQAAAAAAABQAAABAAAAQgBABgBAAIgDACIAABIQAAABAAABQAAAAAAABQAAAAAAAAQgBABAAAAIgEABQgJACAAgFIAAgCIgSAAIAAAGIAKAHQADAEgEABIgEACQgHAIgNALIgGADQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBgAgwAWIASAAIAAgWIgSAAgAgwgEIASAAIAAgVIgSAAgAgwgeIASAAIAAgWIgSAAgAgeAxIgBgEQgCgGgGgFQgGgFAKACQAQAEADAIQACAIgHADIgDABQgFAAgBgGg");
	this.shape_9.setTransform(-67.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.8,-9.5,153.8,19);


(lib.vjv23t当期純利益 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhDBIIAAgQIAVAAIAAgmQgIAHgKAFIgKgQQAOgGAKgIQANgLAGgPIgjAAIAAgQIAlAAQgDgIgHgJIAOgJQAMANAEANIAQAAQAHgMAFgRIAPAFQABABAAAAQABAAAAABQABAAAAABQAAAAAAABIAAABIgDACIgJARIAoAAIAAAQIgiAAQANAaAfAMIgLAQQgJgEgKgIIAAAoIAWAAIAAAQgAAUA4IAKAAIAAgjIgKAAgAgEA4IAIAAIAAgjIgIAAgAgdA4IAIAAIAAgjIgIAAgAggAFIBBAAIgHgIQgHgJgGgOIgaAAQgJAWgKAJg");
	this.shape.setTransform(34.9,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghBHIAAg2QgMARgOAKIgKgQQAJgFAGgJQANgNAHgQIghAAIAAgQIAiAAIAAgPIgbABIgEgQQAkgBAcgIIAKAOQADADgCACIgFAAIgVACIAAASIAeAAIAAAQIgeAAIAAAKIAGAEQALAFANANIgMAOQgJgKgJgHIAAA5gAAlBGIgCgRIAMAAQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIAAgDIAAhzIAPAAQAIABgFAEIAAB3IgBAFQgCAIgKAAgAATAoIAAhbIAPAAQAHAAgFAFIAABWg");
	this.shape_1.setTransform(16.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgtBKIAAhAIgSACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgCAAgCgFIgDgMIAOAAIAJgMQgJgLgMgJIAJgMIAFAFIAUggIANAIIACACIgBACIgDABIgUAcIAGAFIASgZIAMAIQAQAAAQgDIAAgZIAOAAQAHABgFAFIAAARQAPgCANgFIAIANQADAFgDABQgCABgDgCIgfAFIAAAxIALAAIAAguIANAAQAIABgFAEIAAA5IgbAAIAAATIABADQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAIAKAAIACgBIACgCIACgLIAQAHIgDAMIgCACQgCAFgDACQgDABgEAAIgXAAQgMAAAAgNIAAgZIgJAAIAAAKIgPAAIAAhDIANAAQAHABgFAEIAAAkIAJAAIAAguIgeADIgCgNQgRASgOATIAQgBIgFgLIAMgFQALAPAEAMIgOAHIgCgHIgKACIAABBgAhKA5IAFgNQAEgPAAgMIAOACIADACIABADIgCACIgCAOQgDAQgGALgAgYAVIAPgCQAFANAAAVIgQADQABgSgFgRg");
	this.shape_2.setTransform(-1,-0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgHA9QAJgIAGgIQALgNAAgNIAAhWIA0AAIAAB+IgBAFQgCAIgKAAIgQAAIgCgSIAKAAQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIAAgDIAAgdIgQAAIAAACQAAAHgDAIQgFASgaAUgAAlAEIAQAAIAAgTIgQAAgAAlgfIAQAAIAAgTIgQAAgAhEA7QAHgFAJgMQAGgIACgFIgaAAIAAgPIATAAIAAgzIgPAAIAAgPIAPAAIAAgVIAOAAQAHABgFAEIAAAQIATAAIAAgWIAOAAQAHABgFAEIAAARIANAAIAAAPIgNAAIAAAzIAPAAIAAAPIgYAAQAJAIAGAHIgMAMIgRgSIAMgJIgcAAIAMAGIgHAOQgKAOgLAJgAgjAOIATAAIAAgJIgTAAgAgjgJIATAAIAAgGIgTAAgAgjgeIATAAIAAgHIgTAAg");
	this.shape_3.setTransform(-19.4,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAsBFIAAgHIhoAAIAAgRIBoAAIAAgPIhgAAIAAgRIBgAAIAAgNIhoAAIAAgSIAzAAIAAgyIAQAAQAGgBgBAEIgDACIAAAtIAZAAIgPgIQALgSAHgTIAOAHIACABQAEADgBACQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAgBAAQgFANgMASIAaAAIAABXgAg2gxIAPgKQAKAMAKARIgPALQgKgSgKgMg");
	this.shape_4.setTransform(-37.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.1,-10,94.2,20);


(lib.vjv23t経常利益 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhDBIIAAgQIAVAAIAAgmQgIAHgLAFIgJgQQAOgGAKgIQAOgLAFgPIgjAAIAAgQIAlAAQgDgIgHgJIAPgJQAMANADANIAQAAQAHgMAGgRIAOAFQABABAAAAQABAAAAABQABAAAAABQAAAAABABIAAABIgEACIgJARIAoAAIAAAQIgiAAQAOAaAeAMIgLAQQgJgEgJgIIAAAoIAVAAIAAAQgAAUA4IAKAAIAAgjIgKAAgAgEA4IAIAAIAAgjIgIAAgAgeA4IAJAAIAAgjIgJAAgAggAFIBBAAIgHgIQgHgJgGgOIgaAAQgJAWgKAJg");
	this.shape.setTransform(27.9,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghBHIAAg2QgMARgOAKIgKgQQAJgFAGgJQANgNAHgQIghAAIAAgQIAiAAIAAgPIgbABIgEgQQAkgBAcgIIAKAOQADADgCACIgFAAIgVACIAAASIAeAAIAAAQIgeAAIAAAKIAGAEQALAFANANIgMAOQgJgKgJgHIAAA5gAAlBGIgCgRIAMAAQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIAAgDIAAhzIAPAAQAIABgFAEIAAB3IgBAFQgCAIgKAAgAATAoIAAhbIAPAAQAHAAgFAFIAABWg");
	this.shape_1.setTransform(7.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgHBJIAAgnIgfAAIAAAfIgSAAIAAguIAxAAIAAgGIghAAIAAglIBQAAIAAAlIgeAAIAAAGIAyAAIAAAiIgBAFQgCAIgJAAIgTAAIgCgSIAMAAIADgBIAAgDIAAgKIggAAIAAAngAgWgBIAtAAIAAgKIgtAAgAhFgLIAAgiIAhAAIgNgOIANgKQAMAJAHAKIgJAFIATAAIAAgbIAOAAQAHAAgEAFIAAAWIAPAAIgHgFIAPgVIANAJIACAEQAAAAAAABQAAAAgBAAQAAAAgBABQAAAAgBAAIgIALIAhAAIAAAiIgSAAIAAgTIhnAAIAAATg");
	this.shape_2.setTransform(-12.1,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgxBKIAAhDIgSABQAAABgBABQAAABgBAAQAAAAgBAAQAAAAgBgBIgBgCIgEgQIASAAIAGgJIgWgSIAKgNIAFAEQAJgOAIgPIAOAGIACACQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAIgCAAQgKAOgLANIAGAGQAIgKAKgQIANAKQAEADgCABIgFABIgZAgIAMgBIgFgIIAMgHQALALAHATIgQAHIgDgJIgLABIAABFgAgMBFIAAgQIAgAAIAAgXIgYAAIAAgRIAYAAIAAgQIAQAAQAHABgFADIAAAMIAbAAIAAARIgbAAIAAAXIAjAAIAAAQgAhMA4IAEgKQACgNAAgUIAQAFQAHACgFADQgCAUgGAUgAgfASIAPgFIADAHQAGANABAPIgSADQAAgPgHgSgAAegLQgNAKgRAHIgHgPIATgJIAGgEIgHgJQgFgHgEgLIgHAAIAAgPIA3AAIACgDIALAKQAFAEgGAAQgIAVgKAKIADADIAUAHIAKACIgFAQQgXgDgTgOgAAWgrQADAGAFAFQAHgFACgGIACgGIgWAAIADAGg");
	this.shape_3.setTransform(-32.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,-10,84.2,20);


(lib.vjv23t650000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(23.6,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(14.9,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(6.2,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAFgUIgIAAIAAgTIATAAIAAASIgIAVg");
	this.shape_3.setTransform(-0.1,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-6,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUA4QgLgKgCgUIAQAAQACAOAFAFQAFAFAFAAQAHgBAEgFQAHgGgBgRQABgPgHgGQgFgEgGAAQgLAAgGAKIgPAAIAEhGIA3AAIAAAQIgmAAIgEAjQAJgGAKAAQAKAAAKAJQAKAKAAAVQAAAYgKAKQgKAJgOAAQgNABgHgJg");
	this.shape_5.setTransform(-14.7,-0.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgVA4QgNgOAAgnQAAgrAOgOQAKgKAMAAQAMAAAIAHQAIAJACAPIgQAAQgCgIgDgDQgEgEgFAAQgFAAgEAFQgJAIgCAaQAJgMALAAQAMAAAJAKQAMALAAAVQAAAXgMAMQgJAJgNAAQgMAAgKgJgAgJAAQgGAGAAAPQAAAQAGAGQAFAGAFAAQAGAAAFgGQAHgHAAgPQAAgNgHgIQgFgEgGAAQgFAAgFAEg");
	this.shape_6.setTransform(-23.4,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.9,-10,59.9,20);


(lib.vjv23t600000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(23.6,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(14.9,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(6.2,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAFgUIgIAAIAAgTIATAAIAAASIgIAVg");
	this.shape_3.setTransform(-0.1,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-6,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_5.setTransform(-14.7,-0.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgVA4QgNgOAAgnQAAgrAOgOQAKgKAMAAQAMAAAIAHQAIAJACAPIgQAAQgCgIgDgDQgEgEgFAAQgFAAgEAFQgJAIgCAaQAJgMALAAQAMAAAJAKQAMALAAAVQAAAXgMAMQgJAJgNAAQgMAAgKgJgAgJAAQgGAGAAAPQAAAQAGAGQAFAGAFAAQAGAAAFgGQAHgHAAgPQAAgNgHgIQgFgEgGAAQgFAAgFAEg");
	this.shape_6.setTransform(-23.4,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.9,-10,59.9,20);


(lib.vjv23t520000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQAMALADAaQABALgBAKQgDAbgMAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHABAoQgBApAIAHQADADACAAQADAAADgDQAIgHAAgpQAAgogIgHQgDgDgDAAQgCAAgDADg");
	this.shape.setTransform(21.5,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQALALAEAaQABALgBAKQgEAbgLAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHAAAoQAAApAIAHQACADADAAQADAAADgDQAIgHgBgpQABgogIgHQgDgDgDAAQgDAAgCADg");
	this.shape_1.setTransform(13.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAGgHAIAAQAJAAAHAHQALALADAaQABALgBAKQgDAbgLAMQgIAHgIAAQgHAAgHgHgAgGgvQgGAHAAAoQAAApAGAHQAEADACAAQAEAAADgDQAGgHABgpQgBgogGgHQgDgDgEAAQgCAAgEADg");
	this.shape_2.setTransform(5.9,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgJAUQAMgJADgLQgGAFgIgEQgHgDAAgIQABgKAKgDQAEgBAFABQAGADADAFQAFAOgLANQgFAHgIAFg");
	this.shape_3.setTransform(0,4.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAGgHAIAAQAJAAAHAHQAKALAEAaQABALgBAKQgEAbgKAMQgIAHgIAAQgHAAgHgHgAgGgvQgGAHgBAoQABApAGAHQADADADAAQADAAAEgDQAGgHAAgpQAAgogGgHQgEgDgDAAQgDAAgDADg");
	this.shape_4.setTransform(-5.9,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgeA3IAAgFIAIgLIAVgbQAFgHAEgJQAFgKAAgLQAAgNgGgFQgEgFgGABQgHgBgFAGQgFAEgCAGQAGgBADADQADADgBAEQABAGgDADQgDADgDAAQgDAAgDgDQgDgDgBgIQAAgLALgKQAJgJAKABQANgBAIAJQAJAIAAAOQAAAPgMAKIgMALQgNANgJAMIAfAAQAFAAADgGIADgLIAEAAIgDAjg");
	this.shape_5.setTransform(-13.5,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgWAwQgGgHAAgJQAAgGADgEQACgCAEAAQAEAAACACQADADAAAFQAAAEgDADQgEAEgEgBQAEAKALAAQALAAAFgQQAFgSgFgNQgFgMgJAAQgJAAgHALIgEAAIADg4IAwAAIgCANQgBAFgFAAIgkAAIgDAfQAJgMALAAQALAAAJAJQAJAIAAASQAAASgKAKQgJAJgNAAQgMAAgHgHg");
	this.shape_6.setTransform(-21.4,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.5,-9.5,55,19);


(lib.vjv23t360000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQAMALADAaQABALgBAKQgDAbgMAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHABAoQgBApAIAHQADADACAAQADAAADgDQAIgHAAgpQAAgogIgHQgDgDgDAAQgCAAgDADg");
	this.shape.setTransform(21.5,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQALALAEAaQABALgBAKQgEAbgLAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHAAAoQAAApAIAHQACADADAAQADAAADgDQAIgHgBgpQABgogIgHQgDgDgDAAQgDAAgCADg");
	this.shape_1.setTransform(13.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAGgHAIAAQAJAAAHAHQALALADAaQABALgBAKQgDAbgLAMQgIAHgIAAQgHAAgHgHgAgGgvQgGAHAAAoQAAApAGAHQAEADACAAQAEAAADgDQAGgHABgpQgBgogGgHQgDgDgEAAQgCAAgEADg");
	this.shape_2.setTransform(5.9,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgJAUQAMgJADgLQgGAFgIgEQgHgDAAgIQABgKAKgDQAEgBAFABQAGADADAFQAFAOgLANQgFAHgIAFg");
	this.shape_3.setTransform(0,4.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAGgHAIAAQAJAAAHAHQAKALAEAaQABALgBAKQgEAbgKAMQgIAHgIAAQgHAAgHgHgAgGgvQgGAHgBAoQABApAGAHQADADADAAQADAAAEgDQAGgHAAgpQAAgogGgHQgEgDgDAAQgDAAgDADg");
	this.shape_4.setTransform(-5.9,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgOAwQgJgIgEgSQgGgjAPgYQAKgSAQAAQAJAAAGAGQAFAFAAAHQAAAFgDAEQgDACgDAAQgHAAgBgHQgCgJAIgEQgFgFgGABQgGACgEAHQgEAHgCAQIgBARQAGgKAIAAQAJAAAIAIQAKAJAAAQQAAARgKAJQgHAIgLAAQgJAAgHgIgAgIABQgCAEgBAHIABASQAAANAEAFQADADAEAAQAEAAADgDQAEgFAAgUIgBgSQgCgJgIAAQgFAAgEAFg");
	this.shape_5.setTransform(-13.6,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgVAxQgFgFgCgIQgCgKAEgEQADgDADAAQAEAAACADQADADAAAEQAAAFgDADQgDADgEAAQADAGAFADQAHACAGgCQAFgCADgGQAEgHAAgJQAAgMgFgHQgFgJgIADIgBABQgFABgBgDQAAgFAGABQAGACACgBQAJgEAAgXQgBgKgFgFQgEgFgIACQgIACgCAIQAHAAACAFQADAHgFAFQgDAEgGgCQgGgDAAgIQAAgNAMgHQAHgFAKABQANABAGAKQAFAIgBANQgCAJgEAEQgGAGgIACQAIABAHAFQAIAIAAANQAAAUgSAIQgHADgGAAQgKAAgJgHg");
	this.shape_6.setTransform(-21.5,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.5,-9.5,55,19);


(lib.vjv23t240000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(23.6,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(14.9,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(6.2,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAFgUIgIAAIAAgTIATAAIAAASIgIAVg");
	this.shape_3.setTransform(-0.1,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-6,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAFBAIAAggIgmAAIAAgOIAjhRIAUAAIAABQIAMAAIAAAPIgMAAIAAAggAgRARIAWAAIAAgzg");
	this.shape_5.setTransform(-14.7,-0.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AggBAIAAgNQAKgYAUgUQATgTAAgRQAAgLgFgFQgEgDgHAAQgQAAAAAeIgQAAQAAgYANgNQAIgJALABQANAAAJAIQALAKgBAPQABAZgXAWQgPAQgJARIAtAAIAAAOg");
	this.shape_6.setTransform(-23.4,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.9,-10,59.9,20);


(lib.vjv23t192000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQAMALADAaQABALgBAKQgDAbgMAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHABAoQgBApAIAHQADADACAAQADAAADgDQAIgHAAgpQAAgogIgHQgDgDgDAAQgCAAgDADg");
	this.shape.setTransform(21.5,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQALALAEAaQABALgBAKQgEAbgLAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHAAAoQAAApAIAHQACADADAAQADAAADgDQAIgHgBgpQABgogIgHQgDgDgDAAQgDAAgCADg");
	this.shape_1.setTransform(13.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAGgHAIAAQAJAAAHAHQALALADAaQABALgBAKQgDAbgLAMQgIAHgIAAQgHAAgHgHgAgGgvQgGAHAAAoQAAApAGAHQAEADACAAQAEAAADgDQAGgHABgpQgBgogGgHQgDgDgEAAQgCAAgEADg");
	this.shape_2.setTransform(5.9,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgJAUQAMgJADgLQgGAFgIgEQgHgDAAgIQABgKAKgDQAEgBAFABQAGADADAFQAFAOgLANQgFAHgIAFg");
	this.shape_3.setTransform(0,4.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdA3IAAgFIAHgLIAVgbQAGgHADgJQAEgKABgLQgBgNgFgFQgEgFgFABQgIgBgGAGQgEAEgCAGQAGgBADADQACADABAEQgBAGgCADQgCADgEAAQgEAAgCgDQgDgDAAgIQAAgLAKgKQAIgJALABQANgBAIAJQAJAIAAAOQAAAPgMAKIgMALQgMANgKAMIAfAAQAFAAADgGIADgLIAEAAIgDAjg");
	this.shape_4.setTransform(-5.7,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgVAyQgGgFABgHQAAgHAEgDQAGgCAEAEQADADAAAEQAAAIgHACQAAABABAAQAAABAAAAQABAAAAABQABAAAAAAQAGACAHgEQAIgFACgRQACgMgBgLQgFAHgFABQgIACgIgEQgNgGAAgVQAAgRALgMQAIgHAJAAQAKAAAHAHQAMAMAAAZQAAAXgEANQgFAMgHAIQgKAJgJAAQgKABgFgGgAgCgyQgHACgCAMQgCAJABAKQABANADAEQAFAJAIgGQAGgDAAgMIAAgLQAAgNgEgJQgDgFgEAAIgCAAg");
	this.shape_5.setTransform(-13.6,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgWA3IAAgEIACAAQAGAAAEgEQADgDAAgIIAAhAQAAgGgDgDQgDgDgJgBIAAgEQAGAAAIgCQAIgCAFgFIAEAAIAABaQAAAJACACQADAEAFAAIAEAAIAAAEg");
	this.shape_6.setTransform(-21.2,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.5,-9.5,55,19);


(lib.vjv23t130000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(23.6,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(14.9,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(6.2,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAFgUIgIAAIAAgTIATAAIAAASIgIAVg");
	this.shape_3.setTransform(-0.1,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-6,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgWA4QgKgKgCgZIARAAQAAARAHAIQAFAEAFAAQAIAAAFgFQAGgGAAgKQAAgLgHgGQgHgHgMABIAAgSQAWADAAgXQAAgJgFgFQgDgDgHAAQgFAAgEADQgGAIAAANIgQAAQABgUAKgLQAJgIALAAQAOAAAJAIQAJAKAAAOQAAASgNALQAQANAAATQAAAQgLALQgJAJgPAAQgNAAgJgJg");
	this.shape_5.setTransform(-14.7,-0.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AACBAIAAhhIgTAAIAAgNQAVgCACgPIANAAIAAB/g");
	this.shape_6.setTransform(-24.1,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.9,-10,59.9,20);


(lib.vjv23t110500 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQAMALADAaQABALgBAKQgDAbgMAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHABAoQgBApAIAHQADADACAAQADAAADgDQAIgHAAgpQAAgogIgHQgDgDgDAAQgCAAgDADg");
	this.shape.setTransform(21.5,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAHgHAHAAQAJAAAGAHQALALAEAaQABALgBAKQgEAbgLAMQgGAHgJAAQgHAAgHgHgAgFgvQgIAHAAAoQAAApAIAHQACADADAAQADAAADgDQAIgHgBgpQABgogIgHQgDgDgDAAQgDAAgCADg");
	this.shape_1.setTransform(13.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWAwQgGgHAAgJQAAgGADgEQACgCAEAAQAEAAACACQADADAAAFQAAAEgDADQgEAEgEgBQAEAKALAAQALAAAFgQQAFgSgFgNQgFgMgJAAQgJAAgHALIgEAAIADg4IAwAAIgCANQgBAFgFAAIgkAAIgDAfQAJgMALAAQALAAAJAJQAJAIAAASQAAASgKAKQgJAJgNAAQgMAAgHgHg");
	this.shape_2.setTransform(6,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgJAUQAMgJADgLQgGAFgIgEQgHgDAAgIQABgKAKgDQAEgBAFABQAGADADAFQAFAOgLANQgFAHgIAFg");
	this.shape_3.setTransform(0,4.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgOAxQgMgMgDgbQgBgKABgLQADgaAMgLQAGgHAIAAQAJAAAHAHQAKALAEAaQABALgBAKQgEAbgKAMQgIAHgIAAQgHAAgHgHgAgGgvQgGAHgBAoQABApAGAHQADADADAAQADAAAEgDQAGgHAAgpQAAgogGgHQgEgDgDAAQgDAAgDADg");
	this.shape_4.setTransform(-5.9,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgWA3IAAgEIACAAQAGAAAEgEQADgDAAgIIAAhAQAAgGgDgDQgDgDgJgBIAAgEQAGAAAIgCQAIgCAFgFIAEAAIAABaQAAAJACACQADAEAFAAIAEAAIAAAEg");
	this.shape_5.setTransform(-13.4,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgWA3IAAgEIACAAQAGAAAEgEQADgDAAgIIAAhAQAAgGgDgDQgDgDgJgBIAAgEQAGAAAIgCQAIgCAFgFIAEAAIAABaQAAAJACACQADAEAFAAIAEAAIAAAEg");
	this.shape_6.setTransform(-21.2,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.5,-9.5,55,19);


(lib.vjv23t48000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgXA3QgKgKAAgSQAAgRAPgNQgNgLAAgRQAAgQAJgJQAJgIANAAQAOAAAIAIQAKAJAAAQQAAARgOALQAQALAAATQAAASgKAKQgKAKgOAAQgNAAgKgKgAgLAKQgGAGAAALQAAAKAGAGQAFAGAGAAQAHAAAFgGQAGgGAAgKQAAgLgGgGQgFgFgHAAQgGAAgFAFgAgKgrQgFAFAAAHQAAAIAFAGQAFAEAFAAQAGAAAFgEQAFgGAAgIQAAgHgFgFQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-10.3,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAFBAIAAggIgmAAIAAgOIAjhRIATAAIAABQIANAAIAAAPIgNAAIAAAggAgRARIAWAAIAAgzg");
	this.shape_5.setTransform(-19,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,-10,51.2,20);


(lib.vjv23t40000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-10.3,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAFBAIAAggIgmAAIAAgOIAjhRIATAAIAABQIANAAIAAAPIgNAAIAAAggAgRARIAWAAIAAgzg");
	this.shape_5.setTransform(-19,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,-10,51.2,20);


(lib.vjv23t30000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-10.3,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgWA4QgKgKgCgZIARAAQAAARAHAIQAFAEAFAAQAIAAAFgFQAGgGAAgKQAAgLgHgGQgHgHgMABIAAgSQAWADAAgXQAAgJgFgFQgDgDgHAAQgFAAgEADQgGAIAAANIgQAAQABgUAKgLQAJgIALAAQAOAAAJAIQAJAKAAAOQAAASgNALQAQANAAATQAAAQgLALQgJAJgPAAQgNAAgJgJg");
	this.shape_5.setTransform(-19.1,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,-10,51.2,20);


(lib.vjv23t19500 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVA4QgKgKgCgUIAQAAQACAOAFAFQAFAFAFAAQAGgBAGgFQAFgGAAgRQAAgPgFgGQgGgEgGAAQgMAAgEAKIgQAAIAEhGIA4AAIAAAQIgoAAIgCAjQAHgGALAAQAKAAAJAJQALAKAAAVQAAAYgLAKQgJAJgOAAQgMABgJgJg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUA5QgIgJgDgPIAQAAQAFAPAIABQAHgBADgDQAIgHAEgbQgJAKgMAAQgMAAgJgJQgMgMAAgVQAAgWAMgNQAKgIAMAAQAMAAAIAIQAPAPAAAqQAAAogPAPQgIAJgMAAQgMAAgIgIgAgLgrQgGAHgBAPQABAPAGAHQAFAEAGAAQAFAAAFgEQAGgHAAgPQAAgPgGgHQgFgFgFAAQgGAAgFAFg");
	this.shape_4.setTransform(-10.3,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AACBAIAAhhIgUAAIAAgNQAWgCADgPIALAAIAAB/g");
	this.shape_5.setTransform(-19.7,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,-10,51.2,20);


(lib.vjv23t18000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgXA3QgKgKAAgSQAAgRAPgNQgNgLAAgRQAAgQAJgJQAJgIANAAQAOAAAIAIQAKAJAAAQQAAARgOALQAQALAAATQAAASgKAKQgKAKgOAAQgNAAgKgKgAgLAKQgGAGAAALQAAAKAGAGQAFAGAGAAQAHAAAFgGQAGgGAAgKQAAgLgGgGQgFgFgHAAQgGAAgFAFgAgKgrQgFAFAAAHQAAAIAFAGQAFAEAFAAQAGAAAFgEQAFgGAAgIQAAgHgFgFQgFgFgGAAQgFAAgFAFg");
	this.shape_4.setTransform(-10.3,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AACBAIAAhhIgUAAIAAgNQAWgCADgPIALAAIAAB/g");
	this.shape_5.setTransform(-19.7,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,-10,51.2,20);


(lib.vjv23t17000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgRBAIAghwIguAAIAAgPIA/AAIAAAPIggBwg");
	this.shape_4.setTransform(-10.3,-0.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AACBAIAAhhIgUAAIAAgNQAWgCADgPIALAAIAAB/g");
	this.shape_5.setTransform(-19.7,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,-10,51.2,20);


(lib.vjv23t16000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgVA4QgNgOAAgnQAAgrAOgOQAKgKAMAAQAMAAAIAHQAIAJACAPIgQAAQgCgIgDgDQgEgEgFAAQgFAAgEAFQgJAIgCAaQAJgMALAAQAMAAAJAKQAMALAAAVQAAAXgMAMQgJAJgNAAQgMAAgKgJgAgJAAQgGAGAAAPQAAAQAGAGQAFAGAFAAQAGAAAFgGQAHgHAAgPQAAgNgHgIQgFgEgGAAQgFAAgFAEg");
	this.shape_4.setTransform(-10.3,-0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AACBAIAAhhIgUAAIAAgNQAWgCADgPIALAAIAAB/g");
	this.shape_5.setTransform(-19.7,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.5,-10,51.2,20);


(lib.vjv23t6500 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape.setTransform(19.2,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgUA5QgQgQAAgpQAAgpAQgPQAIgIAMAAQANAAAIAIQAQAPAAApQAAApgQAQQgIAIgNAAQgMAAgIgIgAgKgsQgKAKAAAiQAAAjAKAKQAFAFAFAAQAGAAAFgFQAKgKAAgjQAAgigKgKQgFgFgGAAQgFAAgFAFg");
	this.shape_1.setTransform(10.5,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgVA4QgKgKgCgUIAQAAQACAOAFAFQAFAFAFAAQAGgBAGgFQAFgGAAgRQAAgPgFgGQgGgEgGAAQgMAAgEAKIgQAAIAEhGIA4AAIAAAQIgoAAIgCAjQAHgGALAAQAKAAAJAJQALAKAAAVQAAAYgLAKQgJAJgOAAQgMABgJgJg");
	this.shape_2.setTransform(1.8,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgGAUIAEgUIgHAAIAAgTIATAAIAAASIgHAVg");
	this.shape_3.setTransform(-4.5,5.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgVA4QgNgOAAgnQAAgrAOgOQAKgKAMAAQAMAAAIAHQAIAJACAPIgQAAQgCgIgDgDQgEgEgFAAQgFAAgEAFQgJAIgCAaQAJgMALAAQAMAAAJAKQAMALAAAVQAAAXgMAMQgJAJgNAAQgMAAgKgJgAgJAAQgGAGAAAPQAAAQAGAGQAFAGAFAAQAGAAAFgGQAHgHAAgPQAAgNgHgIQgFgEgGAAQgFAAgFAEg");
	this.shape_4.setTransform(-10.3,-0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.8,-10,42.5,20);


(lib.vjv23t税引前当期純利益 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhDBIIAAgQIAVAAIAAgmQgIAHgLAFIgJgQQAOgGAKgIQAOgLAEgPIgiAAIAAgQIAlAAQgDgIgHgJIAPgJQAMANADANIAQAAQAHgMAGgRIAOAFQABABAAAAQABAAAAABQABAAAAABQAAAAABABIAAABIgEACIgJARIAoAAIAAAQIgiAAQAOAaAeAMIgLAQQgJgEgJgIIAAAoIAVAAIAAAQgAAUA4IAKAAIAAgjIgKAAgAgFA4IAJAAIAAgjIgJAAgAgeA4IAJAAIAAgjIgJAAgAggAFIBBAAIgGgIQgIgJgGgOIgaAAQgJAWgKAJg");
	this.shape.setTransform(55.9,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AghBHIAAg2QgMARgOAKIgKgQQAJgFAGgJQANgNAHgQIghAAIAAgQIAiAAIAAgPIgbABIgEgQQAkgBAcgIIAKAOQADADgCACIgFAAIgVACIAAASIAeAAIAAAQIgeAAIAAAKIAGAEQALAFANANIgMAOQgJgKgJgHIAAA5gAAlBGIgCgRIAMAAQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIAAgDIAAhzIAPAAQAIABgFAEIAAB3IgBAFQgCAIgKAAgAATAoIAAhbIAPAAQAHAAgFAFIAABWg");
	this.shape_1.setTransform(39.7,0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgtBKIAAhAIgSACQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgCAAgCgFIgDgMIAOAAIAJgMQgJgLgMgJIAJgMIAFAFIAUggIANAIIACACIgBACIgDABIgUAcIAGAFIASgZIAMAIQAQAAAQgDIAAgZIAOAAQAHABgFAFIAAARQAPgCANgFIAIANQADAFgDABQgCABgDgCIgfAFIAAAxIALAAIAAguIANAAQAIABgFAEIAAA5IgbAAIAAATIABADQAAAAAAAAQAAABABAAQAAAAABAAQAAAAABAAIAKAAIACgBIACgCIACgLIAQAHIgDAMIgCACQgCAFgDACQgDABgEAAIgXAAQgMAAAAgNIAAgZIgJAAIAAAKIgPAAIAAhDIANAAQAHABgFAEIAAAkIAJAAIAAguIgeADIgCgNQgRASgOATIAQgBIgFgLIAMgFQALAPAEAMIgOAHIgCgHIgKACIAABBgAhKA5IAFgNQAEgPAAgMIAOACIADACIABADIgCACIgCAOQgDAQgGALgAgYAVIAPgCQAFANAAAVIgQADQABgSgFgRg");
	this.shape_2.setTransform(24,-0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgHA9QAJgIAGgIQALgNAAgNIAAhWIA0AAIAAB+IgBAFQgCAIgKAAIgQAAIgCgSIAKAAQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAgBIAAgDIAAgdIgQAAIAAACQAAAHgDAIQgFASgaAUgAAlAEIAQAAIAAgTIgQAAgAAlgfIAQAAIAAgTIgQAAgAhEA7QAHgFAJgMQAGgIACgFIgaAAIAAgPIATAAIAAgzIgPAAIAAgPIAPAAIAAgVIAOAAQAHABgFAEIAAAQIATAAIAAgWIAOAAQAHABgFAEIAAARIANAAIAAAPIgNAAIAAAzIAPAAIAAAPIgYAAQAJAIAGAHIgMAMIgRgSIAMgJIgcAAIAMAGIgHAOQgKAOgLAJgAgjAOIATAAIAAgJIgTAAgAgjgJIATAAIAAgGIgTAAgAgjgeIATAAIAAgHIgTAAg");
	this.shape_3.setTransform(7.6,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAsBFIAAgHIhoAAIAAgRIBoAAIAAgPIhgAAIAAgRIBgAAIAAgNIhoAAIAAgSIAzAAIAAgyIAQAAQAGgBgBAEIgDACIAAAtIAZAAIgPgIQALgSAHgTIAOAHIACABQAEADgBACQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAgBAAQgFANgMASIAaAAIAABXgAg2gxIAPgKQAKAMAKARIgPALQgKgSgKgMg");
	this.shape_4.setTransform(-8.1,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("Ag8BLIAAhnIA5AAIAABYIgBAGQgCAHgJABIgRAAIgBgSIAJAAQABAAAAAAQABAAAAAAQAAAAABgBQAAAAAAAAIABgEIAAgNIgWAAIAAAlgAgqAVIAWAAIAAgIIgWAAgAgqgDIAWAAIAAgJIgWAAgAAeBKIgBgTIAKAAQABAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBIAAgDIAAhPIARAAQAGAAgBADIgCADIAABTIgCAGQgCAHgJABgAAKAzIAAhMIAPAAQAIABgFAEIAABHgAhKggIAAgSIApAAIgIgNIAPgJQAHAJAHANIAVAAQAGgJAFgPIAPAFQAFABgBACQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAgBAAIgIAOIAtAAIAAASg");
	this.shape_5.setTransform(-24.1,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AArBFIAAiIIAPAAQAIABgFADIAACEgAgrBFIgBgQIAbAAIAEgBIADgDIABgGQAEgNACgOIgnAAIgBAHIgRgCQAHggACgWIAuAAIAAgQIg5AAIAAgQIBJAAIAAA0IgQAAIAAgEIgfAAIgCARIAzAAQgFAngFAUQgCAJgLABg");
	this.shape_6.setTransform(-40.4,0.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgZA6QANgFAHgFQAGgGACgFQADgFAAgGIAAgLIgNAAIAAg1IAQAAQgFgLgKgNIAOgKQAKAMAIAOIgOAIIAdAAIgMgGQAHgNAFgRIAOAGQABAAABABQAAAAABAAQAAABABAAQAAABAAAAIAAACIgEABQgEAOgGAKIAXAAIAAA1IgUAAIAAAiIAAADQABABAAAAQAAAAAAAAQABAAAAAAQABAAABAAIABAAIACAAIABgCIABgDIACgLIARAFIgDAPQAAANgMAAIgSAAQgNgBAAgMIAAgqIgHAAIAAAOQAAAKgFAIQgKARgWALgAAKAAIAoAAIAAgXIgoAAgAguBJIAAg0IgRAXIgMgOQAWgVAFgaIgXAAIAAgRIAZAAIAAgNIgTACIgFgQQAigDASgIIAIANQADAHgIgCIgOADIAAARIATAAIAAARIgTAAIAAAJQAPAIAGAHIgIAQIgNgMIAAA+g");
	this.shape_7.setTransform(-56.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66.1,-10,132.2,20);


(lib.vjv23t単位千円 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgQAyQAHgFAFgHQAJgNACgRQABgRgEgMQgFgRgPgMIACgDQAOAKAEAGQALANACAQQACAPgFAMQgGASgWARg");
	this.shape.setTransform(29,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAZAzIAAgEIgCgBIgPgGQgFgBALAAIANAAQAEgBAAgDIAAggIhCAAIAAAuQAAAEgHABQgGAAAAgCIAAhnIAQAHIA9AAIAFgJIANAMQAEADgEADIgDAAIAABOQAAAGgKAEIgFABQgDAAgBgDgAAEAAIAbAAIAAgpIgbAAgAgjAAIAbAAIAAgpIgbAAg");
	this.shape_1.setTransform(21.2,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgFA2QgBAAAAAAQAAAAAAgBQgBAAAAgBQAAgBAAgBIAAgzIgtAAIgCgDIAvAAIAAgbIgcADIgMABQgHgBAIgDQAZgEATgHQANgEAQgIIAMALQAEAFgGAAIgEAAIgbAFIAAAdIAaAAIAJgNIANALQADADgEACIgvAAIAAAyIgBADQgFADgEAAIgBgBg");
	this.shape_2.setTransform(9.1,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgIAnQgDgDAAgGQAAgGADgDQAEgDAEAAQAFAAAEADQADADAAAGQAAAGgDADQgEADgFAAQgEAAgEgDgAgIgTQgDgEAAgFQAAgGADgDQAEgEAEAAQAFAAAEAEQADADAAAGQAAAFgDAEQgEACgFAAQgEAAgEgCg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgoA0IAAg1IgHAHQgGAHgCACQgDAAAEgHQAJgOAFgUQAGgRACgKIAOAFQADACgDADIgEACIgHASIAEADQAAAAAAAAQAAABAAAAQAAABAAAAQAAAAgBABIgCABIAABBQAAAGgKAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAgAgXAwIgCgDIAmAAQAHgaADgOIADgaIAPAGQAGAEgFACIgCABQgEAOgFAMIgMAbIAQAAIAJgLIAMAKQADAEgEAAgAgGAiQgBgCAAgFIAAgIQgBgOgCgJIgFgNQgCgEAHAGQAQATAAAVQAAAIgEADQgBAAAAAAQgBABAAAAQAAAAAAAAQgBAAAAAAQgDAAgCgDgAgXgYIgBgCIAeAAIAAgbIAQABQAEACgEAEIgDACIAAASIAPAAIAIgLIALAKQADACgEABg");
	this.shape_4.setTransform(-9,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgFA3QgBgBAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBIAAgWIguAAIgBgDIAvAAIAAgOIgVAAIAAADIgBADQgHACgBgBQgBAAgBAAQgBAAAAAAQgBgBAAAAQAAAAAAgBIAAgxIAOAGIArAAIAAgCQAEgKAFgRIANAGQADAEgDACIgBAAIgTAQIgBABIgBAAIABAAIAJAAIAFgHIAMALQAAAAAAABQABAAAAABQgBAAAAABQgBAAAAAAIgCABIAAAfQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBABIgIABQgBAAgBAAQAAAAAAgBQgBAAAAAAQAAAAAAgBIAAgEIgVAAIAAAOIAdAAIAKgMIAKALQABAAAAABQAAABAAAAQAAABAAAAQgBABAAAAIgxAAIAAAUQAAAAgBABQAAAAAAABQAAAAAAABQgBAAAAAAQgDACgCAAIgDAAgAAFAKIAVAAIAAgOIgVAAgAgcAKIAVAAIAAgOIgVAAgAAFgHIAVAAIAAgPIgVAAgAgcgHIAVAAIAAgPIgVAAgAgdgcQgCgBgCgGQgDgKgFgDQgDgEAHACQAKACADAEQACACACAEQACAHgGADIgDAAIgCAAgAgFghIgDgKQgBgEgDgCQgFgEAFAAQANADAEAIQACAEgBAEQgCAFgEAAQgEAAgBgEg");
	this.shape_5.setTransform(-20.9,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgBAoQgNgOgCgRQgCgPAFgNQAGgRAWgRIACADIgMAMQgJANgBAQQgCARAEAOQAFAQAPAMIgCAEQgLgIgFgGg");
	this.shape_6.setTransform(-29.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35.1,-8,70.2,16);


(lib.vjv_ボタンbasegr前 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// base
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(1.5,1,1).p("Ak+CqIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkIAACLQAABkBkAAg");
	this.shape.setTransform(-59.6,-18);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EFEFEF").s().p("Ak+CqQhkAAAAhkIAAiLQAAhkBkAAIJ9AAQBkAAAABkIAACLQAABkhkAAg");
	this.shape_1.setTransform(-59.6,-18);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#666666").ss(1.5,1,1).p("AmiBGQAABkBkAAIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkg");
	this.shape_2.setTransform(-59.6,-18);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#CC5555","#EBBEBE","#FAF1E7"],[0.008,0.729,1],65.3,16,65.3,-15).s().p("Ak+CqQhkAAAAhkIAAiLQAAhkBkAAIJ9AAQBkAAAABkIAACLQAABkhkAAg");
	this.shape_3.setTransform(-59.6,-18);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#333333").ss(1.5,1,1).p("Ak+CqIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkIAACLQAABkBkAAg");
	this.shape_4.setTransform(-59.6,-18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_3},{t:this.shape_4}]},1).wait(1));

	// line
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BCBCBC").ss(5,1,1).p("AmiBGQAABkBkAAIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkg");
	this.shape_5.setTransform(-59.6,-18);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-104,-37.5,88.8,39);


(lib.vjv_ボタンbasegr = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// base
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#666666").ss(1.5,1,1).p("Ak+CqIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkIAACLQAABkBkAAg");
	this.shape.setTransform(-59.6,-18);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#B8B8B8","#D5D5D5","#F2F2F2"],[0.008,0.31,0.698],69.9,16,69.9,-6).s().p("Ak+CqQhkAAAAhkIAAiLQAAhkBkAAIJ9AAQBkAAAABkIAACLQAABkhkAAg");
	this.shape_1.setTransform(-59.6,-18);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#666666").ss(1.5,1,1).p("AmiBGQAABkBkAAIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkg");
	this.shape_2.setTransform(-59.6,-18);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#CC5555","#EBBEBE","#FAF1E7"],[0.008,0.729,1],65.3,16,65.3,-15).s().p("Ak+CqQhkAAAAhkIAAiLQAAhkBkAAIJ9AAQBkAAAABkIAACLQAABkhkAAg");
	this.shape_3.setTransform(-59.6,-18);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#333333").ss(1.5,1,1).p("Ak+CqIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkIAACLQAABkBkAAg");
	this.shape_4.setTransform(-59.6,-18);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[{t:this.shape_3},{t:this.shape_4}]},1).wait(1));

	// line
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#BCBCBC").ss(5,1,1).p("AmiBGQAABkBkAAIJ9AAQBkAAAAhkIAAiLQAAhkhkAAIp9AAQhkAAAABkg");
	this.shape_5.setTransform(-59.6,-18);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-104,-37.5,88.8,39);


(lib.vis202解答欄 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(2,1,1).p("AHMh3IuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8IAAh3QAAg8g8AAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AnLB4Qg8AAAAg8IAAh3QAAg8A8AAIOXAAQA8AAAAA8IAAB3QAAA8g8AAg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(2,1,1).p("AHMh3IuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8IAAh3QAAg8g8AAg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEFEFE").s().p("AnLB4Qg8AAAAg8IAAh3QAAg8A8AAIOXAAQA8AAAAA8IAAB3QAAA8g8AAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-13,106,26);


(lib.val = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.visible = false;
	}
	this.frame_1 = function() {
		//クイズの情報
		exportRoot.fncValMC();
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AgxAyIAAhjIBjAAIAABjg");
	this.shape.setTransform(5,5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,10,10);


(lib.UI閉じるボタンMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 一時停止
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#515860").s().p("AAAATIguAwIgUgUIAvgvIgvguIAUgUIAuAvIAvgvIAUAUIgvAuIAvAvIgUAUg");
	this.shape.setTransform(0,0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#567089").s().p("AAAATIguAwIgUgUIAvgvIgvguIAUgUIAuAvIAvgvIAUAUIgvAuIAvAvIgUAUg");
	this.shape_1.setTransform(0,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// 前へ次へ
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABahZQglglg1AAQg0AAgmAlQglAlAAA0QAAA1AlAlQAmAlA0AAQA1AAAlglQAmglAAg1QAAg0gmglg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#EAF4FE","#99A3AD"],[0,1],-40.5,-12.2,-40.5,13.5).s().p("AhaBaQgkglgBg1QABg0AkglQAmglA0AAQA1AAAlAlQAmAlAAA0QAAA1gmAlQglAlg1AAQg0AAgmglg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#EAFFFF","#99B7D5"],[0,1],-40.5,-12.2,-40.5,13.5).s().p("AhaBaQgkglgBg1QABg0AkglQAmglA0AAQA1AAAlAlQAmAlAAA0QAAA1gmAlQglAlg1AAQg0AAgmglg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).to({state:[{t:this.shape_4},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.7,-13.7,27.5,27.5);


(lib.UIボタン明示 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("AkXDmIAAnLIIvAAIAAHLg");
	this.shape.setTransform(23.5,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AEYEEIovAAQgMAAgJgJQgJgJAAgMIAAnLQAAgMAJgJQAJgJAMAAIIvAAQAMAAAJAJQAJAJAAAMIAAHLQAAAMgJAJQgJAJgMAAIAAAAgAkXDmIIvAAIAAnLIovAAg");
	this.shape_1.setTransform(23.5,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.5,-3.5,62,52);


(lib.UI_節終了画面_文字 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 」をタップしてください。
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A7rDOIAAgiIBhAAIAAkYIAjAAIAAE6gAaCC4QgRgRAAgbQAAgaARgRQASgSAbAAQAaAAARASQASARAAAaQAAAbgSARQgRASgaAAQgbAAgSgSgAaTBwQgNANAAAPQAAARANAMQALAMARAAQAPAAANgMQAMgMAAgRQAAgPgMgNQgNgMgPAAQgRAAgLAMgAprCiQBbgeAyhCQA0hDAAhfIjcAAIAAgmIDTAAQgDgHAAgMQAAgUAOgPQASgPATgCQAVAAAQASQAKAMACAQQACAYgQARQgOAOgTgBIAAAJQAABkg4BNQg3BOhhAmgAmVitQgIAJABAMQACALAFAFQAHAHALgBQALABAGgHQAHgHAAgKQAAgLgHgHQgGgHgLgCQgLAAgHAHgAGRA4QggggAAgWQAAgPAbgcQBEhFAvhQIAgAZQhIBkgxAtQgQAQAAAHQAAAIALAIQAdAcArAtQAoArAVAcIghAhQguhDhGhJgAydClQBXgiAshIQg3gvgdgRIASgcQAjAWAzAkQAUgxAAg9IAAgMIhyAAQgTBWg1AwIgcgbQBIhBgBiBIAoAAQAAAcgDAZICOAAIAAAuQAABKgcA6QAVARAOANIgaAjQgIgJgTgRQgxBNhWAhgA2CDEQgugBgZgQQgYgPAAgiQAAgqAVgYQAYgeBDgdQgDghgZgFQghgEgZAWQgHAHgcAsIgigaQApgxAXg+IhFAAIAAgnIBRAAQALgeADgbIAlAKQgEAXgIAYICHAAIAAAnIiTAAQgPAlgRATQAcgWAnABQAoAEAKA2IBaggIANAoQg6AQgpANIAABVIgjAAIAAhGQgqAUgQANQgTASAAATQAAAeAOAHQAKAGAigBIBwAAIAAAogAtdCiQBWgeAfg8QAgg1gChlIAhAEQgBBqgkA+QgjA/hWAmgAPmCbQgdgWgCgrQgCgpAggcQAcgbAmAAQAyACAcAJQgZgjgag0QhNAMg0ACIgDglQAxgDBFgJIgZhHIAjgLQANArAMAiQA8gGAmgGIAFAhQgeAIg5AGQAhBFAzAvIgbAjQgogjhCgCQgpAAgSATQgPAQAAAVQAAAhAaAOQAlAVBkAAIgHAnQh0AAgugjgAMVC4QgkAAgYgRQgagVAEgiQADgcAVgcIAbATQgSAaACAUQAEAZAvAAIBvAAIAAAmgAU7C1Qg6gHgBiZQAAhWAJhXIAoAFQgMBSAABYQABBsAZAFQAZAFAVhLIAgAaQgPAxgXAWQgPASgVAAIgIAAgACQCJQgogngChDQAAglAXgqQAagwAugaIi4AAIAAgiIEzAAIAAAjQhSACg0AsQgvArAAA7QAAA5AlAeQAjAcBIAAIgKAnQhTAAgugsgAjzCZQgVgagCg/IAAjyIAjAAIAADyQAAArAQASQAQAQAxgCQAngCAVgiQATgbAIg6IAmASQgXCPh0AAIgHAAQgzAAgVgagAJPB7QAzhfAWh6IhGAAIAAghIBMAAQAHglACglIAnAGIgJBEIBtAAIAAAhIh1AAQgaCGg0BqgAX2gLQgVg+gbgjIAigWQAfArAVA7QAWA2AFA8IgoANQgGg1gTg5gAuRgwIAggOQAQAWAaBBIghAPQgVg1gUgjgAtBhVIAegOQAYAmATAwIghAPQgVg2gTghgALkgIIAAghICZAAIAAAhgANziFIAAhEIAeAAIAABEgANDiFIAAhEIAeAAIAABEg");
	this.shape.setTransform(78.6,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// マーク
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFFF").s().p("ACJDgIAAjPIldDPIAAm/IFdDNIAAjNIBMAAIAAG/g");
	this.shape_1.setTransform(-129.5,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// 「進む
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AkpChQAqgPAcgYIAAhrIg/AAIAAghIBjAAIAACQQAfAjA6AAIDWAAIgJAhIjNAAQhLAAgmgxQgVAfgqAYgAExDAQgsgDgUgJQgagMAAgcIAEgdIgJAAQgVgBgOgWQgSgaACgnQACgbARgUQASgWAZAAQAHAAAGACIAAgtIhLAAIAAgiIBLAAIAAhDIAjAAIAABDIBSAAIAAAiIhSAAIAABCQAPATAAAYQAAAygaAYQgJAYABALQACAOAKAFQAJAGAZAAIBKAAQAsAAAAgxQAAgjgbgkIAfgTQAiAmABA1QAAAqgWAUQgVAVgoADgADBAZQgCAVAGAOQAIAPAKAAQARABAIgRQAFgLACgQQACgTgIgMQgGgOgOAAQgZAAgDAmgAiLCMIAAi9QgVAcgOAIIgRgmQBDg8AUhYIAnALQAPAFgSAFQgJAbgQAcIA2AAQAZglALgjIAlAOQAMAIgRACQgMAWgUAaIBcAAIAAAcIhcAAIAAAsIBOAAIAAAcIhOAAIAAAnIBLAAIAAAdIhLAAIAAAvIBoAAIAAAcIjNAAIAAAUgAhoBcIBBAAIAAgvIhBAAgAhoAQIBBAAIAAgnIhBAAgAhogzIBBAAIAAgsIhBAAgAnlBzIAAk6ICEAAIAAAiIhhAAIAAEYgAGAhZIATgeQAxAhAiAvIgYAiQgrg+gjgWgAkJiXIAYgcQAsAZAWAYIgdAeQgXgagmgZg");
	this.shape_2.setTransform(-207.2,-0.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// 黒
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(4,1,1).p("AAqBGQAfg1gBhlIAhAEQgCBqgjA+QgjA/hWAnIgWgeQBVgeAgg8gAGOjPQAWAAAPASQALAMACAQQABAZgQAQQgNAOgUAAIAAAIQAABkg4BNQg3BOhgAmIgagjQBbgeAxhBQA1hDAAhgIjcAAIAAgmIDTAAQgEgHAAgNQAAgTAPgQQARgOATgCgAGOiDQALAAAHgHQAHgHAAgLQAAgLgHgGQgHgHgLgCQgKAAgHAHQgJAIABANQACALAGAFQAHAHAKAAgARTieIAAAjQhTADgzAsQgwAqAAA7QAAA5AmAeQAjAcBIAAIgLAnQhSAAgugsQgpgmgChDQAAgmAYgqQAagwAtgaIi4AAIAAgigAK3BmQAUgcAHg6IAmASQgWCPh0AAQg5ACgWgcQgVgagCg/IAAjyIAjAAIAADyQAAArAQASQAQAQAxgCQAngCAUghgAZEiCIAAAjIh0AAQgaCGg1BpIgggXQAzhfAXh5IhGAAIAAgjIBMAAQAGglACgkIAnAGQgEAigFAhgASzARQAeAcAqAtQApAsAVAcIgiAgQgthDhHhJQgfgfAAgXQAAgPAagcQBEhFAwhRIAgAaQhIBkgyAtQgPAQAAAIQAAAHAKAIgAaQgrIAAAhIiZAAIAAghgAajjLIAABEIgeAAIAAhEgAZ0jLIAABEIgeAAIAAhEgAdph8QA8gGAngGIAFAhQgeAIg6AGQAiBFAzAwIgbAiQgogihDgDQgpAAgRATQgQAQAAAVQAAAhAbAPQAkAUBkAAIgGAnQh1AAgtgjQgegVgCgsQgBgpAfgcQAdgbAmAAQAxACAcAKQgYgkgag0QhOANgzACIgDglQAwgEBFgJQgMgjgMglIAjgLQAMAsAMAigEAhSACGQAYAFAVhKIAgAZQgOAxgXAXQgSAVgagEQg6gHgBiZQAAhVAIhYIAoAFQgMBTAABXQACBsAZAFgEAj6gCDQAgAqAVA7QAVA3AFA7IgoANQgFg1gUg5QgUg+gbgjgEAntABfQARARAAAbQAAAagRASQgSARgaAAQgaAAgSgRQgSgSAAgaQAAgbASgRQASgSAaAAQAaAAASASgEAndACnQAMgMAAgQQAAgQgMgNQgMgLgQAAQgQAAgMALQgMANAAAQQAAAQAMAMQAMAMAQAAQAQAAAMgMgAaaCQIAAAnIhyAAQglAAgXgSQgagVADgiQAEgcAVgcIAaAUQgRAZABAVQAEAYAwAAgEgnaABtIgjAAIAAk6ICEAAIAAAhIhhAAgEgjkgBqQgXgbgmgZIAYgcQAsAZAVAZgEgijgA3QgVAcgOAIIgSgmQBDg8AVhYIAnALQAOAFgRAFQgJAagQAcIA2AAQAZglALgjIAmAOQAMAJgRACQgNAVgUAaIBdAAIAAAdIhdAAIAAAsIBOAAIAAAcIhOAAIAAAnIBMAAIAAAdIhMAAIAAAvIBpAAIAAAcIjOAAIAAAUIgjAAgEglBACbQAqgPAcgYIAAhrIg/AAIAAghIBiAAIAACQQAgAjA6AAIDWAAIgJAhIjNAAQhMAAglgxQgVAfgqAYgEgiAgBlIAAAsIBBAAIAAgsgEgiAgAdIAAAnIBBAAIAAgngA52AJQAjAmAAA1QAAAqgVAUQgVAVgoADIhBAAQgsgDgUgJQgagMAAgcQACgOACgPQgCAAgHAAQgVgBgOgWQgSgaACgnQACgbARgUQASgWAZAAQAGAAAHACIAAgtIhLAAIAAgjIBLAAIAAhDIAjAAIAABDIBSAAIAAAjIhSAAIAABCQAPATAAAYQAAAygbAYQgIAYABALQACAOAKAFQAJAGAZAAIBKAAQAsAAAAgxQAAgjgbgkgA9ABFQAQABAJgRQAFgLACgQQACgTgIgLQgHgPgNAAQgZAAgEAmQgBAVAGAOQAHAPALAAgA6Eh9QAxAgAiAwIgZAiQgqg+gjgWgAtVhuIAAE6IiEAAIAAgiIBhAAIAAkYgA3jjfIAAG/IFejPIAADPIBMAAIAAm/IhMAAIAADOgAo+gKQAngOAzgRIANAoQg6APgpAOIAABUIgjAAIAAhGQgqAUgQANQgTASAAATQAAAeAOAHQAKAGAiAAIBwAAIAAAnIhwAAQguAAgZgRQgYgPAAghQAAgrAVgYQAYgeBDgcQgDghgZgFQghgFgZAWQgHAHgcAsIgigZQApgyAXg+IhFAAIAAgnIBRAAQALgeADgbIAlAKQgEAWgIAZICHAAIAAAnIiTAAQgPAlgRATQAcgWAnACQAoADAKA2gAi8hXQAABKgcA6QAVARAOANIgaAjQgIgIgTgSQgxBOhWAgIgageQBXgjAshHQg3gwgdgQIASgcQAjAVAzAkQAUgwAAg+IAAgMIhyAAQgTBWg1AwIgcgaQBIhCgBiBIAoAAQAAAcgDAZICOAAgAhfhAQAQAXAaBAIghAQQgVg2gUgjgAgRhlQAYAnATAvIghAPQgVg2gTghgEgiAAAnIAAAvIBBAAIAAgvg");
	this.shape_3.setTransform(0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	// 黒
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(0,0,0,0.749)").ss(7,1,1).p("AAqBGQAfg1gBhlIAhAEQgCBqgjA+QgjA/hWAnIgWgeQBVgeAgg8gAGOjPQAWAAAPASQALAMACAQQABAZgQAQQgNAOgUAAIAAAIQAABkg4BNQg3BOhgAmIgagjQBbgeAxhBQA1hDAAhgIjcAAIAAgmIDTAAQgEgHAAgNQAAgTAPgQQARgOATgCgAGOiDQALAAAHgHQAHgHAAgLQAAgLgHgGQgHgHgLgCQgKAAgHAHQgJAIABANQACALAGAFQAHAHAKAAgAK3BmQAUgcAHg6IAmASQgWCPh0AAQg5ACgWgcQgVgagCg/IAAjyIAjAAIAADyQAAArAQASQAQAQAxgCQAngCAUghgARTieIAAAjQhTADgzAsQgwAqAAA7QAAA5AmAeQAjAcBIAAIgLAnQhSAAgugsQgpgmgChDQAAgmAYgqQAagwAtgaIi4AAIAAgigAZEiCIAAAjIh0AAQgaCGg1BpIgggXQAzhfAXh5IhGAAIAAgjIBMAAQAGglACgkIAnAGQgEAigFAhgASzARQAeAcAqAtQApAsAVAcIgiAgQgthDhHhJQgfgfAAgXQAAgPAagcQBEhFAwhRIAgAaQhIBkgyAtQgPAQAAAIQAAAHAKAIgAaQgrIAAAhIiZAAIAAghgAajjLIAABEIgeAAIAAhEgAZ0jLIAABEIgeAAIAAhEgAdph8QA8gGAngGIAFAhQgeAIg6AGQAiBFAzAwIgbAiQgogihDgDQgpAAgRATQgQAQAAAVQAAAhAbAPQAkAUBkAAIgGAnQh1AAgtgjQgegVgCgsQgBgpAfgcQAdgbAmAAQAxACAcAKQgYgkgag0QhOANgzACIgDglQAwgEBFgJQgMgjgMglIAjgLQAMAsAMAigEAj6gCDQAgAqAVA7QAVA3AFA7IgoANQgFg1gUg5QgUg+gbgjgEAhSACGQAYAFAVhKIAgAZQgOAxgXAXQgSAVgagEQg6gHgBiZQAAhVAIhYIAoAFQgMBTAABXQACBsAZAFgEgnaABtIgjAAIAAk6ICEAAIAAAhIhhAAgEgjkgBqQgXgbgmgZIAYgcQAsAZAVAZgEgijgA3QgVAcgOAIIgSgmQBDg8AVhYIAnALQAOAFgRAFQgJAagQAcIA2AAQAZglALgjIAmAOQAMAJgRACQgNAVgUAaIBdAAIAAAdIhdAAIAAAsIBOAAIAAAcIhOAAIAAAnIBMAAIAAAdIhMAAIAAAvIBpAAIAAAcIjOAAIAAAUIgjAAgEglBACbQAqgPAcgYIAAhrIg/AAIAAghIBiAAIAACQQAgAjA6AAIDWAAIgJAhIjNAAQhMAAglgxQgVAfgqAYgEgiAgBlIAAAsIBBAAIAAgsgEgiAgAdIAAAnIBBAAIAAgngA52AJQAjAmAAA1QAAAqgVAUQgVAVgoADIhBAAQgsgDgUgJQgagMAAgcQACgOACgPQgCAAgHAAQgVgBgOgWQgSgaACgnQACgbARgUQASgWAZAAQAGAAAHACIAAgtIhLAAIAAgjIBLAAIAAhDIAjAAIAABDIBSAAIAAAjIhSAAIAABCQAPATAAAYQAAAygbAYQgIAYABALQACAOAKAFQAJAGAZAAIBKAAQAsAAAAgxQAAgjgbgkgA9ABFQAQABAJgRQAFgLACgQQACgTgIgLQgHgPgNAAQgZAAgEAmQgBAVAGAOQAHAPALAAgA6Eh9QAxAgAiAwIgZAiQgqg+gjgWgAtVhuIAAE6IiEAAIAAgiIBhAAIAAkYgA3jjfIAAG/IFejPIAADPIBMAAIAAm/IhMAAIAADOgAo+gKQAngOAzgRIANAoQg6APgpAOIAABUIgjAAIAAhGQgqAUgQANQgTASAAATQAAAeAOAHQAKAGAiAAIBwAAIAAAnIhwAAQguAAgZgRQgYgPAAghQAAgrAVgYQAYgeBDgcQgDghgZgFQghgFgZAWQgHAHgcAsIgigZQApgyAXg+IhFAAIAAgnIBRAAQALgeADgbIAlAKQgEAWgIAZICHAAIAAAnIiTAAQgPAlgRATQAcgWAnACQAoADAKA2gAi8hXQAABKgcA6QAVARAOANIgaAjQgIgIgTgSQgxBOhWAgIgageQBXgjAshHQg3gwgdgQIASgcQAjAVAzAkQAUgwAAg+IAAgMIhyAAQgTBWg1AwIgcgaQBIhCgBiBIAoAAQAAAcgDAZICOAAgAgRhlQAYAnATAvIghAPQgVg2gTghgAhfhAQAQAXAaBAIghAQQgVg2gUgjgEgiAAAnIAAAvIBBAAIAAgvgEAndACnQAMgMAAgQQAAgQgMgNQgMgLgQAAQgQAAgMALQgMANAAAQQAAAQAMAMQAMAMAQAAQAQAAAMgMgEAntABfQARARAAAbQAAAagRASQgSARgaAAQgaAAgSgRQgSgSAAgaQAAgbASgRQASgSAaAAQAaAAASASgAaaCQIAAAnIhyAAQglAAgXgSQgagVADgiQAEgcAVgcIAaAUQgRAZABAVQAEAYAwAAg");
	this.shape_4.setTransform(0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	// 黒
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(0,0,0,0.498)").ss(10,1,1).p("AAqBGQAfg1gBhlIAhAEQgCBqgjA+QgjA/hWAnIgWgeQBVgeAgg8gAGOjPQAWAAAPASQALAMACAQQABAZgQAQQgNAOgUAAIAAAIQAABkg4BNQg3BOhgAmIgagjQBbgeAxhBQA1hDAAhgIjcAAIAAgmIDTAAQgEgHAAgNQAAgTAPgQQARgOATgCgAGOiDQALAAAHgHQAHgHAAgLQAAgLgHgGQgHgHgLgCQgKAAgHAHQgJAIABANQACALAGAFQAHAHAKAAgARTieIAAAjQhTADgzAsQgwAqAAA7QAAA5AmAeQAjAcBIAAIgLAnQhSAAgugsQgpgmgChDQAAgmAYgqQAagwAtgaIi4AAIAAgigAK3BmQAUgcAHg6IAmASQgWCPh0AAQg5ACgWgcQgVgagCg/IAAjyIAjAAIAADyQAAArAQASQAQAQAxgCQAngCAUghgAZEiCIAAAjIh0AAQgaCGg1BpIgggXQAzhfAXh5IhGAAIAAgjIBMAAQAGglACgkIAnAGQgEAigFAhgASzARQAeAcAqAtQApAsAVAcIgiAgQgthDhHhJQgfgfAAgXQAAgPAagcQBEhFAwhRIAgAaQhIBkgyAtQgPAQAAAIQAAAHAKAIgAaQgrIAAAhIiZAAIAAghgAajjLIAABEIgeAAIAAhEgAZ0jLIAABEIgeAAIAAhEgAdph8QA8gGAngGIAFAhQgeAIg6AGQAiBFAzAwIgbAiQgogihDgDQgpAAgRATQgQAQAAAVQAAAhAbAPQAkAUBkAAIgGAnQh1AAgtgjQgegVgCgsQgBgpAfgcQAdgbAmAAQAxACAcAKQgYgkgag0QhOANgzACIgDglQAwgEBFgJQgMgjgMglIAjgLQAMAsAMAigEAhSACGQAYAFAVhKIAgAZQgOAxgXAXQgSAVgagEQg6gHgBiZQAAhVAIhYIAoAFQgMBTAABXQACBsAZAFgEAj6gCDQAgAqAVA7QAVA3AFA7IgoANQgFg1gUg5QgUg+gbgjgEAntABfQARARAAAbQAAAagRASQgSARgaAAQgaAAgSgRQgSgSAAgaQAAgbASgRQASgSAaAAQAaAAASASgEAndACnQAMgMAAgQQAAgQgMgNQgMgLgQAAQgQAAgMALQgMANAAAQQAAAQAMAMQAMAMAQAAQAQAAAMgMgAaaCQIAAAnIhyAAQglAAgXgSQgagVADgiQAEgcAVgcIAaAUQgRAZABAVQAEAYAwAAgEgnaABtIgjAAIAAk6ICEAAIAAAhIhhAAgEgjkgBqQgXgbgmgZIAYgcQAsAZAVAZgEgijgA3QgVAcgOAIIgSgmQBDg8AVhYIAnALQAOAFgRAFQgJAagQAcIA2AAQAZglALgjIAmAOQAMAJgRACQgNAVgUAaIBdAAIAAAdIhdAAIAAAsIBOAAIAAAcIhOAAIAAAnIBMAAIAAAdIhMAAIAAAvIBpAAIAAAcIjOAAIAAAUIgjAAgEglBACbQAqgPAcgYIAAhrIg/AAIAAghIBiAAIAACQQAgAjA6AAIDWAAIgJAhIjNAAQhMAAglgxQgVAfgqAYgEgiAgBlIAAAsIBBAAIAAgsgEgiAgAdIAAAnIBBAAIAAgngA52AJQAjAmAAA1QAAAqgVAUQgVAVgoADIhBAAQgsgDgUgJQgagMAAgcQACgOACgPQgCAAgHAAQgVgBgOgWQgSgaACgnQACgbARgUQASgWAZAAQAGAAAHACIAAgtIhLAAIAAgjIBLAAIAAhDIAjAAIAABDIBSAAIAAAjIhSAAIAABCQAPATAAAYQAAAygbAYQgIAYABALQACAOAKAFQAJAGAZAAIBKAAQAsAAAAgxQAAgjgbgkgA9ABFQAQABAJgRQAFgLACgQQACgTgIgLQgHgPgNAAQgZAAgEAmQgBAVAGAOQAHAPALAAgA6Eh9QAxAgAiAwIgZAiQgqg+gjgWgAtVhuIAAE6IiEAAIAAgiIBhAAIAAkYgA3jjfIAAG/IFejPIAADPIBMAAIAAm/IhMAAIAADOgAo+gKQAngOAzgRIANAoQg6APgpAOIAABUIgjAAIAAhGQgqAUgQANQgTASAAATQAAAeAOAHQAKAGAiAAIBwAAIAAAnIhwAAQguAAgZgRQgYgPAAghQAAgrAVgYQAYgeBDgcQgDghgZgFQghgFgZAWQgHAHgcAsIgigZQApgyAXg+IhFAAIAAgnIBRAAQALgeADgbIAlAKQgEAWgIAZICHAAIAAAnIiTAAQgPAlgRATQAcgWAnACQAoADAKA2gAi8hXQAABKgcA6QAVARAOANIgaAjQgIgIgTgSQgxBOhWAgIgageQBXgjAshHQg3gwgdgQIASgcQAjAVAzAkQAUgwAAg+IAAgMIhyAAQgTBWg1AwIgcgaQBIhCgBiBIAoAAQAAAcgDAZICOAAgAhfhAQAQAXAaBAIghAQQgVg2gUgjgAgRhlQAYAnATAvIghAPQgVg2gTghgEgiAAAnIAAAvIBBAAIAAgvg");
	this.shape_5.setTransform(0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

	// 黒
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(0,0,0,0.247)").ss(13,1,1).p("AGOjPQAWAAAPASQALAMACAQQABAZgQAQQgNAOgUAAIAAAIQAABkg4BNQg3BOhgAmIgagjQBbgeAxhBQA1hDAAhgIjcAAIAAgmIDTAAQgEgHAAgNQAAgTAPgQQARgOATgCgAAqBGQAfg1gBhlIAhAEQgCBqgjA+QgjA/hWAnIgWgeQBVgeAgg8gAGOiDQALAAAHgHQAHgHAAgLQAAgLgHgGQgHgHgLgCQgKAAgHAHQgJAIABANQACALAGAFQAHAHAKAAgAK3BmQAUgcAHg6IAmASQgWCPh0AAQg5ACgWgcQgVgagCg/IAAjyIAjAAIAADyQAAArAQASQAQAQAxgCQAngCAUghgARTieIAAAjQhTADgzAsQgwAqAAA7QAAA5AmAeQAjAcBIAAIgLAnQhSAAgugsQgpgmgChDQAAgmAYgqQAagwAtgaIi4AAIAAgigAZEiCIAAAjIh0AAQgaCGg1BpIgggXQAzhfAXh5IhGAAIAAgjIBMAAQAGglACgkIAnAGQgEAigFAhgASzARQAeAcAqAtQApAsAVAcIgiAgQgthDhHhJQgfgfAAgXQAAgPAagcQBEhFAwhRIAgAaQhIBkgyAtQgPAQAAAIQAAAHAKAIgAaQgrIAAAhIiZAAIAAghgAajjLIAABEIgeAAIAAhEgAZ0jLIAABEIgeAAIAAhEgAdph8QA8gGAngGIAFAhQgeAIg6AGQAiBFAzAwIgbAiQgogihDgDQgpAAgRATQgQAQAAAVQAAAhAbAPQAkAUBkAAIgGAnQh1AAgtgjQgegVgCgsQgBgpAfgcQAdgbAmAAQAxACAcAKQgYgkgag0QhOANgzACIgDglQAwgEBFgJQgMgjgMglIAjgLQAMAsAMAigEAhSACGQAYAFAVhKIAgAZQgOAxgXAXQgSAVgagEQg6gHgBiZQAAhVAIhYIAoAFQgMBTAABXQACBsAZAFgEAj6gCDQAgAqAVA7QAVA3AFA7IgoANQgFg1gUg5QgUg+gbgjgEAntABfQARARAAAbQAAAagRASQgSARgaAAQgaAAgSgRQgSgSAAgaQAAgbASgRQASgSAaAAQAaAAASASgEAndACnQAMgMAAgQQAAgQgMgNQgMgLgQAAQgQAAgMALQgMANAAAQQAAAQAMAMQAMAMAQAAQAQAAAMgMgAaaCQIAAAnIhyAAQglAAgXgSQgagVADgiQAEgcAVgcIAaAUQgRAZABAVQAEAYAwAAgEgjkgBqQgXgbgmgZIAYgcQAsAZAVAZgEgnaABtIgjAAIAAk6ICEAAIAAAhIhhAAgEgijgA3QgVAcgOAIIgSgmQBDg8AVhYIAnALQAOAFgRAFQgJAagQAcIA2AAQAZglALgjIAmAOQAMAJgRACQgNAVgUAaIBdAAIAAAdIhdAAIAAAsIBOAAIAAAcIhOAAIAAAnIBMAAIAAAdIhMAAIAAAvIBpAAIAAAcIjOAAIAAAUIgjAAgEglBACbQAqgPAcgYIAAhrIg/AAIAAghIBiAAIAACQQAgAjA6AAIDWAAIgJAhIjNAAQhMAAglgxQgVAfgqAYgEgiAgBlIAAAsIBBAAIAAgsgEgiAgAdIAAAnIBBAAIAAgngA52AJQAjAmAAA1QAAAqgVAUQgVAVgoADIhBAAQgsgDgUgJQgagMAAgcQACgOACgPQgCAAgHAAQgVgBgOgWQgSgaACgnQACgbARgUQASgWAZAAQAGAAAHACIAAgtIhLAAIAAgjIBLAAIAAhDIAjAAIAABDIBSAAIAAAjIhSAAIAABCQAPATAAAYQAAAygbAYQgIAYABALQACAOAKAFQAJAGAZAAIBKAAQAsAAAAgxQAAgjgbgkgA9ABFQAQABAJgRQAFgLACgQQACgTgIgLQgHgPgNAAQgZAAgEAmQgBAVAGAOQAHAPALAAgA6Eh9QAxAgAiAwIgZAiQgqg+gjgWgA3jjfIAAG/IFejPIAADPIBMAAIAAm/IhMAAIAADOgAtVhuIAAE6IiEAAIAAgiIBhAAIAAkYgAo+gKQAngOAzgRIANAoQg6APgpAOIAABUIgjAAIAAhGQgqAUgQANQgTASAAATQAAAeAOAHQAKAGAiAAIBwAAIAAAnIhwAAQguAAgZgRQgYgPAAghQAAgrAVgYQAYgeBDgcQgDghgZgFQghgFgZAWQgHAHgcAsIgigZQApgyAXg+IhFAAIAAgnIBRAAQALgeADgbIAlAKQgEAWgIAZICHAAIAAAnIiTAAQgPAlgRATQAcgWAnACQAoADAKA2gAi8hXQAABKgcA6QAVARAOANIgaAjQgIgIgTgSQgxBOhWAgIgageQBXgjAshHQg3gwgdgQIASgcQAjAVAzAkQAUgwAAg+IAAgMIhyAAQgTBWg1AwIgcgaQBIhCgBiBIAoAAQAAAcgDAZICOAAgAgRhlQAYAnATAvIghAPQgVg2gTghgAhfhAQAQAXAaBAIghAQQgVg2gUgjgEgiAAAnIAAAvIBBAAIAAgvg");
	this.shape_6.setTransform(0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-267.8,-28.8,534.7,57.7);


(lib.UI_vol_base = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.4)").s().p("AFZDcIAAm3IH5AAIAAG3gAtRDcIAAm3ISWAAIAAG3g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.6)").s().p("AgEDcIAAm3IAJAAIAAG3g");
	this.shape_1.setTransform(33,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("AgEDcIAAm3IAJAAIAAG3g");
	this.shape_2.setTransform(34,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.UI_vol_base, new cjs.Rectangle(-85,-22,170,44), null);


(lib.UI_TitleMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 節タイトル
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLBJQgbAAgCgUIgCgKQgFACgEAAQgIAAgFgGQgIgHAAgOQAAgQAJgHQAHgHAMAAQAFAAAFACIAAgTIgiADIgCgOIAkgDIAAgcIAMAAQAGABgFADIAAAXIAdgCIACAMIgfADIAAAfQADADAAAFQAAAMgKANIABARQABAKAPAAIAhAAQAOAAAAgOIAAgaIANAEIAAAZQAAAYgYAAgAg2ACQgGAEAAAMQAAAJAFADQACACADABQAGgBAEgEQAGgGAAgKQABgIgCgCQgFgDgEAAQgHAAgDADgAAbggIAIgMQAYARAOAOIgJAMQgUgUgRgLg");
	this.shape.setTransform(310.4,9.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhJBAQATgeAPgvIgdADIgBgOIAhgCQAGgVAEgVIAOAFQAIADgJADIgIAdIARgBQAIAAAFAFQAIAIAAAbQAAAmgLALQgGAHgJAAQgMAAgNgPIAJgLQAKAKAGAAQADAAADgDQAGgHAAghQAAgSgDgEQgCgCgGAAIgRACQgOAwgTAjgAAZghIAMgIQAbAbAKAnIgPAGQgMgrgWgVg");
	this.shape_1.setTransform(293.2,9.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAlQAwgBARgQQAJgKABgNQAAgQgLgKQgIgIgUAAQgQAAgWAIQgRAGgVAJIgHgRIAlgLQAfgJARAAQAbAAAMAMQANANAAAVQAAAWgMAMQgXAWgzABg");
	this.shape_2.setTransform(276.2,10.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgIBLQgWABgIgJQgHgHAAgKQAAgKAJgJQANgOAZgKQgBgHgBgCQgDgDgJAAQgNAAgbAWIgLgKQAfgTALgXIglACIgDgMIAtgCQAEgJAEgSIAMADQAHACgHAEIgFARIAtgFIACANIgzAEQgHAOgGAHQAIgCAHAAQAIAAAFAFQAEAEABAJIAtgNIAEAOQgaAFgWAIIAAAdIgNAAIAAgYQgTAKgGAGQgIAHAAAHQAAAEAEAEQAFAFANAAIA3AAIAAAMg");
	this.shape_3.setTransform(259.5,10);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAABAQAegPAJgNQgIgNgDgeQgHAKgDADIgEgEIgOAAIAAAOIAUAAIAAAKIgUAAIAAAPIAXgFIAAALIg0ALQAAAFgDgDIgFgOIAagDIAAgRIgUAAIAAgKIAUAAIAAgOIgXAAIAAgKIAvAAQAQgVAFgrIAPACQAAAAAAABQAAAAAAABQAAABAAAAQgBAAAAABIgHAZIAkAAIAAAMIgKAAQgBAkgMAdQAJAMAPALIgHAPQgRgNgIgNQgMAOgcAOgAAvAXQAHggABgUIgRAAQABAjAIARgAg3BKIAAhKQgHALgHAGIgIgLQATgRAMggIAMAIQACAEgEgBIgHANIAABdgAgfgRIAAgtIAKAAQAFAAgEAEIAAAYIAJAAIAAgpIALAAQAEABgEADIAAAlIAKAAIAAgbIAKAAQAGABgFADIAAAiIgpAAIAAAGgAhJglQAQgPAKgXIALAIQAEADgGAAQgNAZgQANg");
	this.shape_4.setTransform(242.1,10);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgtBMIAAg1IgTAGQgBAGgCgDIgFgPIAbgJIAAgkIgMAAQgDASgDAIIgMgFQAIgVACghIAMACQAFACgFACIgBAMIAJAAIAAggIANAAQAFAAgEAEIAAAcIAQAAIAAAPIgQAAIAAAdIAOgDIACALIgQAIIAAA7gAAdBLIgCgNIAKAAQABAAAAAAQABAAAAgBQAAAAABAAQAAgBAAAAIAAglIgxAAIAAgOIAxAAIAAgQIg3AAIAAgMIAkAAIAAgUIgdAAIAAgNIAdAAIAAgXIANAAQAFAAgEAEIAAATIAfAAIAAANIgfAAIAAAUIApAAIAAAMIgXAAIAAAQIAUAAIAAAOIgUAAIAAAqQAAAKgIAAgAgEAjIAKgIQAOAJAFAJIgMAKQgGgKgLgKg");
	this.shape_5.setTransform(225.2,10);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAEAyQAYgIANgNQAMgMAAgSQAAgVgNgOQgOgNgdABIAKAGQAJADgJAEQgKBCgQAPQgJAJgJAAQgKAAgGgGQgQgQAAgYQAAgcAVgVQAWgWAggBQAcABARAQQATATAAAZQAAAbgSAQQgKAMgYALgAglgfQgRARAAAZQAAAPAKAJQACADAEAAQAEAAAFgFQAPgPAHhCQgRAEgNANg");
	this.shape_6.setTransform(208.2,10.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgtBLIAAhBQgMAKgNAIIgFgOQAfgQASgfIgsAAIAAgNIAZAAIAAgcIANAAQAFAAgFAEIAAAYIAOAAIADgCIAKAJIgFAEQgIAPgOARQARAFANAIIgIAPQgLgJgLgGIAABBgAgNBDIAAgOIAmAAIAAhEIgbAAIAAgPIAbAAIAAgoIAPAAQAGABgGAEIAAAjIAeAAIAAAPIgeAAIAABEIAlAAIAAAOg");
	this.shape_7.setTransform(191.1,10);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAqA9IhgALQgDADgCgCIgFgRIAbgBIATgiIgwAAIAAgOICHAAIAAAOIhHAAIgUAhIA2gEIgTgPIALgIQAhAXALAQIgNAJQgGgHgHgHgAhLgUQAvgMAXgqIAMACQAGABgFADQAVAgAvAMIgHAQQgLgDgTgLIAAAOIhKAAIAAgNQgRANgQAEgAghgWIBHAAQgYgNgOgZQgNAYgUAOg");
	this.shape_8.setTransform(174.2,9.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgTBHIgGgPIAQAAQAgAAAJgIQAHgIAAgJQAAgIgGgHQgGgGgOAAQgcAAgYAdIgNgBIAHhGIAOACQAGADgGADIgFAqQAXgTAdAAQASAAALAJQAIAJAAAOQAAAPgLAMQgNANgkAAgAgng6IAGgMQATAFAfALIgHAOQgXgKgagIg");
	this.shape_9.setTransform(157.8,9.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AhJBAQATgeAPgvIgdADIgBgOIAhgCQAGgVAEgVIAOAFQAIADgJADIgIAdIARgBQAIAAAFAFQAIAIAAAbQAAAmgLALQgGAHgJAAQgMAAgNgPIAJgLQAKAKAGAAQADAAADgDQAGgHAAghQAAgSgDgEQgCgCgGAAIgRACQgOAwgTAjgAAZghIAMgIQAbAbAKAnIgPAGQgMgrgWgVg");
	this.shape_10.setTransform(140.4,9.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAmBMIAAgDIhLAAIAAADIgOAAIAAgwIBmAAIAAAwgAglA/IBLAAIAAgHIhLAAgAglAtIBLAAIAAgHIhLAAgAhLAUIAAgKIBFAAIAAgJIgwAAIAAgJIAwAAIAAgIIgvAAIAAgLIAvAAIAAgIIhCAAIAAgKIBCAAIAAgIIguAAIAAgKIAuAAIAAgNIAMAAQAFACgEADIAAAIIAtAAIAAASIAWAAIAAAKIgWAAIAAATIgtAAIAAAIIAwAAIAAAJIgwAAIAAAJIBFAAIAAAKgAAHgbIAgAAIAAgIIggAAgAAHgtIAgAAIAAgIIggAAg");
	this.shape_11.setTransform(123.4,9.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag+BCQAggEAEgPIgxAAIAAgKIAyAAIAAgKIgLAAIgLAAIAAg+IAyAAIgJgHQAMgNAGgWIAOAFQAFACgIACIgCAFIAzAAIAAALIgfAAIAHAKIgNADIgGgNIgMAAIgMARIArAAIAAA+IgTAAIAAAKIAuAAIAAAKIguAAIAAAcIgMAAIAAgcIgeAAQgCAYgrAHgAgMAlIAdAAIAAgKIgdAAgAgjAQIBIAAIAAgJIhIAAgAgjAAIBIAAIAAgIIhIAAgAgjgQIBIAAIAAgJIhIAAgAhIgmQASgQAHgXIANAGQAFACgHABIgDAFIAnAAIAAALIgVAAIAGAKIgOACIgEgMIgKAAQgIAPgMAJg");
	this.shape_12.setTransform(106.4,10);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhCBKIAAg2IA2AAIAAA0IgNAAIAAgHIgcAAIAAAJgAg1A2IAcAAIAAgXIgcAAgAAcBKIAAhSIgjAAIAAgMIAjAAIAAg1IANAAQAGABgGADIAAAxIAiAAIAAAMIgiAAIAABSgAg+AKIAAgMIAuAAIAAAMgAg+gLIAAgNIAuAAIAAANgAhKghIAAgMIBGAAIAAAMgAg+g5IAAgMIAuAAIAAAMg");
	this.shape_13.setTransform(89.4,9.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhHBKIAAgNIAZAAIAAgwQgKAJgMAGIgHgNQAjgPAJgeIgnAAIAAgNIAsAAQgDgIgJgMIAMgHQAKAMAEAPIAVAAQAHgMAGgSIAQAGQACADgGABQgHAPgFAFIAvAAIAAANIgoAAQAOAfAhAMIgIAOQgSgJgEgGIAAAxIAZAAIAAANgAASA9IAQAAIAAgpIgQAAgAgHA9IAOAAIAAgpIgOAAgAgiA9IAPAAIAAgpIgPAAgAgoAHIBQAAQgSgSgHgTIgfAAQgHAZgRAMg");
	this.shape_14.setTransform(72.6,9.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAgA6IAGgKQATAJATAHIgHANQgTgIgSgLgAg9BMIgCgMIAKAAQABAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAgBIAAgsIgRAGQAAAFgDgCIgEgQIAYgHIAAggIgUAAIAAgMIAUAAIAAgjIANAAQAGABgFADIAAAfIARAAIAAAMIgRAAIAAAdIAPgFIACALIgRAHIAAA1QAAALgLgBgAgeA/QAVgFARgKIAIAKQADAEgGgBQgQAJgWAFgAgQAtIAAhMIBVAAIAABMgAgDAiIA6AAIAAgLIg6AAgAgDANIA6AAIAAgMIg6AAgAgDgIIA6AAIAAgMIg6AAgAgHgnIAAghIBCAAIAAAhgAADgxIAtAAIAAgMIgtAAg");
	this.shape_15.setTransform(55.4,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// 節番号
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AghBBIAAgLQAPgcAWgaQANgOAAgQQAAgLgGgGQgEgEgHAAQgEAAgGAFQgGAGAAATIgOAAQABgYAKgLQAIgIAMAAQANAAAJAJQAJAJAAARQAAATgSAUQgSAWgNAUIAzAAIAAANg");
	this.shape_16.setTransform(36.2,9.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgUA4QgPgQgBgoQABgmAPgQQAKgKAKAAQALAAAKAKQAPAQAAAmQAAAogPAQQgKAJgLAAQgKAAgKgJgAgIgvQgMANAAAiQAAAkAMAMQAEAEAEAAQAEAAAEgEQANgMAAgkQAAgigNgNQgEgEgEAAQgEAAgEAEg");
	this.shape_17.setTransform(27.7,9.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AghBBIAAgLQAPgcAWgaQANgOAAgQQAAgLgGgGQgEgEgHAAQgEAAgGAFQgGAGAAATIgOAAQABgYAKgLQAIgIAMAAQANAAAJAJQAJAJAAARQAAATgSAUQgSAWgNAUIAzAAIAAANg");
	this.shape_18.setTransform(19.2,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16}]}).wait(1));

	// Base
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(0,0,0,0.647)").s().p("Eg2rABkIAAjHMBtXAAAIAADHg");
	this.shape_19.setTransform(350,10);

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(1));

}).prototype = getMCSymbolPrototype(lib.UI_TitleMC, new cjs.Rectangle(0,-0.5,700,21), null);


(lib.UI_hide1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg2rBCBMAAAiEBMBtXAAAMAAACEBg");
	this.shape.setTransform(0,422.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-350,0,700,845);


(lib.UI_cBaseMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnzH0IAAvnIPnAAIAAPng");
	this.shape.setTransform(50,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.UI_cBaseMC, new cjs.Rectangle(0,0,100,100), null);


(lib.u_b = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnzH0IAAvnIPnAAIAAPng");
	this.shape.setTransform(50,50);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,100);


(lib.s09MC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10));

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBEQgTgTAAgxQAAgwATgTQAJgJAPAAQAPAAAKAJQATATAAAwQAAAxgTATQgKAJgPAAQgPAAgJgJgAgMg0QgMALAAApQAAAqAMALQAGAGAGAAQAHAAAGgGQALgLAAgqQAAgpgLgLQgGgGgHAAQgGAAgGAGg");
	this.shape.setTransform(0,-0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AACBMIAAhzIgXAAIAAgQQAagCADgSIAOAAIAACXg");
	this.shape_1.setTransform(-0.8,-0.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnBNIAAgQQANgdAYgXQAWgXAAgVQAAgMgFgGQgGgFgIAAQgSAAgBAlIgTAAQAAgdAPgQQAKgKANAAQAQAAALALQAMAMAAARQAAAegbAaQgSATgKAUIA1AAIAAASg");
	this.shape_2.setTransform(0,-0.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbBCQgLgLgCgeIATAAQAAAUAJAJQAFAFAHAAQAJAAAGgGQAHgGAAgNQAAgMgIgIQgIgIgOABIAAgVQAaADAAgbQAAgKgGgGQgEgEgIAAQgGAAgEAEQgJAIABARIgTAAQABgZAMgMQALgKANAAQARAAAKAKQAKALAAARQAAAVgOAOQASAQAAAVQAAATgMANQgMALgRAAQgQAAgLgLg");
	this.shape_3.setTransform(0,-0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAGBMIAAgmIgtAAIAAgRIAqhgIAXAAIAABfIAOAAIAAASIgOAAIAAAmgAgUAUIAaAAIAAg9g");
	this.shape_4.setTransform(0,-0.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgZBDQgLgMgDgYIATAAQABAQAIAHQAEAEAHAAQAIABAGgHQAHgHAAgUQAAgRgHgIQgGgFgIAAQgNAAgGALIgTAAIAFhSIBCAAIAAASIguAAIgEArQAKgIALAAQANAAALAKQAMANAAAZQAAAcgMANQgLALgRgBQgPAAgKgJg");
	this.shape_5.setTransform(0,-0.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgZBCQgPgQAAguQAAgzARgRQAMgMAOAAQAOAAAIAJQALAKADARIgTAAQgDgIgEgEQgFgFgGAAQgGAAgFAFQgKALgCAeQAKgNANAAQAPAAALALQAOANgBAaQABAagOAOQgMALgPAAQgOAAgMgLgAgLAAQgHAHAAATQAAATAHAHQAGAGAGAAQAHAAAGgGQAJgJAAgRQAAgRgJgJQgGgFgHAAQgGAAgGAFg");
	this.shape_6.setTransform(0,-0.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgUBMIAmiFIg3AAIAAgSIBLAAIAAARIgnCGg");
	this.shape_7.setTransform(0,-0.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgcBBQgMgMAAgVQAAgTASgQQgPgNAAgVQAAgSALgMQAKgJAQAAQARAAAKAJQALAMAAASQAAAVgRANQAUANAAAWQAAAVgMAMQgMAMgRAAQgQAAgMgMgAgNAMQgIAHAAANQAAANAIAHQAGAGAHAAQAIAAAGgGQAHgHAAgNQAAgNgHgHQgGgGgIAAQgHAAgGAGgAgMg0QgGAGAAAKQAAAKAGAFQAGAGAGAAQAHAAAGgGQAFgFAAgKQAAgKgFgGQgGgFgHAAQgGAAgGAFg");
	this.shape_8.setTransform(0,-0.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgYBEQgJgKgEgSIASAAQAGASALAAQAHAAAFgFQAIgIAFggQgKAMgOAAQgOAAgKgKQgQgPABgZQgBgaAQgPQAKgKAOAAQAOAAALAKQARASAAAxQAAAwgRASQgLAKgOAAQgOAAgJgJgAgNg0QgIAIAAATQAAATAIAHQAGAFAGAAQAHAAAGgFQAHgHABgTQgBgTgHgIQgGgFgHAAQgGAAgGAFg");
	this.shape_9.setTransform(0,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.2,-11.5,14.5,23);


(lib.p1l_音量ツマミMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(2));

	// 色
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AAEBFIgHAAQgdAAAAgdIAAhPQAAgdAdAAIAHAAQAdAAAAAdIAABPQAAAdgdAAIAAAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFFF").s().p("AAEBFIgHAAQgdAAAAgdIAAhPQAAgdAdAAIAHAAQAdAAAAAdIAABPQAAAdgdAAIAAAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(1));

	// つまみ
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYBpQgqAAAAgqIAAh9QAAgqAqAAIAxAAQAqAAAAAqIAAB9QAAAqgqAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.7,-10.5,13.5,21);


(lib.p1l_vol_disp_iroBase = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","#666666"],[0,1],0,-3,0,3).s().p("AnzAeIAAg7IPnAAIAAA7g");
	this.shape.setTransform(50,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1l_vol_disp_iroBase, new cjs.Rectangle(-1,-3,101,6), null);


(lib.p1l_vol_disp_iro = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AnzAZIAAgxIPnAAIAAAxg");
	this.shape.setTransform(50,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1l_vol_disp_iro, new cjs.Rectangle(0,-2.5,100,5), null);


(lib.IF_progressBase = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","#B3B3B3"],[0,1],0,-3,0,3).s().p("Eg1HAAeIAAg7MBqPAAAIAAA7g");
	this.shape.setTransform(340,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.IF_progressBase, new cjs.Rectangle(0,-3,680,6), null);


(lib.IF_progress = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		// 進捗バーのサイズ
		this.myWidth = 680;
		// 学習済み領域明示幅変数
		this.current = 0;
		// 前回学習済み領域明示幅変数
		this.current_before = this.current;
		//コンテンツのトータルフレームを秒数にしてキャッシュ
		this.tFrames = Math.floor(cTotalFrames / cFps);
		//映像などの秒数追加(コンテンツ側exportRoot.IFaddSecond)
		/*
		if (exportRoot.IFaddSecond != void(0)) {
			this.tFrames += exportRoot.IFaddSecond;
		}
		*/
		//全体は何分何秒？ 
		this.parent.parent.funbyo.texT = min_sec(this.tFrames);
		// ★★★★★★★★★★★★★★★★★★★★★★★★★★
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF3300").s().p("Eg1HAAZIAAgxMBqPAAAIAAAxg");
	this.shape.setTransform(340,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.IF_progress, new cjs.Rectangle(0,-2.5,680,5), null);


(lib.IF_but_slider = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		if (getterm() == "pc") {
			this.mouse_on = function (haninai) {
				// 変化があったとき実行
				if (haninai != this["haninai2"]) {
					if (!haninai) {
						// 消灯
						this.gotoAndStop(1);
					} else {
						// 点灯
						this.gotoAndStop(2);
					}
					this.haninai2 = haninai;
				}
			}.bind(this);
			this.ef = function () {
				// 現在マウスの位置割り出し
				var lm = this.globalToLocal(stage.mouseX, stage.mouseY);
				// オンマウスで点灯
				this.mouse_on(this.hitTest(lm.x, lm.y));
			}.bind(this);
			this.addEventListener("tick", this.ef);
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(2));

	// ランプ
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AAEBFIgHAAQgdAAAAgdIAAhPQAAgdAdAAIAHAAQAdAAAAAdIAABPQAAAdgdAAIAAAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFFF").s().p("AAEBFIgHAAQgdAAAAgdIAAhPQAAgdAdAAIAHAAQAdAAAAAdIAABPQAAAdgdAAIAAAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(1));

	// ツマミ
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgYBpQgqAAAAgqIAAh9QAAgqAqAAIAxAAQAqAAAAAqIAAB9QAAAqgqAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.7,-10.5,13.5,21);


(lib.IF_but_進む三角 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		if (cFps == 6){
			this.gotoAndPlay(7);
		}
	}
	this.frame_10 = function() {
		if (cFps == 6){
			this.gotoAndPlay(1);
		}
	}
	this.frame_13 = function() {
		this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(6).call(this.frame_10).wait(3).call(this.frame_13).wait(1));

	// マーク
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABuCzIAAilIkXClIAAllIEXCkIAAikIA8AAIAAFlg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00FFFF").s().p("ABuCzIAAilIkXClIAAllIEXCkIAAikIA8AAIAAFlg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},7).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17,-17.8,34.1,35.8);


(lib.bt_vol = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// 斜線
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai2CwIFZl0IAUAVIlaF0g");
	this.shape.setTransform(-3.8,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(3));

	// 音量
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AhCB5QAuABAhgkQAggkAAgyQAAgxgggkQghgkguAAIAAgXQA3ABAnAqQAmAqABA7QgBA8gmArQgnAqg3AAg");
	this.shape_1.setTransform(16.2,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhCB5QAuABAhgkQAggkAAgyQAAgxgggkQghgkguAAIAAgXQA3ABAnAqQAmAqABA7QgBA8gmArQgnAqg3AAg");
	this.shape_2.setTransform(16.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.shape_2}]},3).wait(1));

	// 音量
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#333333").s().p("AgrBLQAbgCAUgVQATgVAAgfQAAgegTgVQgUgXgbAAIAAgVQAjgBAaAdQAaAcAAAnQAAAogaAcQgaAdgjgBg");
	this.shape_3.setTransform(14,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgrBLQAbgCAUgVQATgVAAgfQAAgegTgVQgUgXgbAAIAAgVQAjgBAaAdQAaAcAAAnQAAAogaAcQgaAdgjgBg");
	this.shape_4.setTransform(14,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3}]}).to({state:[{t:this.shape_4}]},2).wait(2));

	// 音量
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#333333").s().p("AgYAdQALAAAIgIQAHgJAAgMQAAgLgHgJQgIgIgLAAIAAgYQAUAAAOAPQAPAPAAAWQAAAXgPAQQgOAOgUAAg");
	this.shape_5.setTransform(12,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgYAdQALAAAIgIQAHgJAAgMQAAgLgHgJQgIgIgLAAIAAgYQAUAAAOAPQAPAPAAAWQAAAXgPAQQgOAOgUAAg");
	this.shape_6.setTransform(12,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5}]}).to({state:[{t:this.shape_6}]},1).wait(3));

	// マーク
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgGBRIAAihIB0hbIAAFXgAAWg7IAAB3IA3AqIAAjLgAhtBRIAAihIBhAAIAAChgAhRAyIApAAIAAhjIgpAAg");
	this.shape_7.setTransform(-4.9,0);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.1,-19.7,45,39.3);


(lib.copyright10baseW = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("AgJAtIAUhPIgfAAIAAgKIApAAIAAALIgVBOg");
	this.shape.setTransform(-4.8,0.1);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(7).to({_off:false},0).to({_off:true},1).wait(2));

	// レイヤー 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("AABAuIAAhGIgLAAIAAgGIADAAQAGAAADgFQAEgEABgGIAEAAIAABbg");
	this.shape_1.setTransform(-10.8,0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F2F2F2").s().p("AAMAnQgJgLAAgXIAAgJQAAgXAJgLQAGgHAJAAQAJAAAHAHQAIALAAAXIAAAJQAAAXgIALQgHAHgJAAQgJAAgGgHgAATgfQgFAHAAATIAAALQAAATAGAHQADAEAEAAQAFAAADgEQAGgHAAgTIAAgLQAAgTgGgHQgDgEgFAAQgEAAgEAEgAgyAuIAAgJQABgGAGgJIASgXQAIgJAAgLQAAgGgEgFQgCgDgEAAQgEAAgCADQgFAGAAANIgKAAQAAgQAHgJQAFgHAIAAQAKAAAGAHQAFAHAAAKQAAANgGAIIgNASIgHAJQgDAEgCAFIAhAAIAAAKg");
	this.shape_2.setTransform(-18.8,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F2F2F2").s().p("AidAnQgJgJAAgUIAMAAQAAAPAFAGQAEAEAIAAQAIAAADgEQAFgFAAgHIAAg+IAMAAIAAA/QAAAMgIAHQgGAHgNAAQgOAAgHgHgACbAtIAAhEIgXBEIgIAAIgYhEIAABEIgMAAIAAhYIAQAAIAXBEIAYhEIAQAAIAABYgABBAtIgLgbIgiAAIgKAbIgLAAIAihaIAKAAIAjBagAAYAIIAbAAIgOgjgAgYAtIAAhEIgXBEIgIAAIgYhEIAABEIgMAAIAAhYIAQAAIAXBEIAYhEIAQAAIAABYg");
	this.shape_3.setTransform(16.8,0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F2F2F2").s().p("AglAmQgQgQAAgWQAAgVAQgQQAQgPAVAAQAWAAAQAPQAQAQAAAVQAAAWgQAQQgQAQgWAAQgVAAgQgQgAgegfQgNAOAAARQAAATANAMQANAOARAAQATAAANgOQANgMAAgTQAAgRgNgOQgNgNgTABQgRgBgNANgAgOAdQgHgFgDgHQgDgIAAgJQAAgJAEgIIALgMIAOgDQAKAAAGAFQAHAFACAIIAAABIAAAAIgJACIgGgKIgKgDIgLADIgHAJIgCAMIADANQACAFAFAEQAEADAFAAQAHAAAFgEQAEgEACgHIAAgBIABAAIAIADQgCAKgHAGQgGAFgLAAQgKAAgGgEg");
	this.shape_4.setTransform(-31.4,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},7).to({state:[]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-5.1,70.3,10.7);


(lib.copyright10baseB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgJAtIAUhPIgfAAIAAgKIApAAIAAALIgVBOg");
	this.shape.setTransform(-4.8,0.1);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(7).to({_off:false},0).to({_off:true},1).wait(2));

	// レイヤー 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AABAuIAAhGIgLAAIAAgGIADAAQAGAAADgFQAEgEABgGIAEAAIAABbg");
	this.shape_1.setTransform(-10.8,0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAMAnQgJgLAAgXIAAgJQAAgXAJgLQAGgHAJAAQAJAAAHAHQAIALAAAXIAAAJQAAAXgIALQgHAHgJAAQgJAAgGgHgAATgfQgFAHAAATIAAALQAAATAGAHQADAEAEAAQAFAAADgEQAGgHAAgTIAAgLQAAgTgGgHQgDgEgFAAQgEAAgEAEgAgyAuIAAgJQABgGAGgJIASgXQAIgJAAgLQAAgGgEgFQgCgDgEAAQgEAAgCADQgFAGAAANIgKAAQAAgQAHgJQAFgHAIAAQAKAAAGAHQAFAHAAAKQAAANgGAIIgNASIgHAJQgDAEgCAFIAhAAIAAAKg");
	this.shape_2.setTransform(-18.8,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AidAnQgJgJAAgUIAMAAQAAAPAFAGQAEAEAIAAQAIAAADgEQAFgFAAgHIAAg+IAMAAIAAA/QAAAMgIAHQgGAHgNAAQgOAAgHgHgACbAtIAAhEIgXBEIgIAAIgYhEIAABEIgMAAIAAhYIAQAAIAXBEIAYhEIAQAAIAABYgABBAtIgLgbIgiAAIgKAbIgLAAIAihaIAKAAIAjBagAAYAIIAbAAIgOgjgAgYAtIAAhEIgXBEIgIAAIgYhEIAABEIgMAAIAAhYIAQAAIAXBEIAYhEIAQAAIAABYg");
	this.shape_3.setTransform(16.8,0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AglAmQgQgQAAgWQAAgVAQgQQAQgPAVAAQAWAAAQAPQAQAQAAAVQAAAWgQAQQgQAQgWAAQgVAAgQgQgAgegfQgNAOAAARQAAATANAMQANAOARAAQATAAANgOQANgMAAgTQAAgRgNgOQgNgNgTABQgRgBgNANgAgOAdQgHgFgDgHQgDgIAAgJQAAgJAEgIIALgMIAOgDQAKAAAGAFQAHAFACAIIAAABIAAAAIgJACIgGgKIgKgDIgLADIgHAJIgCAMIADANQACAFAFAEQAEADAFAAQAHAAAFgEQAEgEACgHIAAgBIABAAIAIADQgCAKgHAGQgGAFgLAAQgKAAgGgEg");
	this.shape_4.setTransform(-31.4,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]},7).to({state:[]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-5.1,70.3,10.7);


(lib.b_menu_part01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#99A3AD").ss(1,1,1).p("AHzg7IAABZIAAAeQAAAsgrAAIuPAAQgrAAAAgsIAAh3QgBgWALgLQAMgLAVAAIOPAAQAWAAALALQAKALAAAWg");
	this.shape.setTransform(0,3.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#ADADAD","#ADB7C1","#9AA4AE","#66707A","#8F99A3"],[0,0,0.459,0.494,1],0,-10.8,0,10.8).s().p("AnHBoQgrAAAAgsIAAh3QgBgWALgLQAMgLAVAAIOPAAQAWAAALALQAKALAAAWIAABZIAAAeQAAAsgrAAg");
	this.shape_1.setTransform(0,3.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#DF9999").ss(1,1,1).p("AHzg7IAABZIAAAeQAAAsgrAAIuPAAQgrAAAAgsIAAh3QgBgWALgLQAMgLAVAAIOPAAQAWAAALALQAKALAAAWg");
	this.shape_2.setTransform(0,3.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#F3ADAD","#E09A9A","#AC6666","#D58F8F"],[0,0.459,0.494,1],0,-10.8,0,10.8).s().p("AnHBoQgrAAAAgsIAAh3QgBgWALgLQAMgLAVAAIOPAAQAWAAALALQAKALAAAWIAABZIAAAeQAAAsgrAAg");
	this.shape_3.setTransform(0,3.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.9,-7.7,101.9,22.8);


(lib.制御判定btmc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		exportRoot.jtLabelN = "label_4";
		Next();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(28).call(this.frame_29).wait(1));

	// レイヤー 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AAygxIAABjIhjAAIAAhjg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgxAyIAAhjIBjAAIAABjg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-6,12,12);


(lib.jimakuOffBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{release:1,over:5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// マーク
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AjJCdIAAk5IGTAAIAAE5gAiRBQIDQAAIAAggIjQAAgAiRAPIEjAAIAAgfIkjAAgAiRgxIEjAAIAAggIkjAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.jimakuOnBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// マーク
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjJCdIAAk5IGTAAIAAE5gAiRBQIDQAAIAAggIjQAAgAiRAPIEjAAIAAgfIkjAAgAiRgxIEjAAIAAggIkjAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.vjv202選択600000 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.instance = new lib.vjv23t600000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(0.8,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// レイヤー 1
	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2));

	// レイヤー 3
	this.instance_2 = new lib.vjv202Q選択Box("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(2,-12,1.1,1.1);
	this.instance_2.alpha = 0.602;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).wait(1));

	// レイヤー 4
	this.instance_3 = new lib.vjv202Q選択Box("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(4,-22,1.1,1.1);
	this.instance_3.alpha = 0.398;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q3解答欄B1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		delete this.ft;
	}
	this.frame_1 = function() {
		if (this.ft == void(0)) {
			this.ft = true;
			//初期画面＝最終フレーム
			this.gotoAndStop(17);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(17));

	// レイヤー 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E80000").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00CC00").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},15).to({state:[]},1).wait(1));

	// レイヤー 4
	this.instance = new lib.vjv23t600000("single",0);
	this.instance.parent = this;

	this.instance_1 = new lib.vjv23t360000("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.vjv23t240000("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.vjv23t192000("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.vjv23t48000("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.vjv23t40000("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.vjv23t30000("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.vjv23t18000("synched",0);
	this.instance_7.parent = this;

	this.instance_8 = new lib.vjv23t650000("single",0);
	this.instance_8.parent = this;

	this.instance_9 = new lib.vjv23t520000("synched",0);
	this.instance_9.parent = this;

	this.instance_10 = new lib.vjv23t130000("synched",0);
	this.instance_10.parent = this;

	this.instance_11 = new lib.vjv23t110500("synched",0);
	this.instance_11.parent = this;

	this.instance_12 = new lib.vjv23t19500("synched",0);
	this.instance_12.parent = this;

	this.instance_13 = new lib.vjv23t17000("synched",0);
	this.instance_13.parent = this;

	this.instance_14 = new lib.vjv23t16000("synched",0);
	this.instance_14.parent = this;

	this.instance_15 = new lib.vjv23t6500("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-4.3,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AhDBFIAAgLIAYAAIAAgtQgJAIgMAFIgHgMQAigOAJgcIglAAIAAgMIAoAAQgCgIgJgMIALgGQAKALAFAPIASAAQAIgMAFgQIAOAFQADADgFAAQgHAPgEAFIArAAIAAAMIgmAAQAOAdAeALIgHANQgRgIgDgGIAAAvIAXAAIAAALgAARA6IAQAAIAAgnIgQAAgAgHA6IAOAAIAAgnIgOAAgAghA6IAPAAIAAgnIgPAAgAglAHIBLAAQgRgRgGgSIgfAAQgFAXgQAMg");
	this.shape_2.setTransform(32.1,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgeBEIAAg8QgLASgSAOIgHgMQAZgUAJgaIgeAAIAAgMIAgAAIAAgVIgbACIgDgLQAjgCAagFIAGAKQABAFgEgCIgWACIAAAWIAhAAIAAAMIghAAIAAAOQASAHAMANIgJAMQgIgKgNgJIAAA7gAApBDIgCgMIAMAAQABAAAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAIAAh3IAMAAQAFACgFADIAAB2QAAAKgKAAgAAVAlIAAhXIAMAAQAFABgEADIAABTg");
	this.shape_3.setTransform(15.8,0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgrBJIAAhDIgWAEQgBAEgCgCIgDgOIANAAIALgNQgJgLgNgJIAHgKIAGAFIAVggIAJAGQADACgEAAIgVAeIAIAJIASgZIAKAFQAAABABABQAAAAAAAAQAAABgBAAQAAAAgBAAIggAoIAYgCIgGgMIAJgEQAHALAEAOIgIAFIgDgHIgNACIAABEgAAjBDQgLgBAAgLIAAgbIgNAAIAAANIgMAAIAAhAIALAAQAFABgEACIAAAlIANAAIAAg0IgfAEIgCgLIAhgFIAAgXIAKAAQAHAAgGADIAAASIAdgGIAGANQABADgGgDIgeAFIAAA2IAQAAIAAguIAMAAQAFABgEADIAAA1IgdAAIAAAYQAAAFAEAAIAOAAQAGgBACgOIALAFQgDATgMABgAhGA3QAHgUABgQIANADQACADgEAAQgBASgHARgAgWAWIALgCQAEALAAARIgLACQgBgRgDgLg");
	this.shape_4.setTransform(0.1,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgGA9QAbgRAAgcIAAhRIAvAAIAAB8QAAAKgKAAIgNAAIgCgNIAKAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgjIgWAAQgBAggeAVgAAhAGIAWAAIAAgWIgWAAgAAhgcIAWAAIAAgYIgWAAgAhBA6QAOgLALgSIALAHQAEADgGAAQgKARgNANgAgVAmIAKgJQALAIAGAIIgJAKQgIgJgKgIgAhDAaIAAgKIAUAAIAAg4IgQAAIAAgKIAQAAIAAgUIAKAAQAGAAgFADIAAARIAZAAIAAgUIAKAAQAFAAgFADIAAARIAPAAIAAAKIgPAAIAAA4IARAAIAAAKgAgkAQIAZAAIAAgNIgZAAgAgkgGIAZAAIAAgMIgZAAgAgkgcIAZAAIAAgMIgZAAg");
	this.shape_5.setTransform(-16.3,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AAuBDIAAgHIhoAAIAAgMIBoAAIAAgVIhgAAIAAgMIBgAAIAAgTIhoAAIAAgLIAzAAIAAgzIANAAQAGABgFAEIAAAuIA0AAIAABSgAAWgbQAKgPAGgSIAOAGQAFADgHABQgEANgLARgAg0gxIAMgIQAKAKAIARIgNAIQgJgRgIgKg");
	this.shape_6.setTransform(-32,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

	// ベースボックス
	this.instance_16 = new lib.vis202解答欄("single",1);
	this.instance_16.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(17).to({startPosition:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-13,106,26);


(lib.vjv202q3解答欄A1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		delete this.ft;
	}
	this.frame_1 = function() {
		if (this.ft == void(0)) {
			this.ft = true;
			//初期画面＝最終フレーム
			this.gotoAndStop(17);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(17));

	// レイヤー 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E80000").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00CC00").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[{t:this.shape}]},1).to({state:[]},8).wait(1));

	// レイヤー 4
	this.instance = new lib.vjv23t600000("single",0);
	this.instance.parent = this;

	this.instance_1 = new lib.vjv23t360000("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.vjv23t240000("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.vjv23t192000("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.vjv23t48000("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.vjv23t40000("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.vjv23t30000("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.vjv23t18000("synched",0);
	this.instance_7.parent = this;

	this.instance_8 = new lib.vjv23t650000("single",0);
	this.instance_8.parent = this;

	this.instance_9 = new lib.vjv23t520000("synched",0);
	this.instance_9.parent = this;

	this.instance_10 = new lib.vjv23t130000("synched",0);
	this.instance_10.parent = this;

	this.instance_11 = new lib.vjv23t110500("synched",0);
	this.instance_11.parent = this;

	this.instance_12 = new lib.vjv23t19500("synched",0);
	this.instance_12.parent = this;

	this.instance_13 = new lib.vjv23t17000("synched",0);
	this.instance_13.parent = this;

	this.instance_14 = new lib.vjv23t16000("synched",0);
	this.instance_14.parent = this;

	this.instance_15 = new lib.vjv23t6500("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-4.3,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("AhDBFIAAgLIAYAAIAAgtQgJAIgMAFIgHgMQAigOAJgcIglAAIAAgMIAoAAQgCgIgJgMIALgGQAKALAFAPIASAAQAIgMAFgQIAOAFQADADgFAAQgHAPgEAFIArAAIAAAMIgmAAQAOAdAeALIgHANQgRgIgDgGIAAAvIAXAAIAAALgAARA6IAQAAIAAgnIgQAAgAgHA6IAOAAIAAgnIgOAAgAghA6IAPAAIAAgnIgPAAgAglAHIBLAAQgRgRgGgSIgfAAQgFAXgQAMg");
	this.shape_2.setTransform(32.1,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AgeBEIAAg8QgLASgSAOIgHgMQAZgUAJgaIgeAAIAAgMIAgAAIAAgVIgbACIgDgLQAjgCAagFIAGAKQABAFgEgCIgWACIAAAWIAhAAIAAAMIghAAIAAAOQASAHAMANIgJAMQgIgKgNgJIAAA7gAApBDIgCgMIAMAAQABAAAAAAQAAAAAAgBQAAAAABAAQAAgBAAAAIAAh3IAMAAQAFACgFADIAAB2QAAAKgKAAgAAVAlIAAhXIAMAAQAFABgEADIAABTg");
	this.shape_3.setTransform(15.8,0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AgrBJIAAhDIgWAEQgBAEgCgCIgDgOIANAAIALgNQgJgLgNgJIAHgKIAGAFIAVggIAJAGQADACgEAAIgVAeIAIAJIASgZIAKAFQAAABABABQAAAAAAAAQAAABgBAAQAAAAgBAAIggAoIAYgCIgGgMIAJgEQAHALAEAOIgIAFIgDgHIgNACIAABEgAAjBDQgLgBAAgLIAAgbIgNAAIAAANIgMAAIAAhAIALAAQAFABgEACIAAAlIANAAIAAg0IgfAEIgCgLIAhgFIAAgXIAKAAQAHAAgGADIAAASIAdgGIAGANQABADgGgDIgeAFIAAA2IAQAAIAAguIAMAAQAFABgEADIAAA1IgdAAIAAAYQAAAFAEAAIAOAAQAGgBACgOIALAFQgDATgMABgAhGA3QAHgUABgQIANADQACADgEAAQgBASgHARgAgWAWIALgCQAEALAAARIgLACQgBgRgDgLg");
	this.shape_4.setTransform(0.1,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CCCCCC").s().p("AgGA9QAbgRAAgcIAAhRIAvAAIAAB8QAAAKgKAAIgNAAIgCgNIAKAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgjIgWAAQgBAggeAVgAAhAGIAWAAIAAgWIgWAAgAAhgcIAWAAIAAgYIgWAAgAhBA6QAOgLALgSIALAHQAEADgGAAQgKARgNANgAgVAmIAKgJQALAIAGAIIgJAKQgIgJgKgIgAhDAaIAAgKIAUAAIAAg4IgQAAIAAgKIAQAAIAAgUIAKAAQAGAAgFADIAAARIAZAAIAAgUIAKAAQAFAAgFADIAAARIAPAAIAAAKIgPAAIAAA4IARAAIAAAKgAgkAQIAZAAIAAgNIgZAAgAgkgGIAZAAIAAgMIgZAAgAgkgcIAZAAIAAgMIgZAAg");
	this.shape_5.setTransform(-16.3,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AAuBDIAAgHIhoAAIAAgMIBoAAIAAgVIhgAAIAAgMIBgAAIAAgTIhoAAIAAgLIAzAAIAAgzIANAAQAGABgFAEIAAAuIA0AAIAABSgAAWgbQAKgPAGgSIAOAGQAFADgHABQgEANgLARgAg0gxIAMgIQAKAKAIARIgNAIQgJgRgIgKg");
	this.shape_6.setTransform(-32,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

	// ベースボックス
	this.instance_16 = new lib.vis202解答欄("single",1);
	this.instance_16.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(17).to({startPosition:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-13,106,26);


(lib.vjv202q1解答欄B2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		delete this.ft;
	}
	this.frame_1 = function() {
		if (this.ft == void(0)) {
			this.ft = true;
			//初期画面＝最終フレーム
			this.gotoAndStop(17);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(17));

	// レイヤー 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E80000").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00CC00").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},8).to({state:[{t:this.shape}]},1).to({state:[]},7).wait(1));

	// レイヤー 4
	this.instance = new lib.vjv23t600000("single",0);
	this.instance.parent = this;

	this.instance_1 = new lib.vjv23t360000("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.vjv23t240000("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.vjv23t192000("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.vjv23t48000("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.vjv23t40000("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.vjv23t30000("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.vjv23t18000("synched",0);
	this.instance_7.parent = this;

	this.instance_8 = new lib.vjv23t650000("single",0);
	this.instance_8.parent = this;

	this.instance_9 = new lib.vjv23t520000("synched",0);
	this.instance_9.parent = this;

	this.instance_10 = new lib.vjv23t130000("synched",0);
	this.instance_10.parent = this;

	this.instance_11 = new lib.vjv23t110500("synched",0);
	this.instance_11.parent = this;

	this.instance_12 = new lib.vjv23t19500("synched",0);
	this.instance_12.parent = this;

	this.instance_13 = new lib.vjv23t17000("synched",0);
	this.instance_13.parent = this;

	this.instance_14 = new lib.vjv23t16000("synched",0);
	this.instance_14.parent = this;

	this.instance_15 = new lib.vjv23t6500("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-4.3,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ag9BIIAAhEIB7AAIAAA5QAAAJgKABIgMAAIgCgNIAJAAQABAAAAAAQABAAAAAAQAAAAABgBQAAAAAAgBIAAgoIhiAAIAAA4gAgfA/IAAgnIA/AAIAAAfIg0AAIAAAIgAgUAuIApAAIAAgMIgpAAgAgngEIAAggIBQAAIAAAggAgdgOIA7AAIAAgMIg7AAgAhFgsIAAgMIA/AAIAAgPIAMAAQAHAAgGAEIAAALIA/AAIAAAMg");
	this.shape_2.setTransform(15.9,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AhDA+IAAgOIA5AAIAAhtIAMAAQAGABgFAEIAAAkIAzAAIAAAOIgzAAIAAA2IBBAAIAAAOg");
	this.shape_3.setTransform(-0.1,-0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AhEA6QApgDAAgcIAAgSIANAAQAGABgGADIAAAOQAAAmgzAHgAAVBFQgMAAAAgLIAAgxIANAAQAGABgGADIAAAoQAAAEAEAAIAYAAQAGAAABgPIAMAFQgCAWgMAAgAAyATIAAgRIhmAAIAAARIgOAAIAAgbICCAAIAAAbgAg2gSIAAgNIAuAAIAAgMIg5AAIAAgMIA5AAIAAgPIANAAQAHAAgGAEIAAALIA6AAIAAAMIg6AAIAAAMIAuAAIAAANg");
	this.shape_4.setTransform(-15.9,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

	// ベースボックス
	this.instance_16 = new lib.vis202解答欄("single",1);
	this.instance_16.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(17).to({mode:"synched",startPosition:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-13,106,26);


(lib.vjv202q1解答欄A2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		delete this.ft;
	}
	this.frame_1 = function() {
		if (this.ft == void(0)) {
			this.ft = true;
			//初期画面＝最終フレーム
			this.gotoAndStop(17);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(17));

	// レイヤー 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00CC00").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#E80000").ss(2,1,1).p("AIIg7QAAg8g8AAIuXAAQg8AAAAA8IAAB3QAAA8A8AAIOXAAQA8AAAAg8g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[]},15).wait(1));

	// レイヤー 4
	this.instance = new lib.vjv23t600000("single",0);
	this.instance.parent = this;

	this.instance_1 = new lib.vjv23t360000("synched",0);
	this.instance_1.parent = this;

	this.instance_2 = new lib.vjv23t240000("synched",0);
	this.instance_2.parent = this;

	this.instance_3 = new lib.vjv23t192000("synched",0);
	this.instance_3.parent = this;

	this.instance_4 = new lib.vjv23t48000("synched",0);
	this.instance_4.parent = this;

	this.instance_5 = new lib.vjv23t40000("synched",0);
	this.instance_5.parent = this;

	this.instance_6 = new lib.vjv23t30000("synched",0);
	this.instance_6.parent = this;

	this.instance_7 = new lib.vjv23t18000("synched",0);
	this.instance_7.parent = this;

	this.instance_8 = new lib.vjv23t650000("single",0);
	this.instance_8.parent = this;

	this.instance_9 = new lib.vjv23t520000("synched",0);
	this.instance_9.parent = this;

	this.instance_10 = new lib.vjv23t130000("synched",0);
	this.instance_10.parent = this;

	this.instance_11 = new lib.vjv23t110500("synched",0);
	this.instance_11.parent = this;

	this.instance_12 = new lib.vjv23t19500("synched",0);
	this.instance_12.parent = this;

	this.instance_13 = new lib.vjv23t17000("synched",0);
	this.instance_13.parent = this;

	this.instance_14 = new lib.vjv23t16000("synched",0);
	this.instance_14.parent = this;

	this.instance_15 = new lib.vjv23t6500("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-4.3,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#CCCCCC").s().p("Ag9BIIAAhEIB7AAIAAA5QAAAJgKABIgMAAIgCgNIAJAAQABAAAAAAQABAAAAAAQAAAAABgBQAAAAAAgBIAAgoIhiAAIAAA4gAgfA/IAAgnIA/AAIAAAfIg0AAIAAAIgAgUAuIApAAIAAgMIgpAAgAgngEIAAggIBQAAIAAAggAgdgOIA7AAIAAgMIg7AAgAhFgsIAAgMIA/AAIAAgPIAMAAQAHAAgGAEIAAALIA/AAIAAAMg");
	this.shape_2.setTransform(15.9,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#CCCCCC").s().p("AhDA+IAAgOIA5AAIAAhtIAMAAQAGABgFAEIAAAkIAzAAIAAAOIgzAAIAAA2IBBAAIAAAOg");
	this.shape_3.setTransform(-0.1,-0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CCCCCC").s().p("AhEA6QApgDAAgcIAAgSIANAAQAGABgGADIAAAOQAAAmgzAHgAAVBFQgMAAAAgLIAAgxIANAAQAGABgGADIAAAoQAAAEAEAAIAYAAQAGAAABgPIAMAFQgCAWgMAAgAAyATIAAgRIhmAAIAAARIgOAAIAAgbICCAAIAAAbgAg2gSIAAgNIAuAAIAAgMIg5AAIAAgMIA5AAIAAgPIANAAQAHAAgGAEIAAALIA6AAIAAAMIg6AAIAAAMIAuAAIAAANg");
	this.shape_4.setTransform(-15.9,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},1).wait(1));

	// ベースボックス
	this.instance_16 = new lib.vis202解答欄("single",1);
	this.instance_16.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(17).to({mode:"synched",startPosition:0},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-13,106,26);


(lib.vjv202q3正解4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		if (kno == 4) {
			this.play();
		} else {
			this.stop();
		}
	}
	this.frame_15 = function() {
		exportRoot.mcLyoko.q1ans4.visible = false;
		exportRoot.mcLtate.q1ans4.visible = false;
		exportRoot.mcLyoko.q1ap4.visible = false;
		exportRoot.mcLtate.q1ap4.visible = false;
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(14).call(this.frame_15).wait(1));

	// レイヤー 4
	this.instance = new lib.vjv23t650000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(3.3,-104.5,1.1,1.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({scaleX:1,scaleY:1,x:-10,y:103.5},4).to({_off:true},3).wait(1));

	// レイヤー 1
	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(2.5,-104.5,1.1,1.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({x:-10.5,y:103.5},4).to({_off:true},3).wait(1));

	// レイヤー 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnfCMQg8AAAAg8IAAifQAAg8A8AAIO/AAQA8AAAAA8IAACfQAAA8g8AAg");
	this.shape.setTransform(-10,103.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(12).to({_off:false},0).to({_off:true},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.vjv202q3正解3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		if (kno == 3) {
			this.play();
		} else {
			this.stop();
		}
	}
	this.frame_15 = function() {
		exportRoot.mcLyoko.q1ans3.visible = false;
		exportRoot.mcLtate.q1ans3.visible = false;
		exportRoot.mcLyoko.q1ap3.visible = false;
		exportRoot.mcLtate.q1ap3.visible = false;
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(14).call(this.frame_15).wait(1));

	// レイヤー 3
	this.instance = new lib.vjv23t6500("single",0);
	this.instance.parent = this;
	this.instance.setTransform(8.1,32.5,1.1,1.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({scaleX:1,scaleY:1,x:-13.8,y:66.5,mode:"synched"},4).to({_off:true},3).wait(1));

	// レイヤー 1
	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(2.5,32.5,1.1,1.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({x:-9.5,y:66.5},4).to({_off:true},3).wait(1));

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnfCMQg8AAAAg8IAAifQAAg8A8AAIO/AAQA8AAAAA8IAACfQAAA8g8AAg");
	this.shape.setTransform(-10,66.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(12).to({_off:false},0).to({_off:true},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.vjv202q3正解2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		if (kno == 2) {
			this.play();
		} else {
			this.stop();
		}
	}
	this.frame_15 = function() {
		exportRoot.mcLyoko.q1ans2.visible = false;
		exportRoot.mcLtate.q1ans2.visible = false;
		exportRoot.mcLyoko.q1ap2.visible = false;
		exportRoot.mcLtate.q1ap2.visible = false;
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(14).call(this.frame_15).wait(1));

	// レイヤー 3
	this.instance = new lib.vjv23t600000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(7.3,-104.5,1.1,1.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({scaleX:1,scaleY:1,x:-10,y:103.5},4).to({_off:true},3).wait(1));

	// レイヤー 1
	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(6.5,-104.5,1.1,1.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({x:-10.5,y:103.5},4).to({_off:true},3).wait(1));

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnfCMQg8AAAAg8IAAifQAAg8A8AAIO/AAQA8AAAAA8IAACfQAAA8g8AAg");
	this.shape.setTransform(-10,103.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(12).to({_off:false},0).to({_off:true},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.vjv202q3正解1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		if (kno == 1) {
			this.play();
		} else {
			this.stop();
		}
	}
	this.frame_15 = function() {
		exportRoot.mcLyoko.q1ans1.visible = false;
		exportRoot.mcLtate.q1ans1.visible = false;
		exportRoot.mcLyoko.q1ap1.visible = false;
		exportRoot.mcLtate.q1ap1.visible = false;
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(14).call(this.frame_15).wait(1));

	// レイヤー 2
	this.instance = new lib.vjv23t18000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(12.1,32.5,1.1,1.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({scaleX:1,scaleY:1,x:-10,y:66.5,mode:"synched"},4).to({_off:true},3).wait(1));

	// レイヤー 1
	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(6.5,32.5,1.1,1.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(2).to({_off:false},0).to({_off:true},2).wait(2).to({_off:false},0).wait(2).to({startPosition:0},0).to({x:-10.5,y:65.5},4).to({_off:true},3).wait(1));

	// レイヤー 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AnzCgQg8AAAAg8IAAjHQAAg8A8AAIPnAAQA8AAAAA8IAADHQAAA8g8AAg");
	this.shape.setTransform(-10,66.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(12).to({_off:false},0).to({_off:true},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.vjv202BT計算g = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AAdBcQgDgDgBgGIAAgVIg1AAIAAACQgDAHgGAGQgGAHgIAEQgLAEgMACQgFABgEgCQgDgCgBgFQgBgEACgEQADgEAGgBQAJgBAFgDQAGgDAEgDIAAgBIgfAAQgEAAgCgDQgCgCgBgFQABgDACgDQACgDAEAAIAkAAIAAgBIAAgJIgLAAQgOAAAAgOIAAg3QAAgNAOAAIASAAIgBgEIgCgEIgCgDIgBgCIgLAAIgCAEQgHAIgGAFQgEADgFAAQgEgBgDgDQgDgEABgEQABgEAEgEIAJgKIAIgOQACgFAFgCQADgBAEABQAFACABAEQABADgBAEIAoAAQADAAADADQACACAAAEQAAAEgCACQgCADgEAAIgPAAIABAEQACAFgCAEIAXAAQgDgEAAgEQABgFACgDQAEgFADgEIAFgMQACgFAEgCQADgCAGABQAEACACADQABAEgBAFIAxAAQADAAACADQADACAAAEQAAAEgDACQgCADgDAAIgRAAIABADQACAFgCAEIgBABQAIADAAAKIAAA3QAAAOgOAAIgLAAIAAAKIAkAAQAEAAADADQACACABAEQgBAEgCADQgDADgEAAIgkAAIAAAVQAAAFgDAEQgDADgFAAQgFAAgDgDgAgZAqIAAABIAyAAIAAgKIgyAAgAgyAPQAAAEAEAAIBcAAQAFAAgBgEIAAgGIhkAAgAgygDIBkAAIAAgKIhkAAgAgygfIAAAEIBkAAIAAgEQABgFgFAAIhcAAQgEAAAAAFgAAPgyIAAABIAhAAIgBgEIgCgEIgCgEIgBgBIgSAAQgEAIgFAEg");
	this.shape.setTransform(51.9,17);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AAiBcQgDgEAAgGIAAhSIgeAAQgEAAgDgEQgEgDAAgFQAAgEAEgEQADgDAEAAIAeAAIAAg7QAAgFADgDQADgEAFAAQAFAAADAEQAEADgBAFIAAA7IAcAAQAFAAADADQAEADAAAFQAAAFgEADQgCADgGABIgcAAIAABSQABAGgEAEQgDACgFAAQgFAAgDgCgAhIBaQgNAAAAgOIAAgkQAAgNANAAIArAAQAPAAAAANIAAAkQAAAOgPAAgAhAAyIAAAPQAAAFAFAAIASAAQAFAAgBgFIAAgPQABgDgFAAIgSAAQgFAAAAADgAhMATQgFAAgDgDQgCgDAAgFQAAgEACgDQADgCAFAAIA0AAQAEAAADACQADADAAAEQAAAFgDACQgDADgEABgAhMgJQgFAAgDgEQgCgCAAgEQAAgFACgDQADgDAFAAIA0AAQAEAAADADQADACAAAGQAAADgDADQgDAEgEAAgAhRgmQgFAAgDgDQgCgDgBgFQABgEACgDQADgDAFAAIA9AAQAFAAAEACQACAEAAAEQAAAEgCAEQgEADgFAAgAhMhDQgFAAgDgDQgCgCAAgFQAAgEACgDQADgCAFgBIA0AAQAEABADACQADACAAAFQAAAFgDACQgDADgEAAg");
	this.shape_1.setTransform(31.9,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).wait(3));

	// レイヤー 1
	this.instance = new lib.vjv_ボタンbasegr前("single",0);
	this.instance.parent = this;
	this.instance.setTransform(101.5,35);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-2.5,88.8,39);


(lib.vjv202BT計算明 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAdBcQgDgDgBgGIAAgVIg1AAIAAACQgDAHgGAGQgGAHgIAEQgLAEgMACQgFABgEgCQgDgCgBgFQgBgEACgEQADgEAGgBQAJgBAFgDQAGgDAEgDIAAgBIgfAAQgEAAgCgDQgCgCgBgFQABgDACgDQACgDAEAAIAkAAIAAgBIAAgJIgLAAQgOAAAAgOIAAg3QAAgNAOAAIASAAIgBgEIgCgEIgCgDIgBgCIgLAAIgCAEQgHAIgGAFQgEADgFAAQgEgBgDgDQgDgEABgEQABgEAEgEIAJgKIAIgOQACgFAFgCQADgBAEABQAFACABAEQABADgBAEIAoAAQADAAADADQACACAAAEQAAAEgCACQgCADgEAAIgPAAIABAEQACAFgCAEIAXAAQgDgEAAgEQABgFACgDQAEgFADgEIAFgMQACgFAEgCQADgCAGABQAEACACADQABAEgBAFIAxAAQADAAACADQADACAAAEQAAAEgDACQgCADgDAAIgRAAIABADQACAFgCAEIgBABQAIADAAAKIAAA3QAAAOgOAAIgLAAIAAAKIAkAAQAEAAADADQACACABAEQgBAEgCADQgDADgEAAIgkAAIAAAVQAAAFgDAEQgDADgFAAQgFAAgDgDgAgZAqIAAABIAyAAIAAgKIgyAAgAgyAPQAAAEAEAAIBcAAQAFAAgBgEIAAgGIhkAAgAgygDIBkAAIAAgKIhkAAgAgygfIAAAEIBkAAIAAgEQABgFgFAAIhcAAQgEAAAAAFgAAPgyIAAABIAhAAIgBgEIgCgEIgCgEIgBgBIgSAAQgEAIgFAEg");
	this.shape.setTransform(51.9,17);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAiBcQgDgEAAgGIAAhSIgeAAQgEAAgDgEQgEgDAAgFQAAgEAEgEQADgDAEAAIAeAAIAAg7QAAgFADgDQADgEAFAAQAFAAADAEQAEADgBAFIAAA7IAcAAQAFAAADADQAEADAAAFQAAAFgEADQgCADgGABIgcAAIAABSQABAGgEAEQgDACgFAAQgFAAgDgCgAhIBaQgNAAAAgOIAAgkQAAgNANAAIArAAQAPAAAAANIAAAkQAAAOgPAAgAhAAyIAAAPQAAAFAFAAIASAAQAFAAgBgFIAAgPQABgDgFAAIgSAAQgFAAAAADgAhMATQgFAAgDgDQgCgDAAgFQAAgEACgDQADgCAFAAIA0AAQAEAAADACQADADAAAEQAAAFgDACQgDADgEABgAhMgJQgFAAgDgEQgCgCAAgEQAAgFACgDQADgDAFAAIA0AAQAEAAADADQADACAAAGQAAADgDADQgDAEgEAAgAhRgmQgFAAgDgDQgCgDgBgFQABgEACgDQADgDAFAAIA9AAQAFAAAEACQACAEAAAEQAAAEgCAEQgEADgFAAgAhMhDQgFAAgDgDQgCgCAAgFQAAgEACgDQADgCAFgBIA0AAQAEABADACQADACAAAFQAAAFgDACQgDADgEAAg");
	this.shape_1.setTransform(31.9,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(4));

	// レイヤー 1
	this.instance = new lib.vjv_ボタンbasegr("single",1);
	this.instance.parent = this;
	this.instance.setTransform(101.5,35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({startPosition:2},0).wait(1).to({startPosition:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-2.5,88.8,39);


(lib.vjv202BT計算 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#990000").s().p("AAdBcQgDgDgBgGIAAgVIg1AAIAAACQgDAHgGAGQgGAHgIAEQgLAEgMACQgFABgEgCQgDgCgBgFQgBgEACgEQADgEAGgBQAJgBAFgDQAGgDAEgDIAAgBIgfAAQgEAAgCgDQgCgCgBgFQABgDACgDQACgDAEAAIAkAAIAAgBIAAgJIgLAAQgOAAAAgOIAAg3QAAgNAOAAIASAAIgBgEIgCgEIgCgDIgBgCIgLAAIgCAEQgHAIgGAFQgEADgFAAQgEgBgDgDQgDgEABgEQABgEAEgEIAJgKIAIgOQACgFAFgCQADgBAEABQAFACABAEQABADgBAEIAoAAQADAAADADQACACAAAEQAAAEgCACQgCADgEAAIgPAAIABAEQACAFgCAEIAXAAQgDgEAAgEQABgFACgDQAEgFADgEIAFgMQACgFAEgCQADgCAGABQAEACACADQABAEgBAFIAxAAQADAAACADQADACAAAEQAAAEgDACQgCADgDAAIgRAAIABADQACAFgCAEIgBABQAIADAAAKIAAA3QAAAOgOAAIgLAAIAAAKIAkAAQAEAAADADQACACABAEQgBAEgCADQgDADgEAAIgkAAIAAAVQAAAFgDAEQgDADgFAAQgFAAgDgDgAgZAqIAAABIAyAAIAAgKIgyAAgAgyAPQAAAEAEAAIBcAAQAFAAgBgEIAAgGIhkAAgAgygDIBkAAIAAgKIhkAAgAgygfIAAAEIBkAAIAAgEQABgFgFAAIhcAAQgEAAAAAFgAAPgyIAAABIAhAAIgBgEIgCgEIgCgEIgBgBIgSAAQgEAIgFAEg");
	this.shape.setTransform(51.9,17);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#990000").s().p("AAiBcQgDgEAAgGIAAhSIgeAAQgEAAgDgEQgEgDAAgFQAAgEAEgEQADgDAEAAIAeAAIAAg7QAAgFADgDQADgEAFAAQAFAAADAEQAEADgBAFIAAA7IAcAAQAFAAADADQAEADAAAFQAAAFgEADQgCADgGABIgcAAIAABSQABAGgEAEQgDACgFAAQgFAAgDgCgAhIBaQgNAAAAgOIAAgkQAAgNANAAIArAAQAPAAAAANIAAAkQAAAOgPAAgAhAAyIAAAPQAAAFAFAAIASAAQAFAAgBgFIAAgPQABgDgFAAIgSAAQgFAAAAADgAhMATQgFAAgDgDQgCgDAAgFQAAgEACgDQADgCAFAAIA0AAQAEAAADACQADADAAAEQAAAFgDACQgDADgEABgAhMgJQgFAAgDgEQgCgCAAgEQAAgFACgDQADgDAFAAIA0AAQAEAAADADQADACAAAGQAAADgDADQgDAEgEAAgAhRgmQgFAAgDgDQgCgDgBgFQABgEACgDQADgDAFAAIA9AAQAFAAAEACQACAEAAAEQAAAEgCAEQgEADgFAAgAhMhDQgFAAgDgDQgCgCAAgFQAAgEACgDQADgCAFgBIA0AAQAEABADACQADACAAAFQAAAFgDACQgDADgEAAg");
	this.shape_1.setTransform(31.9,17);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAdBcQgDgDgBgGIAAgVIg1AAIAAACQgDAHgGAGQgGAHgIAEQgLAEgMACQgFABgEgCQgDgCgBgFQgBgEACgEQADgEAGgBQAJgBAFgDQAGgDAEgDIAAgBIgfAAQgEAAgCgDQgCgCgBgFQABgDACgDQACgDAEAAIAkAAIAAgBIAAgJIgLAAQgOAAAAgOIAAg3QAAgNAOAAIASAAIgBgEIgCgEIgCgDIgBgCIgLAAIgCAEQgHAIgGAFQgEADgFAAQgEgBgDgDQgDgEABgEQABgEAEgEIAJgKIAIgOQACgFAFgCQADgBAEABQAFACABAEQABADgBAEIAoAAQADAAADADQACACAAAEQAAAEgCACQgCADgEAAIgPAAIABAEQACAFgCAEIAXAAQgDgEAAgEQABgFACgDQAEgFADgEIAFgMQACgFAEgCQADgCAGABQAEACACADQABAEgBAFIAxAAQADAAACADQADACAAAEQAAAEgDACQgCADgDAAIgRAAIABADQACAFgCAEIgBABQAIADAAAKIAAA3QAAAOgOAAIgLAAIAAAKIAkAAQAEAAADADQACACABAEQgBAEgCADQgDADgEAAIgkAAIAAAVQAAAFgDAEQgDADgFAAQgFAAgDgDgAgZAqIAAABIAyAAIAAgKIgyAAgAgyAPQAAAEAEAAIBcAAQAFAAgBgEIAAgGIhkAAgAgygDIBkAAIAAgKIhkAAgAgygfIAAAEIBkAAIAAgEQABgFgFAAIhcAAQgEAAAAAFgAAPgyIAAABIAhAAIgBgEIgCgEIgCgEIgBgBIgSAAQgEAIgFAEg");
	this.shape_2.setTransform(51.9,17);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAiBcQgDgEAAgGIAAhSIgeAAQgEAAgDgEQgEgDAAgFQAAgEAEgEQADgDAEAAIAeAAIAAg7QAAgFADgDQADgEAFAAQAFAAADAEQAEADgBAFIAAA7IAcAAQAFAAADADQAEADAAAFQAAAFgEADQgCADgGABIgcAAIAABSQABAGgEAEQgDACgFAAQgFAAgDgCgAhIBaQgNAAAAgOIAAgkQAAgNANAAIArAAQAPAAAAANIAAAkQAAAOgPAAgAhAAyIAAAPQAAAFAFAAIASAAQAFAAgBgFIAAgPQABgDgFAAIgSAAQgFAAAAADgAhMATQgFAAgDgDQgCgDAAgFQAAgEACgDQADgCAFAAIA0AAQAEAAADACQADADAAAEQAAAFgDACQgDADgEABgAhMgJQgFAAgDgEQgCgCAAgEQAAgFACgDQADgDAFAAIA0AAQAEAAADADQADACAAAGQAAADgDADQgDAEgEAAgAhRgmQgFAAgDgDQgCgDgBgFQABgEACgDQADgDAFAAIA9AAQAFAAAEACQACAEAAAEQAAAEgCAEQgEADgFAAgAhMhDQgFAAgDgDQgCgCAAgFQAAgEACgDQADgCAFgBIA0AAQAEABADACQADACAAAFQAAAFgDACQgDADgEAAg");
	this.shape_3.setTransform(31.9,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).wait(3));

	// レイヤー 1
	this.instance = new lib.vjv_ボタンbasegr("single",0);
	this.instance.parent = this;
	this.instance.setTransform(101.5,35);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-2.5,88.8,39);


(lib.vjv23表B要約損益計算書1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// vjv2-3t40,000
	this.instance = new lib.vjv23t6500("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(90.3,82.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},2).wait(15));

	// vjv2-3t70,000
	this.instance_1 = new lib.vjv23t16000("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(90.3,62.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},2).wait(15));

	// vjv2-3t80,000
	this.instance_2 = new lib.vjv23t17000("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(90.3,42.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(15));

	// vjv2-3t90,000
	this.instance_3 = new lib.vjv23t19500("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(90.3,22.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},2).wait(15));

	// vjv2-3t150,000
	this.instance_4 = new lib.vjv23t110500("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(88.4,2.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},2).wait(15));

	// vjv2-3t240,000
	this.instance_5 = new lib.vjv23t130000("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(86,-17.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},2).wait(15));

	// vjv2-3t360,000
	this.instance_6 = new lib.vjv23t520000("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(88.4,-37.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},2).wait(15));

	// vjv2-3t600,000
	this.instance_7 = new lib.vjv23t650000("single",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(86,-57.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({_off:true},2).wait(15));

	// vjv2-3t当期純利益
	this.instance_8 = new lib.vjv23t当期純利益("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-69.9,81.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true},2).wait(15));

	// vjv2-3t税引前当期純利益
	this.instance_9 = new lib.vjv23t税引前当期純利益("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-50.9,61.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true},2).wait(15));

	// vjv2-3t経常利益
	this.instance_10 = new lib.vjv23t経常利益("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(-74.9,41.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:true},2).wait(15));

	// vjv2-3t営業利益
	this.instance_11 = new lib.vjv23t営業利益("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(-74.9,21.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({_off:true},2).wait(15));

	// vjv2-3t販売費及び一般管理費
	this.instance_12 = new lib.vjv23t販売費及び一般管理費("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(-26.2,1.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true},2).wait(15));

	// vjv2-3t売上総利益
	this.instance_13 = new lib.vjv23t売上総利益("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(-69.9,-18.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({_off:true},2).wait(15));

	// vjv2-3t売上原価
	this.instance_14 = new lib.vjv23t売上原価("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(-70.9,-38.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true},2).wait(15));

	// vjv2-3t売上高2
	this.instance_15 = new lib.vjv23t売上高2("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-84.9,-58.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({_off:true},2).wait(15));

	// vjv2-3t（単位：千円）
	this.instance_16 = new lib.vjv23t単位千円("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(84,-76.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({_off:true},2).wait(15));

	// vjv2-3t要約損益計算書
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F00B3").s().p("AAgBOIAAgGIhAAAIAAAGIgXAAIAAg1IBvAAIAAA1gAggA6IBAAAIAAgEIhAAAgAggArIBAAAIAAgEIhAAAgAhMAVIAAgQIBAAAIAAgEIgyAAIAAgLIAyAAIAAgDIgvAAIAAgPIAvAAIAAgFIhAAAIAAgQIBAAAIAAgEIgvAAIAAgQIAvAAIAAgIIAYAAIAAAIIAwAAIAAAUIARAAIAAAQIgRAAIAAAUIgwAAIAAADIAzAAIAAALIgzAAIAAAEIBAAAIAAAQgAAMgcIAYAAIAAgFIgYAAgAAMgxIAYAAIAAgEIgYAAg");
	this.shape.setTransform(72.2,-92.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F00B3").s().p("AhEA7QAXgEAFgHIgiAAIAAgSIAtAAIABgFIgcAAIAAg+QgEAFgFACIgMgVQAUgKAIgRIAZADIgDAFIAdAAIAAAJQAJgHADgKIAYAEIgCAEIAoAAIAAASIgWAAIADALIgYAAIgDgLIgEAAQgFAGgKAHIAwAAIAABAIgVAAIAAAFIAnAAIAAASIgnAAIAAAdIgXAAIAAgdIgYAAQgHANgKAHQgPAJgOACgAgDAeIASAAIAAgFIgRAAgAggAJIBEAAIAAgDIhEAAgAgggGIBEAAIAAgDIhEAAgAgggVIBEAAIAAgDIhEAAgAAFgnIgKgNIgJAAIACALIgWAAIgCgLIgDAAQgFAHgJAGIA6AAg");
	this.shape_1.setTransform(55.1,-92.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F00B3").s().p("AAWBNIAAhUIgfAAIAAgVIAfAAIAAgwIAXAAIAAAwIAgAAIAAAVIggAAIAABUgAhIBJIAAgzIA8AAIAAArIgkAAIAAAIgAgwAwIAOAAIAAgJIgOAAgAhFAQIAAgQIA4AAIAAAQgAhFgFIAAgRIA4AAIAAARgAhMgcIAAgSIBBAAIAAASgAhFg0IAAgSIA3AAIAAASg");
	this.shape_2.setTransform(38.2,-92.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F00B3").s().p("AhKBLIAAgVIATAAIAAgjQgFAFgIAFIgKgaQAYgKANgSIgiAAIAAgVIAmAAQgEgLgIgHIAWgKQAJAIAHAQIgKAEIAbAAIAPgcIAXAGIgKAWIArAAIAAAVIgiAAQAEAHALAJQAKAJALAEIgMAYIgLgIIAAAiIASAAIAAAVgAAZA2IAIAAIAAgeIgIAAgAgCA2IAHAAIAAgeIgHAAgAgfA2IAHAAIAAgeIgHAAgAgkADIBJAAQgIgFgPgXIgbAAQgMAWgLAGg");
	this.shape_3.setTransform(21.2,-93);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F00B3").s().p("AgiA4QAGAAAIgCQAJgCACgBIgMAAIAAhPIBaAAIAABPIgPAAQAMAFAMABIgJAVQgIgBgNgFQgMgFgIgFIAKgLIgdAAIAKALQgHAGgMAEQgOAGgKABgAACAiIAsAAIAAgGIgsAAgAACAOIAsAAIAAgGIgsAAgAACgGIAsAAIAAgFIgsAAgAhDBMIgHgXIAJAAQAFAAAAgHIAAgZIgMAFIgFgYIARgDIAAgZIgQAAIAAgUIAQAAIAAggIAXAAIAAAgIAMAAIAAAUIgMAAIAAASIAIgDIAGATIgOAGIAAAvQAAAPgNAAgAgRggIAAgoIBRAAIAAAogAAFgyIAlAAIAAgFIglAAg");
	this.shape_4.setTransform(4.3,-92.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F00B3").s().p("AguBOIAAg/IgbABIgCgWIASAAIAFgGIgXgYIAKgTIAHAHIAOgbIAUAIIgSAhIACAEIARgaIATAKIgTAfIAQgFQAKAYACAJIgJADQAFASACAWIgUADQAAgTgEgUIAHgBIgBgHIgIABIAABBgAgdgHIAHgBIgCgFgAAaBNIgHgXIAWAAQAHAAAAgKIACgXIACgdIAAgVIgfAAIgGALQgEAGgDACIgSgPQAWgaAGgaIAWAGQgCAIgGAMIAsAAIgBAcIgBAuIgCAbQgCAQgEAFQgEAGgMAAgAhJBBQAGgTAAgaIASACQAAAggDAQgAASANQgFgMgDgEIAUgJIAIAQQAGAPABAFIgVAHQAAgGgGgMg");
	this.shape_5.setTransform(-12.9,-92.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F00B3").s().p("AhGA1QAlABAQgGIgMgDIgEADIgUgKQAMgKABgFIgjAAIAAgWIAzAAIADgEIgoAAIAAgtIAhAAIAAgGIguAAIAAgVICWAAIAAAVIgvAAIAAAGIAhAAIAAAtIg4AAIgEAEIBKAAIAAAVIgbAAIgGALQgEAGgCACQASAFAPAHIgNAWQgFgDgOgGIgUgIQgOAJgTAEQgWAFgXAAgAgOAcIAYAFQACgBACgDIAFgGIgcAAgAAdgWIAJAAIAAgHIgJAAgAgFgWIALAAIAAgHIgLAAgAglgWIAJAAIAAgHIgJAAgAgFgwIALAAIAAgGIgLAAg");
	this.shape_6.setTransform(-29.8,-92.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F00B3").s().p("AAFAtQAZgJAJgMQAQgYgKgWQgKgWgaAAQAABEgcAaQgMAKgNgFQgNgFgHgOQgNgbANgdQAMgcAdgMQAUgIATADQAVACAPAOQARAQACAYQACAZgOAUQgOAUgcAKgAguABQgBAJADAKQAEALAHgDQAIgEAGgSQAGgRAAgeQgeALgDAfg");
	this.shape_7.setTransform(-46.2,-92.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2F00B3").s().p("AgzBOIAAgvQgGAIgKAIIgKgXQAMgJAOgPQANgOAHgOIgsAAIAAgVIAYAAIAAgcIAXAAIAAAcIAIAAIAAgBIASANIgHAPQgFAKgHAJQAFAGARAKIgKAYIgSgSIAAA7gAgQBIIAAgVIAlAAIAAg6IgaAAIAAgVIAaAAIAAgwIAXAAIAAAwIAcAAIAAAVIgcAAIAAA6IAiAAIAAAVg");
	this.shape_8.setTransform(-62.7,-92.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2F00B3").s().p("Ag1BEIAAiIIA+AAQARAAAKAIQALAIACAMQACALgHAKQgFALgMAEQAOAEAHAMQAHAMgCANQgCANgKAJQgMAKgSgBgAgcAuIAmAAQAIABAFgHQAEgFAAgHQgBgJgEgFQgFgGgIAAIglAAgAgcgOIAgAAQAKABAFgGQAGgEAAgHQAAgGgHgGQgFgEgJAAIggAAg");
	this.shape_9.setTransform(-77.2,-92.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},2).to({state:[]},8).wait(7));

	// 外枠
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("ASXMgMgktAAAIAA4/MAktAAAg");
	this.shape_10.setTransform(-1.5,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).to({_off:true},2).wait(15));

	// 縦線
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#666666").ss(1,1,1).p("AAAsfIAAY/");
	this.shape_11.setTransform(51,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).to({_off:true},2).wait(15));

	// 横線
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#666666").ss(1,1,1).p("ASXjHMgktAAAAyWmPMAktAAAAyWpXMAktAAAASXDIMgktAAAAyWAAMAktAAAAyWJYMAktAAAAyWGQMAktAAA");
	this.shape_12.setTransform(-1.5,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).to({_off:true},2).wait(15));

	// 明示
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFF200").s().p("AlEMgIAA4/IKJAAIAAY/g");
	this.shape_13.setTransform(83.5,11.7);
	this.shape_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1).to({_off:false},0).to({_off:true},1).wait(15));

	// ベース
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFBF0").s().p("AyWMgIAA4/MAktAAAIAAY/g");
	this.shape_14.setTransform(-1.5,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).to({_off:true},2).wait(15));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-103.2,239.2,195.9);


(lib.vjv23表A要約損益計算書1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// vjv2-3t40,000
	this.instance = new lib.vjv23t18000("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(90.3,82.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},2).wait(12));

	// vjv2-3t70,000
	this.instance_1 = new lib.vjv23t30000("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(90.3,62.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},2).wait(12));

	// vjv2-3t80,000
	this.instance_2 = new lib.vjv23t40000("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(90.3,42.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},2).wait(12));

	// vjv2-3t90,000
	this.instance_3 = new lib.vjv23t48000("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(90.3,22.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},2).wait(12));

	// vjv2-3t150,000
	this.instance_4 = new lib.vjv23t192000("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(88.4,2.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},2).wait(12));

	// vjv2-3t240,000
	this.instance_5 = new lib.vjv23t240000("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(86,-17.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},2).wait(12));

	// vjv2-3t360,000
	this.instance_6 = new lib.vjv23t360000("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(88.4,-37.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},2).wait(12));

	// vjv2-3t600,000
	this.instance_7 = new lib.vjv23t600000("single",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(86,-57.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({_off:true},2).wait(12));

	// vjv2-3t当期純利益
	this.instance_8 = new lib.vjv23t当期純利益("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-69.9,81.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({_off:true},2).wait(12));

	// vjv2-3t税引前当期純利益
	this.instance_9 = new lib.vjv23t税引前当期純利益("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-50.9,61.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true},2).wait(12));

	// vjv2-3t経常利益
	this.instance_10 = new lib.vjv23t経常利益("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(-74.9,41.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({_off:true},2).wait(12));

	// vjv2-3t営業利益
	this.instance_11 = new lib.vjv23t営業利益("synched",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(-74.9,21.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({_off:true},2).wait(12));

	// vjv2-3t販売費及び一般管理費
	this.instance_12 = new lib.vjv23t販売費及び一般管理費("synched",0);
	this.instance_12.parent = this;
	this.instance_12.setTransform(-26.2,1.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true},2).wait(12));

	// vjv2-3t売上総利益
	this.instance_13 = new lib.vjv23t売上総利益("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(-69.9,-18.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({_off:true},2).wait(12));

	// vjv2-3t売上原価
	this.instance_14 = new lib.vjv23t売上原価("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(-70.9,-38.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({_off:true},2).wait(12));

	// vjv2-3t売上高2
	this.instance_15 = new lib.vjv23t売上高2("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-84.9,-58.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({_off:true},2).wait(12));

	// vjv2-3t（単位：千円）
	this.instance_16 = new lib.vjv23t単位千円("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(84,-76.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({_off:true},2).wait(12));

	// vjv2-3t要約損益計算書
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F00B3").s().p("AAgBOIAAgGIhAAAIAAAGIgXAAIAAg1IBvAAIAAA1gAggA6IBAAAIAAgEIhAAAgAggArIBAAAIAAgEIhAAAgAhMAVIAAgQIBAAAIAAgEIgyAAIAAgLIAyAAIAAgDIgvAAIAAgPIAvAAIAAgFIhAAAIAAgQIBAAAIAAgEIgvAAIAAgQIAvAAIAAgIIAYAAIAAAIIAwAAIAAAUIARAAIAAAQIgRAAIAAAUIgwAAIAAADIAzAAIAAALIgzAAIAAAEIBAAAIAAAQgAAMgcIAYAAIAAgFIgYAAgAAMgxIAYAAIAAgEIgYAAg");
	this.shape.setTransform(72.3,-92.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F00B3").s().p("AhEA7QAXgEAFgHIghAAIAAgSIAtAAIAAgFIgcAAIAAg+QgEAFgEACIgNgVQAUgKAIgRIAYADIgCAFIAcAAIAAAJQAKgHADgKIAYAEIgCAEIAoAAIAAASIgWAAIADALIgYAAIgDgLIgEAAQgFAGgLAHIAxAAIAABAIgVAAIAAAFIAnAAIAAASIgnAAIAAAdIgXAAIAAgdIgYAAQgHANgKAHQgPAJgOACgAgDAeIASAAIAAgFIgRAAgAggAJIBEAAIAAgDIhEAAgAgggGIBEAAIAAgDIhEAAgAgggVIBEAAIAAgDIhEAAgAAFgnIgKgNIgJAAIACALIgWAAIgCgLIgDAAQgFAHgJAGIA6AAg");
	this.shape_1.setTransform(55.2,-92.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2F00B3").s().p("AAWBNIAAhUIgfAAIAAgVIAfAAIAAgwIAXAAIAAAwIAgAAIAAAVIggAAIAABUgAhIBJIAAgzIA8AAIAAArIgkAAIAAAIgAgwAwIAOAAIAAgJIgOAAgAhFAQIAAgQIA4AAIAAAQgAhFgFIAAgRIA4AAIAAARgAhMgcIAAgSIBBAAIAAASgAhFg0IAAgSIA3AAIAAASg");
	this.shape_2.setTransform(38.3,-92.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2F00B3").s().p("AhKBLIAAgVIATAAIAAgjQgFAFgIAFIgKgaQAYgKANgSIgjAAIAAgVIAnAAQgEgLgIgHIAWgKQAJAIAHAQIgKAEIAbAAIAPgcIAYAGIgLAWIArAAIAAAVIgiAAQAEAHALAJQAKAJALAEIgMAYIgLgIIAAAiIASAAIAAAVgAAZA2IAIAAIAAgeIgIAAgAgCA2IAGAAIAAgeIgGAAgAggA2IAIAAIAAgeIgIAAgAgjADIBIAAQgIgFgPgXIgbAAQgNAWgJAGg");
	this.shape_3.setTransform(21.3,-93);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#2F00B3").s().p("AgiA4QAGAAAIgCQAJgCACgBIgMAAIAAhPIBaAAIAABPIgPAAQAMAFAMABIgJAVQgIgBgNgFQgMgFgIgFIAKgLIgdAAIAKALQgHAGgMAEQgOAGgKABgAACAiIAsAAIAAgGIgsAAgAACAOIAsAAIAAgGIgsAAgAACgGIAsAAIAAgFIgsAAgAhDBMIgHgXIAJAAQAFAAAAgHIAAgZIgMAFIgFgYIARgDIAAgZIgQAAIAAgUIAQAAIAAggIAXAAIAAAgIAMAAIAAAUIgMAAIAAASIAIgDIAGATIgOAGIAAAvQAAAPgNAAgAgRggIAAgoIBRAAIAAAogAAFgyIAlAAIAAgFIglAAg");
	this.shape_4.setTransform(4.4,-92.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#2F00B3").s().p("AgtBOIAAg/IgbABIgDgWIASAAIAFgGIgXgYIAKgTIAHAHIAOgbIAUAIIgSAhIACAEIAQgaIAUAKIgUAfIARgFQAKAYACAJIgJADQAFASACAWIgUADQAAgTgEgUIAHgBIgBgHIgJABIAABBgAgdgHIAHgBIgCgFgAAaBNIgHgXIAWAAQAHAAAAgKIACgXIACgdIABgVIggAAIgGALQgEAGgDACIgRgPQAVgaAGgaIAWAGQgBAIgHAMIAsAAIgBAcIgBAuIgCAbQgCAQgEAFQgEAGgMAAgAhIBBQAFgTAAgaIASACQAAAggDAQgAASANQgFgMgDgEIAUgJIAIAQQAGAPABAFIgVAHQAAgGgGgMg");
	this.shape_5.setTransform(-12.8,-92.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#2F00B3").s().p("AhGA1QAlABAQgGIgMgDIgEADIgUgKQAMgKABgFIgjAAIAAgWIAzAAIAEgEIgpAAIAAgtIAhAAIAAgGIguAAIAAgVICWAAIAAAVIgvAAIAAAGIAhAAIAAAtIg4AAIgEAEIBKAAIAAAVIgbAAIgGALQgEAGgDACQATAFAPAHIgNAWQgFgDgOgGIgUgIQgOAJgTAEQgVAFgYAAgAgOAcIAYAFQACgBADgDIADgGIgbAAgAAdgWIAJAAIAAgHIgJAAgAgFgWIALAAIAAgHIgLAAgAglgWIAJAAIAAgHIgJAAgAgFgwIALAAIAAgGIgLAAg");
	this.shape_6.setTransform(-29.7,-92.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#2F00B3").s().p("AAFAtQAZgJAJgMQAQgYgKgWQgKgWgaAAQAABEgcAaQgMAKgNgFQgNgFgHgOQgNgbANgdQAMgcAdgMQAUgIATADQAVACAPAOQARAQACAYQACAZgOAUQgOAUgcAKgAguABQgBAJADAKQAEALAHgDQAIgEAGgSQAGgRAAgeQgeALgDAfg");
	this.shape_7.setTransform(-46.1,-92.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#2F00B3").s().p("AgzBOIAAgvQgGAIgKAIIgKgXQAMgJAOgPQANgOAHgOIgsAAIAAgVIAYAAIAAgcIAXAAIAAAcIAIAAIAAgBIASANIgHAPQgFAKgHAJQAFAGARAKIgKAYIgSgSIAAA7gAgQBIIAAgVIAlAAIAAg6IgaAAIAAgVIAaAAIAAgwIAXAAIAAAwIAcAAIAAAVIgcAAIAAA6IAiAAIAAAVg");
	this.shape_8.setTransform(-62.6,-92.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#2F00B3").s().p("AAhBEIgIgdIgwAAIgHAdIgfAAIAuiIIAgAAIAtCIgAgQATIAiAAIgRg4g");
	this.shape_9.setTransform(-77.3,-92.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},2).wait(12));

	// 外枠
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("AyWsfMAktAAAIAAY/MgktAAAg");
	this.shape_10.setTransform(-1.5,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).to({_off:true},2).wait(12));

	// 縦線
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#666666").ss(1,1,1).p("AAAsfIAAY/");
	this.shape_11.setTransform(51,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).to({_off:true},2).wait(12));

	// 横線
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#666666").ss(1,1,1).p("ASXjHMgktAAAAyWmPMAktAAAAyWpXMAktAAAASXDIMgktAAAAyWAAMAktAAAAyWJYMAktAAAAyWGQMAktAAA");
	this.shape_12.setTransform(-1.5,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).to({_off:true},2).wait(12));

	// 明示
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFF200").s().p("AlEMgIAA4/IKJAAIAAY/g");
	this.shape_13.setTransform(83.5,11.7);
	this.shape_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1).to({_off:false},0).to({_off:true},1).wait(12));

	// ベース
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFBF0").s().p("AyWMgIAA4/MAktAAAIAAY/g");
	this.shape_14.setTransform(-1.5,11.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).to({_off:true},2).wait(12));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-103.2,239.2,195.9);


(lib.vjv計算btmc1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				exportRoot.jtLabelN = "label_5";
				Next();
				e.nativeEvent.preventDefault();
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// レイヤー 2
	this.instance = new lib.vjv202BT計算g("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-41.8,-17);

	this.hani = new lib.vjv202BT計算();
	this.hani.parent = this;
	this.hani.setTransform(-41.8,-17);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202BT計算(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.hani}]},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.3,-19.5,88.8,39);


(lib.UICloseBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// マーク
	this.instance = new lib.UI閉じるボタンMC("single",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,-7.6,1,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({startPosition:1},0).wait(5));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(10.9,-9.8,1.419,1.502,0,0,0,26.9,19.3);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.9,-44.1,88,78.1);


(lib.UI_節終了画面 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 文字
	this.instance = new lib.UI_節終了画面_文字("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(350,187.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.2,scaleY:1.2,y:382.5},0).wait(1));

	// 黒
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.498)").s().p("Eg2rAgbMAAAhA1MBtXAAAMAAABA1g");
	this.shape.setTransform(350,207.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.498)").s().p("Eg2rBCBMAAAiEBMBtXAAAMAAACEBg");
	this.shape_1.setTransform(350,422.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,700.1,415);


(lib.s0059MC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(60));

	// s0-9MC
	this.instance = new lib.s09MC("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.2,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:3},0).wait(1).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(1).to({startPosition:6},0).wait(1).to({startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({startPosition:9},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:3},0).wait(1).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(1).to({startPosition:6},0).wait(1).to({startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({startPosition:9},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:3},0).wait(1).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(1).to({startPosition:6},0).wait(1).to({startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({startPosition:9},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:3},0).wait(1).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(1).to({startPosition:6},0).wait(1).to({startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({startPosition:9},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:3},0).wait(1).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(1).to({startPosition:6},0).wait(1).to({startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({startPosition:9},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:2},0).wait(1).to({startPosition:3},0).wait(1).to({startPosition:4},0).wait(1).to({startPosition:5},0).wait(1).to({startPosition:6},0).wait(1).to({startPosition:7},0).wait(1).to({startPosition:8},0).wait(1).to({startPosition:9},0).wait(1));

	// s0-9MC
	this.instance_1 = new lib.s09MC("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-5.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10).to({startPosition:1},0).wait(10).to({startPosition:2},0).wait(10).to({startPosition:3},0).wait(10).to({startPosition:4},0).wait(10).to({startPosition:5},0).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.3,-11.5,24.8,23);


(lib.p1l_IF共通範囲 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.u_b("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-50,0,1,1,0,0,0,0,50);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.汎用範囲 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.u_b("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(50,50,1,1,0,0,0,50,50);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.mc選状sel16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t6500("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel16, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t16000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel15, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t17000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel14, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t19500("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel13, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t110500("single",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel12, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t130000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(0.8,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel11, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t520000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel10, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t650000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(0.8,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel9, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t18000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel8, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t30000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel7, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t40000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel6, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t48000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(5.6,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel5, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t192000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel4, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t240000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(0.8,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel3, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t360000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(3.5,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel2, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.mc選状sel1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.vjv23t600000("single",0);
	this.instance.parent = this;
	this.instance.setTransform(0.8,0,1.1,1.1);

	this.instance_1 = new lib.vjv202Q選択Box("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,1.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mc選状sel1, new cjs.Rectangle(-36.8,-12.1,73.7,24.2), null);


(lib.LMSBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// マーク
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjbCzIAAjnICzh+ICxB+IAADngAgeA9QgKARABAWQAAAUAMAOQAKALAPAAQAYAAAKgfIgUAAQgCAIgGADQgEAEgIgEQgKgFgBgTIA1AAIAAgGQAAgagOgOQgKgMgOAAQgQAAgKASgABhBDQAFAGAAAMIAAA7IATAAIAAg+QAAgWgKgKQgGgHgLAAQgNAAgKAQIAAgPIgTAAIAABkIATAAIAAg5QABgGAFgJQAFgJAGAAQAEAAAFAEgAhQCQIAUAAIAAiFIgeAAIgWBiIgWhiIgdAAIAACFIATAAIAAhfIAUBfIAYAAIAUhfgAhNgQIBJAAIAAhJIhJAAgACkCNQgJgJAAgQIAAhFIATAAIAAA+QAAAKAEAFQADAFAGAAQAFAAAFgFQAEgGAAgJIAAg+IATAAIAABkIgTAAIAAgKQgJALgLAAQgKAAgHgHgAgTBUQAAgJAGgIQAGgHAHABQAMADACAUg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.keiBtmc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				exportRoot.jtLabelN = "label_5";
				Next();
				e.nativeEvent.preventDefault();
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// レイヤー 1
	this.hani = new lib.vjv202BT計算();
	this.hani.parent = this;
	this.hani.setTransform(-41.8,-17);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202BT計算(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(1));

}).prototype = getMCSymbolPrototype(lib.keiBtmc, new cjs.Rectangle(-44.3,-19.5,88.8,39), null);


(lib.IF_スライド範囲 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.u_b("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-157.5,-15,3.15,0.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.if_slider = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		// マウス操作してません
		slider_operating = false;
		// マウス追従キャンセル
		this.pF = true;
		// バー操作位置変数 初期化
		this.move_pos = 1;
		// 操作可、不可変数 代入
		this.operation = false;
		// 操作可、不可切替
		SBcan_operate();
	}
	this.frame_1 = function() {
		this.but_slider.visible = false;
		this.stop();
	}
	this.frame_2 = function() {
		this.but_slider.visible = true;
		if (!this.hani.hasEventListener("mouseout")) {
			this.hani.addEventListener("mousedown", SBmdH.bind(this));
			this.hani.addEventListener("pressup", SBpuH.bind(this));
			this.hani.addEventListener("mouseout", SBmotH);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1));

	// 範囲
	this.hani = new lib.IF_スライド範囲();
	this.hani.parent = this;
	this.hani.setTransform(340.6,-2.9,2.222,1.667);
	this.hani._off = true;
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.IF_スライド範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2).to({_off:false},0).wait(1));

	// ポインタ
	this.but_slider = new lib.IF_but_slider();
	this.but_slider.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.but_slider).wait(3));

	// 進捗
	this.progress = new lib.IF_progress();
	this.progress.parent = this;
	this.progress.setTransform(0,0,0.002,1);

	this.timeline.addTween(cjs.Tween.get(this.progress).wait(3));

	// 進捗ベース
	this.base = new lib.IF_progressBase();
	this.base.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.base).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.7,-10.5,686.7,21);


(lib.playBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_0 = function() {
		this.visible = false;
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// マーク
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiZixIE0CxIk0Cyg");
	this.shape.setTransform(2,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.backBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// マーク
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhtAOIAAClIg8AAIAAllIA8AAIAACkIEXikIAAFlg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.nextBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// マーク
	this.icon = new lib.IF_but_進む三角();
	this.icon.parent = this;
	this.icon.setTransform(0.6,0,1,1,0,0,0,0.6,0);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.pauseBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// マーク
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAvCzIAAllIBkAAIAAFlgAiSCzIAAllIBkAAIAAFlg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.学習時間MC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_1 = function() {
		var strTime = new String(this.texT);
		var arrTime = strTime.split(":");
		this.miN.gotoAndStop(parseFloat(arrTime[0]));
		this.seC.gotoAndStop(parseFloat(arrTime[1]));
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(1));

	// sec
	this.seC = new lib.s0059MC();
	this.seC.parent = this;
	this.seC.setTransform(7.1,0);

	this.timeline.addTween(cjs.Tween.get(this.seC).wait(2));

	// :
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLA0IAAgYIAXAAIAAAYgAgLgbIAAgYIAXAAIAAAYg");
	this.shape.setTransform(-5.3,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// min
	this.miN = new lib.s09MC();
	this.miN.parent = this;
	this.miN.setTransform(-12.2,0);

	this.timeline.addTween(cjs.Tween.get(this.miN).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.4,-11.5,38.8,23);


(lib.copyright2017 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 明
	this.instance = new lib.copyright10baseW("single",7);
	this.instance.parent = this;
	this.instance.setTransform(-33.9,-5.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// 暗
	this.instance_1 = new lib.copyright10baseB("single",7);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-33.5,-5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// ベース
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(242,242,242,0.498)").s().p("AluBFIAAiJILdAAIAACJg");
	this.shape.setTransform(-35.1,-5.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.8,-12.2,73.3,13.7);


(lib.b_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// レイヤー 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkqAzIAMgFQAHgDAKgGIAUgRQAGgFAFgFIAIgKIgZgSIgSgLIALgMIASAKIAYARQAIgNAEgJIAHgQIADgMIAVAFIgHAPIgJATIgMAWIAQAMIAMAKIAHAIIgQAOIgKgNIgUgRIgOAPIgWATQgOAJgVAKgAAXA5IAAgQIBAAAIADgQIACgRIABgNIAAgHIg5AAIAAgRIBLAAIgCAYIgCARIgBAOIgCAPIAbAAIAAAQgAiOAwIAAgQICEAAIAAAQgACiAGIAAgRICJAAIAAARgAiDgfIAAgRIBrAAIAAARg");
	this.shape.setTransform(-4,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	// レイヤー 1
	this.instance = new lib.b_menu_part01("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(-4,-4.6,1.185,1.185);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.2,-13.5,120.4,26.7);


(lib.yougoOnBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"release":1,"over":5});

	// timeline functions:
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(4).call(this.frame_6).wait(4));

	// 範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(10));

	// レイヤー 6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAFCjQA/giBxAIIAAAPQhwgIhAAigAi0CYIAAgPQBwgIA/AiIAAAPQg/gihwAIgAAFCJQA/ghBxAHIAAAPQhwgHhAAhgAi0B+IAAgPQBwgHA/AhIAAAPQg/ghhwAHgAAFhCQAmgUA3gGIgLAIIgOAKIgIAGIgFAGQgGAIgEAJQgDAJAAALIABAGIAAAGIgBAGIAmAAIAAgIIAAgHQAAgIACgFQABgFAFgFQAFgFAJgGIATgNIAJgIIAHgIIAGgIIAhABIAAC/QhxgIg/AigAAtA3IAqAAIAAgnIgqAAgAi0BjIAAi/QBwgIA/AiIAAC/Qg/gihwAIgABqhkQAGgIAAgKQAAgNgLgIQgKgHgTAAQgLAAgKAEQgIAEgFAIQgDAEgCAFQgCAFAAAIIgqgGQAEgPAFgKQADgKAKgIQALgJAQgGQAQgFAUAAQAXAAASAIQASAHAKANQAKAMAAASQAAAKgDAIIgCAHQgagBgXADIAHgIg");
	this.shape.setTransform(0,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

	// 明示
	this.instance = new lib.UIボタン明示("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,-0.5,1,1,0,0,0,23.5,22.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-26.5,62,52);


(lib.解答欄範囲q14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//解答欄総数
				var ansTN = 4;
				//全解答欄の選択OFF--------------------------
				if (exportRoot.selAns != -1) {
					for (var i = 1; i <= ansTN; i++) {
						ymc["q1ans" + i].waku.visible = false;
						tmc["q1ans" + i].waku.visible = false;
					}
				}
				//この解答欄に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている解答欄を調べる---------------
				for (var i = 1; i <= ansTN; i++) {
					if (ymc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//縦連動
						tmc["q1ans" + i].waku.visible = true;
						break;
					}
					if (tmc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//横連動
						ymc["q1ans" + i].waku.visible = true;
						break;
					}
				}
				//選択肢がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selSel != -1) {
					//対象の解答欄mcを変数に代入(ans_mc)
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selSel == 9) {
						ymc.q1ans4.visible = false;
						tmc.q1ans4.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
						if (k4ry == 0) {
							k4ry = 1;
							ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
							tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
						} else {
							kno = 4;
							Next();
						}
					}
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// waku
	this.waku = new lib.選択枠解答q1();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

	// hani
	this.hani = new lib.汎用範囲();
	this.hani.parent = this;
	this.hani.setTransform(-59,-14,1.18,0.28,0,0,0,0,-0.2);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.汎用範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-14,118,28);


(lib.解答欄範囲q13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//解答欄総数
				var ansTN = 4;
				//全解答欄の選択OFF--------------------------
				if (exportRoot.selAns != -1) {
					for (var i = 1; i <= ansTN; i++) {
						ymc["q1ans" + i].waku.visible = false;
						tmc["q1ans" + i].waku.visible = false;
					}
				}
				//この解答欄に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている解答欄を調べる---------------
				for (var i = 1; i <= ansTN; i++) {
					if (ymc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//縦連動
						tmc["q1ans" + i].waku.visible = true;
						break;
					}
					if (tmc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//横連動
						ymc["q1ans" + i].waku.visible = true;
						break;
					}
				}
				//選択肢がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selSel != -1) {
					//対象の解答欄mcを変数に代入(ans_mc)
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selSel == 16) {
						ymc.q1ans3.visible = false;
						tmc.q1ans3.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
						if (k3ry == 0) {
							k3ry = 1;
							ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
							tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
						} else {
							kno = 3;
							Next();
						}
					}
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// waku
	this.waku = new lib.選択枠解答q1();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

	// hani
	this.hani = new lib.汎用範囲();
	this.hani.parent = this;
	this.hani.setTransform(-59,-14,1.18,0.28,0,0,0,0,-0.2);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.汎用範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-14,118,28);


(lib.解答欄範囲q12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//解答欄総数
				var ansTN = 4;
				//全解答欄の選択OFF--------------------------
				if (exportRoot.selAns != -1) {
					for (var i = 1; i <= ansTN; i++) {
						ymc["q1ans" + i].waku.visible = false;
						tmc["q1ans" + i].waku.visible = false;
					}
				}
				//この解答欄に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている解答欄を調べる---------------
				for (var i = 1; i <= ansTN; i++) {
					if (ymc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//縦連動
						tmc["q1ans" + i].waku.visible = true;
						break;
					}
					if (tmc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//横連動
						ymc["q1ans" + i].waku.visible = true;
						break;
					}
				}
				//選択肢がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selSel != -1) {
					//対象の解答欄mcを変数に代入(ans_mc)
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selSel == 1) {
						ymc.q1ans2.visible = false;
						tmc.q1ans2.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
						if (k2ry == 0) {
							k2ry = 1;
							ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
							tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
						} else {
							kno = 2;
							Next();
						}
		
					}
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// waku
	this.waku = new lib.選択枠解答q1();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

	// hani
	this.hani = new lib.汎用範囲();
	this.hani.parent = this;
	this.hani.setTransform(-59,-14,1.18,0.28,0,0,0,0,-0.2);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.汎用範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-14,118,28);


(lib.解答欄範囲q11 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//解答欄総数
				var ansTN = 4;
				//全解答欄の選択OFF--------------------------
				if (exportRoot.selAns != -1) {
					for (var i = 1; i <= ansTN; i++) {
						ymc["q1ans" + i].waku.visible = false;
						tmc["q1ans" + i].waku.visible = false;
					}
				}
				//この解答欄に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている解答欄を調べる---------------
				for (var i = 1; i <= ansTN; i++) {
					if (ymc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//縦連動
						tmc["q1ans" + i].waku.visible = true;
						break;
					}
					if (tmc["q1ans" + i].waku.visible) {
						//selAns変数に番号を代入
						exportRoot.selAns = i;
						//横連動
						ymc["q1ans" + i].waku.visible = true;
						break;
					}
				}
				//選択肢がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selSel != -1) {
					//対象の解答欄mcを変数に代入(ans_mc)
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selSel == 8) {
						ymc.q1ans1.visible = false;
						tmc.q1ans1.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
						if (k1ry == 0) {
							k1ry = 1;
							ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
							tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
						} else {
							kno = 1;
							Next();
						}
		
					}
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// waku
	this.waku = new lib.選択枠解答q1();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

	// hani
	this.hani = new lib.汎用範囲();
	this.hani.parent = this;
	this.hani.setTransform(-59,-14,1.18,0.28,0,0,0,0,-0.2);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.汎用範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-14,118,28);


(lib.vjv202q1選択肢16 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selAns == 3) {
						ymc.q1ans3.visible = false;
						tmc.q1ans3.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
					}
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel16();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel15();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel14();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel13();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel12();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢11 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel11();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel10();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selAns == 4) {
						ymc.q1ans4.visible = false;
						tmc.q1ans4.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
						if (eval("k" + exportRoot.selAns + "ry == 0")) {
							eval("k" + exportRoot.selAns + "ry = 1");
							ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
							tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
						} else {
							kno = exportRoot.selAns;
							Next();
						}
					}
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel9();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selAns == 1) {
						ymc.q1ans1.visible = false;
						tmc.q1ans1.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
						if (eval("k" + exportRoot.selAns + "ry == 0")) {
							eval("k" + exportRoot.selAns + "ry = 1");
							ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
							tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
						} else {
							kno = exportRoot.selAns;
							Next();
						}
					}
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel8();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel7();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel6();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel5();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel4();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel3();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (eval("k" + exportRoot.selAns + "ry == 0")) {
						eval("k" + exportRoot.selAns + "ry = 1");
						ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
						tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
					} else {
						kno = exportRoot.selAns;
						Next();
					}
		
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel2();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.vjv202q1選択肢1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.waku.visible = false;
		if (!this.hani.hasEventListener("click")) {
			this.hani.addEventListener("click", clickHandler.bind(this));
			function clickHandler(e) {
				//書式短縮のため代入(yoko_mc,tate_mcの略)
				var ymc = exportRoot.mcLyoko;
				var tmc = exportRoot.mcLtate;
				//選択肢総数
				var selTN = 16;
				//全選択肢の選択OFF--------------------------
				if (exportRoot.selSel != -1) {
					for (var i = 1; i <= selTN; i++) {
						ymc["q1sel" + i].waku.visible = false;
						tmc["q1sel" + i].waku.visible = false;
					}
				}
				//この選択肢に枠を表示-----------------------
				this.waku.visible = true;
				//選択されている選択肢を調べる---------------
				for (var i = 1; i <= selTN; i++) {
					if (ymc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//縦連動
						tmc["q1sel" + i].waku.visible = true;
						break;
					}
					if (tmc["q1sel" + i].waku.visible) {
						//selSel変数に番号を代入
						exportRoot.selSel = i;
						//横連動
						ymc["q1sel" + i].waku.visible = true;
						break;
					}
				}
				//解答欄がすでに選択されていたら-------------
				//当てはめ成立
				if (exportRoot.selAns != -1) {
					//対象の解答欄mcを動かす(ans_mcの略)
					//横
					var amc = ymc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//縦
					amc = tmc["q1ap" + exportRoot.selAns];
					amc.gotoAndStop(exportRoot.selSel);
					//選択枠を消す
					ymc["q1sel" + exportRoot.selSel].waku.visible = false;
					tmc["q1sel" + exportRoot.selSel].waku.visible = false;
					ymc["q1ans" + exportRoot.selAns].waku.visible = false;
					tmc["q1ans" + exportRoot.selAns].waku.visible = false;
		
					//判定
					if (exportRoot.selAns == 2) {
						ymc.q1ans2.visible = false;
						tmc.q1ans2.visible = false;
						exportRoot.otosei.gotoAndPlay(2);
					} else {
						if (eval("k" + exportRoot.selAns + "ry == 0")) {
							eval("k" + exportRoot.selAns + "ry = 1");
							ymc["dame" + exportRoot.selAns].gotoAndPlay(2);
							tmc["dame" + exportRoot.selAns].gotoAndPlay(2);
						} else {
							kno = exportRoot.selAns;
							Next();
						}
		
					}
		
		
		
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
					exportRoot["q1kai" + exportRoot.selAns] = exportRoot.selSel;
					//★採点用に変数を使う場合★★★★★★★★★★★★★★★
		
					exportRoot.selSel = -1;
					exportRoot.selAns = -1;
				}
				e.nativeEvent.preventDefault();
			}
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// hani
	this.hani = new lib.vjv202q範囲();
	this.hani.parent = this;
	this.hani.setTransform(-32.5,-10,0.382,0.277);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.vjv202q範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(2));

	// レイヤー 13
	this.waku = new lib.mc選状sel1();
	this.waku.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.waku).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.8,-12.1,73.7,24.2);


(lib.UIOnBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// g
	this.instance = new lib.b_menu("single",0);
	this.instance.parent = this;
	this.instance.setTransform(19.5,15,0.976,1.096);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// ボタン範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(14.5,31.3,2.408,1.692,0,0,0,26.9,19.4);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(1));

}).prototype = getMCSymbolPrototype(lib.UIOnBtn, new cjs.Rectangle(-68.3,-7.4,149.3,88), null);


(lib.UIOffBtn = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// レイヤー 1
	this.instance = new lib.b_menu("single",1);
	this.instance.parent = this;
	this.instance.setTransform(19.5,15,0.976,1.096);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// ボタン範囲
	this.hani = new lib.ボタン範囲PB();
	this.hani.parent = this;
	this.hani.setTransform(14.5,31.3,2.408,1.692,0,0,0,26.9,19.4);
	new cjs.ButtonHelper(this.hani, 0, 1, 2, false, new lib.ボタン範囲PB(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani).wait(1));

}).prototype = getMCSymbolPrototype(lib.UIOffBtn, new cjs.Rectangle(-68.3,-7.4,149.3,88), null);


(lib.p1l_音量調整MC_nw = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//音量初期クローズ
		ssClose(false);
		// 音量＆ミュート変数をセット（後でcookieに変更）
		if (cVolume == void(0)) {
			cVolume = 100;
			cVzenkai = -1;
		}
		this.bVol = -1;
		// 前回のボリューム
		this.parent.now_vol = cVolume;
		this.frmB = 0;
		// ボリュームのスライド幅
		this.s_width = 100;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 範囲
	this.hani1 = new lib.p1l_IF共通範囲();
	this.hani1.parent = this;
	this.hani1.setTransform(138,-0.2,0.55,0.6,-90,0,0,-0.4,0.1);
	new cjs.ButtonHelper(this.hani1, 0, 1, 2, false, new lib.p1l_IF共通範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani1).wait(1));

	// 音
	this.vol_dispB = new lib.bt_vol();
	this.vol_dispB.parent = this;
	this.vol_dispB.setTransform(132.4,-0.1,1,1,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.vol_dispB).wait(1));

	// 範囲
	this.hani2 = new lib.p1l_IF共通範囲();
	this.hani2.parent = this;
	this.hani2.setTransform(-11.5,0,1.2,0.55,0,180,0,-49.6,-0.2);
	new cjs.ButtonHelper(this.hani2, 0, 1, 2, false, new lib.p1l_IF共通範囲(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hani2).wait(1));

	// ツマミ
	this.vol_tumami = new lib.p1l_音量ツマミMC();
	this.vol_tumami.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.vol_tumami).wait(1));

	// 音量
	this.vol_disp = new lib.p1l_vol_disp_iro();
	this.vol_disp.parent = this;
	this.vol_disp.setTransform(0,0,0.02,1);

	this.timeline.addTween(cjs.Tween.get(this.vol_disp).wait(1));

	// 音量ベース色
	this.base = new lib.p1l_vol_disp_iroBase();
	this.base.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.base).wait(1));

	// ベース色
	this.vol_base = new lib.UI_vol_base();
	this.vol_base.parent = this;
	this.vol_base.setTransform(75.1,0);

	this.timeline.addTween(cjs.Tween.get(this.vol_base).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1l_音量調整MC_nw, new cjs.Rectangle(-12,-27.9,179.9,55.4), null);


(lib.レイアウト横 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// 下部隠し
	this.instance = new lib.UI_hide1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,624.1,1,1,0,0,0,0,422.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(465));

	// 次節へ進む画面
	this.instance_1 = new lib.UI_節終了画面("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-349.9,-212.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(464).to({_off:false},0).wait(1));

	// グラデ
	this.instance_2 = new lib.グラデbox("single",1);
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,196);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(465));

	// マイナスにならない
	this.instance_3 = new lib.vjv202tマイナスにならない("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,123.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(371).to({_off:false},0).wait(4).to({scaleX:1.1,scaleY:1.1},0).wait(4).to({scaleX:1,scaleY:1},0).wait(4).to({scaleX:1.1,scaleY:1.1},0).wait(4).to({scaleX:1,scaleY:1},0).wait(78));

	// 通常1から3
	this.instance_4 = new lib.vjv202t通常1から3("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,86.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(317).to({_off:false},0).wait(148));

	// キャラＢ
	this.instance_5 = new lib.vjv202キャラB("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(294.2,93.2);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(3).to({_off:false},0).wait(276).to({startPosition:2},0).wait(116).to({startPosition:4},0).wait(70));

	// キャラＡ
	this.instance_6 = new lib.vjv202キャラA("single",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-313.9,95.1);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({_off:false},0).wait(276).to({startPosition:1},0).wait(186));

	// 正解表示
	this.seih3 = new lib.vjv202q3正解3();
	this.seih3.parent = this;
	this.seih3.setTransform(234,-56);

	this.seih1 = new lib.vjv202q3正解1();
	this.seih1.parent = this;
	this.seih1.setTransform(-74,-56);

	this.seih2 = new lib.vjv202q3正解2();
	this.seih2.parent = this;
	this.seih2.setTransform(-74,-59);

	this.seih4 = new lib.vjv202q3正解4();
	this.seih4.parent = this;
	this.seih4.setTransform(234,-59);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.seih4},{t:this.seih2},{t:this.seih1},{t:this.seih3}]},191).to({state:[]},38).wait(236));

	// 操作テキスト
	this.instance_7 = new lib.vjvQ操作txt("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(2,136.5);

	this.instance_8 = new lib.vjvQ操作txt1("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(2,136.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},111).to({state:[]},56).to({state:[{t:this.instance_8}]},76).to({state:[]},36).wait(186));

	// 計算ボタン
	this.instance_9 = new lib.keiBtmc();
	this.instance_9.parent = this;
	this.instance_9.setTransform(7.7,92,1,1,0,0,0,7.7,0);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(255).to({_off:false},0).to({_off:true},24).wait(186));

	// 計算ボタン
	this.keimc = new lib.vjv計算btmc1();
	this.keimc.parent = this;
	this.keimc.setTransform(7.7,92,1,1,0,0,0,7.7,0);

	this.instance_10 = new lib.vjv202BT計算g("single",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(-41.8,75);

	this.instance_11 = new lib.vjv202BT計算();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-41.8,75);
	new cjs.ButtonHelper(this.instance_11, 0, 1, 2, false, new lib.vjv202BT計算(), 3);

	this.instance_12 = new lib.vjv202BT計算明();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-41.8,75);
	new cjs.ButtonHelper(this.instance_12, 0, 1, 2, false, new lib.vjv202BT計算明(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.keimc}]},111).to({state:[{t:this.instance_10}]},56).to({state:[{t:this.instance_11}]},62).to({state:[{t:this.instance_12}]},14).to({state:[{t:this.instance_11}]},4).to({state:[{t:this.instance_12}]},4).to({state:[]},4).wait(210));

	// クイズ操作説明アニメ
	this.instance_13 = new lib.vjv202選択600000("single",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(-67.5,-163.5);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(93).to({_off:false},0).wait(4).to({mode:"synched"},0).to({x:-71.6,y:-120,mode:"single",startPosition:1},2).to({x:-84,y:10.5,startPosition:0},6).to({alpha:0},4).to({_off:true},2).wait(354));

	// フェード
	this.instance_14 = new lib.フェード用2("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(217,31);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(89).to({_off:false},0).to({alpha:0},6).to({_off:true},2).wait(368));

	// フェード
	this.instance_15 = new lib.フェード用2("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-87,31);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(89).to({_off:false},0).to({alpha:0},6).to({_off:true},2).wait(368));

	// 解答欄範囲MC
	this.q1ans4 = new lib.解答欄範囲q14();
	this.q1ans4.parent = this;
	this.q1ans4.setTransform(224,44.5);

	this.q1ans3 = new lib.解答欄範囲q13();
	this.q1ans3.parent = this;
	this.q1ans3.setTransform(224,9.5);

	this.q1ans2 = new lib.解答欄範囲q12();
	this.q1ans2.parent = this;
	this.q1ans2.setTransform(-84.5,44.5);

	this.q1ans1 = new lib.解答欄範囲q11();
	this.q1ans1.parent = this;
	this.q1ans1.setTransform(-84.5,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.q1ans1},{t:this.q1ans2},{t:this.q1ans3},{t:this.q1ans4}]},89).to({state:[]},140).wait(236));

	// 選択範囲
	this.q1sel16 = new lib.vjv202q1選択肢16();
	this.q1sel16.parent = this;
	this.q1sel16.setTransform(236.5,-23.5);

	this.q1sel15 = new lib.vjv202q1選択肢15();
	this.q1sel15.parent = this;
	this.q1sel15.setTransform(236.5,-43.5);

	this.q1sel14 = new lib.vjv202q1選択肢14();
	this.q1sel14.parent = this;
	this.q1sel14.setTransform(236.5,-63.5);

	this.q1sel13 = new lib.vjv202q1選択肢13();
	this.q1sel13.parent = this;
	this.q1sel13.setTransform(236.5,-83.5);

	this.q1sel12 = new lib.vjv202q1選択肢12();
	this.q1sel12.parent = this;
	this.q1sel12.setTransform(236.5,-103.5);

	this.q1sel11 = new lib.vjv202q1選択肢11();
	this.q1sel11.parent = this;
	this.q1sel11.setTransform(236.5,-123.5);

	this.q1sel10 = new lib.vjv202q1選択肢10();
	this.q1sel10.parent = this;
	this.q1sel10.setTransform(236.5,-143.5);

	this.q1sel9 = new lib.vjv202q1選択肢9();
	this.q1sel9.parent = this;
	this.q1sel9.setTransform(236.5,-163.5);

	this.q1sel8 = new lib.vjv202q1選択肢8();
	this.q1sel8.parent = this;
	this.q1sel8.setTransform(-67.5,-23.5);

	this.q1sel7 = new lib.vjv202q1選択肢7();
	this.q1sel7.parent = this;
	this.q1sel7.setTransform(-67.5,-43.5);

	this.q1sel6 = new lib.vjv202q1選択肢6();
	this.q1sel6.parent = this;
	this.q1sel6.setTransform(-67.5,-63.5);

	this.q1sel5 = new lib.vjv202q1選択肢5();
	this.q1sel5.parent = this;
	this.q1sel5.setTransform(-67.5,-83.5);

	this.q1sel4 = new lib.vjv202q1選択肢4();
	this.q1sel4.parent = this;
	this.q1sel4.setTransform(-67.5,-103.5);

	this.q1sel3 = new lib.vjv202q1選択肢3();
	this.q1sel3.parent = this;
	this.q1sel3.setTransform(-67.5,-123.5);

	this.q1sel2 = new lib.vjv202q1選択肢2();
	this.q1sel2.parent = this;
	this.q1sel2.setTransform(-67.5,-143.5);

	this.q1sel1 = new lib.vjv202q1選択肢1();
	this.q1sel1.parent = this;
	this.q1sel1.setTransform(-67.5,-163.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.q1sel1},{t:this.q1sel2},{t:this.q1sel3},{t:this.q1sel4},{t:this.q1sel5},{t:this.q1sel6},{t:this.q1sel7},{t:this.q1sel8},{t:this.q1sel9},{t:this.q1sel10},{t:this.q1sel11},{t:this.q1sel12},{t:this.q1sel13},{t:this.q1sel14},{t:this.q1sel15},{t:this.q1sel16}]},89).to({state:[]},78).wait(298));

	// 誤メッセージ
	this.dame4 = new lib.vjv202q誤答メッセージ();
	this.dame4.parent = this;
	this.dame4.setTransform(163.6,86);

	this.dame2 = new lib.vjv202q誤答メッセージ();
	this.dame2.parent = this;
	this.dame2.setTransform(-166.4,86);

	this.dame3 = new lib.vjv202q誤答メッセージ();
	this.dame3.parent = this;
	this.dame3.setTransform(233.6,-34);

	this.dame1 = new lib.vjv202q誤答メッセージ();
	this.dame1.parent = this;
	this.dame1.setTransform(-88,-33.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.dame1},{t:this.dame3},{t:this.dame2},{t:this.dame4}]},89).to({state:[]},78).wait(298));

	// 解答欄
	this.q1ap4 = new lib.vjv202q1解答欄B2();
	this.q1ap4.parent = this;
	this.q1ap4.setTransform(224,44.5);

	this.q1ap2 = new lib.vjv202q1解答欄A2();
	this.q1ap2.parent = this;
	this.q1ap2.setTransform(-84,44.5);

	this.q1ap3 = new lib.vjv202q3解答欄B1();
	this.q1ap3.parent = this;
	this.q1ap3.setTransform(224,10.5);

	this.q1ap1 = new lib.vjv202q3解答欄A1();
	this.q1ap1.parent = this;
	this.q1ap1.setTransform(-84,10.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.q1ap1},{t:this.q1ap3},{t:this.q1ap2},{t:this.q1ap4}]},89).to({state:[]},140).wait(236));

	// 計算結果20％
	this.instance_16 = new lib.vjv2021("single",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(209.1,26.7);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(285).to({_off:false},0).wait(34).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(20).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(110));

	// 計算結果40％
	this.instance_17 = new lib.vjv2023("single",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(-95.9,26.7);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(285).to({_off:false},0).wait(34).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(20).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(110));

	// 式イコール
	this.instance_18 = new lib.vjv202txtイコール("single",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(156.1,27.8);

	this.instance_19 = new lib.vjv202txtイコール("single",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(-151.9,27.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},89).to({state:[{t:this.instance_19,p:{startPosition:1}},{t:this.instance_18,p:{startPosition:1}}]},230).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},4).to({state:[{t:this.instance_19,p:{startPosition:1}},{t:this.instance_18,p:{startPosition:1}}]},4).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},20).to({state:[{t:this.instance_19,p:{startPosition:1}},{t:this.instance_18,p:{startPosition:1}}]},4).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},4).wait(110));

	// レイヤー 36
	this.instance_20 = new lib.vjv202解答消し("synched",0,false);
	this.instance_20.parent = this;
	this.instance_20.setTransform(223.5,28);

	this.instance_21 = new lib.vjv202解答消し("synched",0,false);
	this.instance_21.parent = this;
	this.instance_21.setTransform(-84.5,28);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21},{t:this.instance_20}]},279).to({state:[]},6).wait(180));

	// 式括線
	this.instance_22 = new lib.vjv202括線("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(224,27.6);

	this.instance_23 = new lib.vjv202括線("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(-84,27.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_23},{t:this.instance_22}]},89).to({state:[]},196).wait(180));

	// 正解CG
	this.instance_24 = new lib.vjv23t6500("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(219.7,10.5);

	this.instance_25 = new lib.vjv23t18000("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(-84,10.5);

	this.instance_26 = new lib.vjv23t650000("single",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(224,44.5);

	this.instance_27 = new lib.vjv23t600000("single",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(-84,44.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24}]},89).to({state:[]},196).wait(180));

	// 消しフェード
	this.instance_28 = new lib.vjv202白隠し("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(0,162.5,4,2);
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(33).to({_off:false},0).to({alpha:0.012},6).to({_off:true},2).wait(424));

	// 営業利益率
	this.instance_29 = new lib.vjv202txt純利益率B("single",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(95.1,18.3);

	this.instance_30 = new lib.vjv202txt純利益率A("single",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(-209.9,18.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},33).to({state:[{t:this.instance_30,p:{startPosition:1}},{t:this.instance_29,p:{startPosition:1}}]},260).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},4).to({state:[{t:this.instance_30,p:{startPosition:1}},{t:this.instance_29,p:{startPosition:1}}]},4).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},4).to({state:[{t:this.instance_30,p:{startPosition:1}},{t:this.instance_29,p:{startPosition:1}}]},4).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},4).wait(152));

	// Ｂ社
	this.instance_31 = new lib.vjv23表B要約損益計算書1("single",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(152.7,-106.2,1,1,0,0,0,-0.3,0);
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(3).to({_off:false},0).wait(74).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(376));

	// Ａ社
	this.instance_32 = new lib.vjv23表A要約損益計算書1("single",0);
	this.instance_32.parent = this;
	this.instance_32.setTransform(-151.3,-106.2,1,1,0,0,0,-0.3,0);
	this.instance_32._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(3).to({_off:false},0).wait(74).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(376));

	// base
	this.UI_ONOFF = new lib.UI_cBaseMC();
	this.UI_ONOFF.parent = this;
	this.UI_ONOFF.setTransform(-349.9,-212.4,7,4.15);

	this.timeline.addTween(cjs.Tween.get(this.UI_ONOFF).wait(465));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-351,-212.4,702,1259);


(lib.レイアウト縦 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// 下部隠し
	this.instance = new lib.UI_hide1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,631.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(465));

	// 次節へ進む画面
	this.instance_1 = new lib.UI_節終了画面("single",1);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-350,-212.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(464).to({_off:false},0).wait(1));

	// グラデ
	this.instance_2 = new lib.グラデbox("single",2);
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,582);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(465));

	// マイナスにならない
	this.instance_3 = new lib.vjv202tマイナスにならない("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,358.4,1.25,1.25);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(371).to({_off:false},0).wait(4).to({scaleX:1.38,scaleY:1.38},0).wait(4).to({scaleX:1.25,scaleY:1.25},0).wait(4).to({scaleX:1.38,scaleY:1.38},0).wait(4).to({scaleX:1.25,scaleY:1.25},0).wait(78));

	// 通常1から3
	this.instance_4 = new lib.vjv202t通常1から3("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,272.2,1.25,1.25);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(317).to({_off:false},0).wait(148));

	// キャラＢ
	this.instance_5 = new lib.vjv202キャラB("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(267.7,461.1,1.25,1.25);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(3).to({_off:false},0).wait(276).to({startPosition:2},0).wait(116).to({startPosition:4},0).wait(70));

	// キャラＡ
	this.instance_6 = new lib.vjv202キャラA("single",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-292.4,463.5,1.25,1.25);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(3).to({_off:false},0).wait(276).to({startPosition:1},0).wait(186));

	// 正解表示
	this.seih3 = new lib.vjv202q3正解3();
	this.seih3.parent = this;
	this.seih3.setTransform(282.5,94.6,1.25,1.25,0,0,0,0,-0.1);

	this.seih1 = new lib.vjv202q3正解1();
	this.seih1.parent = this;
	this.seih1.setTransform(-82.5,94.6,1.25,1.25,0,0,0,0,-0.1);

	this.seih2 = new lib.vjv202q3正解2();
	this.seih2.parent = this;
	this.seih2.setTransform(-82.5,90.8,1.25,1.25,0,0,0,0,-0.1);

	this.seih4 = new lib.vjv202q3正解4();
	this.seih4.parent = this;
	this.seih4.setTransform(282.5,90.8,1.25,1.25,0,0,0,0,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.seih4},{t:this.seih2},{t:this.seih1},{t:this.seih3}]},191).to({state:[]},38).wait(236));

	// 操作テキスト
	this.instance_7 = new lib.vjvQ操作txt("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(2.5,375.3,1.25,1.25);

	this.instance_8 = new lib.vjvQ操作txt1("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(2.5,375.3,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},111).to({state:[]},56).to({state:[{t:this.instance_8}]},76).to({state:[]},36).wait(186));

	// 計算ボタン
	this.instance_9 = new lib.keiBtmc();
	this.instance_9.parent = this;
	this.instance_9.setTransform(9.7,319.6,1.25,1.25,0,0,0,7.7,0);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(255).to({_off:false},0).to({_off:true},24).wait(186));

	// 計算ボタン
	this.keimc = new lib.vjv計算btmc1();
	this.keimc.parent = this;
	this.keimc.setTransform(9.7,319.6,1.25,1.25,0,0,0,7.7,0);

	this.instance_10 = new lib.vjv202BT計算g("single",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(-52.3,298.3,1.25,1.25);

	this.instance_11 = new lib.vjv202BT計算();
	this.instance_11.parent = this;
	this.instance_11.setTransform(-52.3,298.3,1.25,1.25);
	new cjs.ButtonHelper(this.instance_11, 0, 1, 2, false, new lib.vjv202BT計算(), 3);

	this.instance_12 = new lib.vjv202BT計算明();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-52.3,298.3,1.25,1.25);
	new cjs.ButtonHelper(this.instance_12, 0, 1, 2, false, new lib.vjv202BT計算明(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.keimc}]},111).to({state:[{t:this.instance_10}]},56).to({state:[{t:this.instance_11}]},62).to({state:[{t:this.instance_12}]},14).to({state:[{t:this.instance_11}]},4).to({state:[{t:this.instance_12}]},4).to({state:[]},4).wait(210));

	// クイズ操作説明アニメ
	this.instance_13 = new lib.vjv202選択600000("single",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(-74.3,-39.7,1.25,1.25);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(93).to({_off:false},0).wait(4).to({startPosition:0},0).to({x:-79.4,y:14.7,startPosition:1},2).to({x:-95,y:177.8,startPosition:0},6).to({alpha:0},4).to({_off:true},2).wait(354));

	// フェード
	this.instance_14 = new lib.フェード用2("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(261.3,203.3,1.25,1.25);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(89).to({_off:false},0).to({alpha:0},6).to({_off:true},2).wait(368));

	// フェード
	this.instance_15 = new lib.フェード用2("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-98.7,203.3,1.25,1.25);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(89).to({_off:false},0).to({alpha:0},6).to({_off:true},2).wait(368));

	// 解答欄範囲MC
	this.q1ans4 = new lib.解答欄範囲q14();
	this.q1ans4.parent = this;
	this.q1ans4.setTransform(270,220.3,1.25,1.25);

	this.q1ans3 = new lib.解答欄範囲q13();
	this.q1ans3.parent = this;
	this.q1ans3.setTransform(270,176.5,1.25,1.25);

	this.q1ans2 = new lib.解答欄範囲q12();
	this.q1ans2.parent = this;
	this.q1ans2.setTransform(-95.6,220.3,1.25,1.25);

	this.q1ans1 = new lib.解答欄範囲q11();
	this.q1ans1.parent = this;
	this.q1ans1.setTransform(-95.6,176.5,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.q1ans1},{t:this.q1ans2},{t:this.q1ans3},{t:this.q1ans4}]},89).to({state:[]},140).wait(236));

	// 選択範囲
	this.q1sel16 = new lib.vjv202q1選択肢16();
	this.q1sel16.parent = this;
	this.q1sel16.setTransform(285.6,135.3,1.25,1.25);

	this.q1sel15 = new lib.vjv202q1選択肢15();
	this.q1sel15.parent = this;
	this.q1sel15.setTransform(285.6,110.3,1.25,1.25);

	this.q1sel14 = new lib.vjv202q1選択肢14();
	this.q1sel14.parent = this;
	this.q1sel14.setTransform(285.6,85.3,1.25,1.25);

	this.q1sel13 = new lib.vjv202q1選択肢13();
	this.q1sel13.parent = this;
	this.q1sel13.setTransform(285.6,60.3,1.25,1.25);

	this.q1sel12 = new lib.vjv202q1選択肢12();
	this.q1sel12.parent = this;
	this.q1sel12.setTransform(285.6,35.3,1.25,1.25);

	this.q1sel11 = new lib.vjv202q1選択肢11();
	this.q1sel11.parent = this;
	this.q1sel11.setTransform(285.6,10.3,1.25,1.25);

	this.q1sel10 = new lib.vjv202q1選択肢10();
	this.q1sel10.parent = this;
	this.q1sel10.setTransform(285.6,-14.7,1.25,1.25);

	this.q1sel9 = new lib.vjv202q1選択肢9();
	this.q1sel9.parent = this;
	this.q1sel9.setTransform(285.6,-39.7,1.25,1.25);

	this.q1sel8 = new lib.vjv202q1選択肢8();
	this.q1sel8.parent = this;
	this.q1sel8.setTransform(-74.3,135.3,1.25,1.25);

	this.q1sel7 = new lib.vjv202q1選択肢7();
	this.q1sel7.parent = this;
	this.q1sel7.setTransform(-74.3,110.3,1.25,1.25);

	this.q1sel6 = new lib.vjv202q1選択肢6();
	this.q1sel6.parent = this;
	this.q1sel6.setTransform(-74.3,85.3,1.25,1.25);

	this.q1sel5 = new lib.vjv202q1選択肢5();
	this.q1sel5.parent = this;
	this.q1sel5.setTransform(-74.3,60.3,1.25,1.25);

	this.q1sel4 = new lib.vjv202q1選択肢4();
	this.q1sel4.parent = this;
	this.q1sel4.setTransform(-74.3,35.3,1.25,1.25);

	this.q1sel3 = new lib.vjv202q1選択肢3();
	this.q1sel3.parent = this;
	this.q1sel3.setTransform(-74.3,10.3,1.25,1.25);

	this.q1sel2 = new lib.vjv202q1選択肢2();
	this.q1sel2.parent = this;
	this.q1sel2.setTransform(-74.3,-14.7,1.25,1.25);

	this.q1sel1 = new lib.vjv202q1選択肢1();
	this.q1sel1.parent = this;
	this.q1sel1.setTransform(-74.3,-39.7,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.q1sel1},{t:this.q1sel2},{t:this.q1sel3},{t:this.q1sel4},{t:this.q1sel5},{t:this.q1sel6},{t:this.q1sel7},{t:this.q1sel8},{t:this.q1sel9},{t:this.q1sel10},{t:this.q1sel11},{t:this.q1sel12},{t:this.q1sel13},{t:this.q1sel14},{t:this.q1sel15},{t:this.q1sel16}]},89).to({state:[]},78).wait(298));

	// 誤メッセージ
	this.dame4 = new lib.vjv202q誤答メッセージ();
	this.dame4.parent = this;
	this.dame4.setTransform(204.4,272.1,1.25,1.25);

	this.dame2 = new lib.vjv202q誤答メッセージ();
	this.dame2.parent = this;
	this.dame2.setTransform(-208,272.1,1.25,1.25);

	this.dame3 = new lib.vjv202q誤答メッセージ();
	this.dame3.parent = this;
	this.dame3.setTransform(201.9,122.1,1.25,1.25);

	this.dame1 = new lib.vjv202q誤答メッセージ();
	this.dame1.parent = this;
	this.dame1.setTransform(-100,122.8,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.dame1},{t:this.dame3},{t:this.dame2},{t:this.dame4}]},89).to({state:[]},78).wait(298));

	// 解答欄
	this.q1ap4 = new lib.vjv202q1解答欄B2();
	this.q1ap4.parent = this;
	this.q1ap4.setTransform(270,220.3,1.25,1.25);

	this.q1ap2 = new lib.vjv202q1解答欄A2();
	this.q1ap2.parent = this;
	this.q1ap2.setTransform(-95,220.3,1.25,1.25);

	this.q1ap3 = new lib.vjv202q3解答欄B1();
	this.q1ap3.parent = this;
	this.q1ap3.setTransform(270,177.8,1.25,1.25);

	this.q1ap1 = new lib.vjv202q3解答欄A1();
	this.q1ap1.parent = this;
	this.q1ap1.setTransform(-95,177.8,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.q1ap1},{t:this.q1ap3},{t:this.q1ap2},{t:this.q1ap4}]},89).to({state:[]},140).wait(236));

	// 計算結果20％
	this.instance_16 = new lib.vjv2021("single",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(251.4,198,1.25,1.25);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(285).to({_off:false},0).wait(34).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(20).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(110));

	// 計算結果40％
	this.instance_17 = new lib.vjv2023("single",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(-109.8,198,1.25,1.25);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(285).to({_off:false},0).wait(34).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(20).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(110));

	// 式イコール
	this.instance_18 = new lib.vjv202txtイコール("single",0);
	this.instance_18.parent = this;
	this.instance_18.setTransform(185.1,199.3,1.25,1.25);

	this.instance_19 = new lib.vjv202txtイコール("single",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(-179.9,199.3,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},89).to({state:[{t:this.instance_19,p:{startPosition:1}},{t:this.instance_18,p:{startPosition:1}}]},230).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},4).to({state:[{t:this.instance_19,p:{startPosition:1}},{t:this.instance_18,p:{startPosition:1}}]},4).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},20).to({state:[{t:this.instance_19,p:{startPosition:1}},{t:this.instance_18,p:{startPosition:1}}]},4).to({state:[{t:this.instance_19,p:{startPosition:0}},{t:this.instance_18,p:{startPosition:0}}]},4).wait(110));

	// レイヤー 36
	this.instance_20 = new lib.vjv202解答消し("synched",0,false);
	this.instance_20.parent = this;
	this.instance_20.setTransform(269.4,199.6,1.25,1.25);

	this.instance_21 = new lib.vjv202解答消し("synched",0,false);
	this.instance_21.parent = this;
	this.instance_21.setTransform(-95.6,199.6,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21},{t:this.instance_20}]},279).to({state:[]},6).wait(180));

	// 式括線
	this.instance_22 = new lib.vjv202括線("synched",0);
	this.instance_22.parent = this;
	this.instance_22.setTransform(270,199.1,1.25,1.25);

	this.instance_23 = new lib.vjv202括線("synched",0);
	this.instance_23.parent = this;
	this.instance_23.setTransform(-95,199.1,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_23},{t:this.instance_22}]},89).to({state:[]},196).wait(180));

	// 正解CG
	this.instance_24 = new lib.vjv23t6500("synched",0);
	this.instance_24.parent = this;
	this.instance_24.setTransform(264.6,177.8,1.25,1.25);

	this.instance_25 = new lib.vjv23t18000("synched",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(-95,177.8,1.25,1.25);

	this.instance_26 = new lib.vjv23t650000("single",0);
	this.instance_26.parent = this;
	this.instance_26.setTransform(270,220.3,1.25,1.25);

	this.instance_27 = new lib.vjv23t600000("single",0);
	this.instance_27.parent = this;
	this.instance_27.setTransform(-95,220.3,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24}]},89).to({state:[]},196).wait(180));

	// 消しフェード
	this.instance_28 = new lib.vjv202白隠し("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(0,367.7,5,2.5);
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(33).to({_off:false},0).to({alpha:0.012},6).to({_off:true},2).wait(424));

	// 営業利益率
	this.instance_29 = new lib.vjv202txt純利益率B("single",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(108.8,187.4,1.25,1.25);

	this.instance_30 = new lib.vjv202txt純利益率A("single",0);
	this.instance_30.parent = this;
	this.instance_30.setTransform(-252.4,187.4,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},33).to({state:[{t:this.instance_30,p:{startPosition:1}},{t:this.instance_29,p:{startPosition:1}}]},260).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},4).to({state:[{t:this.instance_30,p:{startPosition:1}},{t:this.instance_29,p:{startPosition:1}}]},4).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},4).to({state:[{t:this.instance_30,p:{startPosition:1}},{t:this.instance_29,p:{startPosition:1}}]},4).to({state:[{t:this.instance_30,p:{startPosition:0}},{t:this.instance_29,p:{startPosition:0}}]},4).wait(152));

	// Ｂ社
	this.instance_31 = new lib.vjv23表B要約損益計算書1("single",0);
	this.instance_31.parent = this;
	this.instance_31.setTransform(180.9,31.9,1.25,1.25,0,0,0,-0.3,0);
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(3).to({_off:false},0).wait(74).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(376));

	// Ａ社
	this.instance_32 = new lib.vjv23表A要約損益計算書1("single",0);
	this.instance_32.parent = this;
	this.instance_32.setTransform(-179.1,31.9,1.25,1.25,0,0,0,-0.3,0);
	this.instance_32._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(3).to({_off:false},0).wait(74).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(4).to({startPosition:1},0).wait(4).to({startPosition:0},0).wait(376));

	// base
	this.UI_ONOFF = new lib.UI_cBaseMC();
	this.UI_ONOFF.parent = this;
	this.UI_ONOFF.setTransform(-350,-212.4,7,8.45);

	this.timeline.addTween(cjs.Tween.get(this.UI_ONOFF).wait(465));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-351,-212.4,702,1689);


(lib.UIBtns = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// 音量
	this.vol_control = new lib.p1l_音量調整MC_nw();
	this.vol_control.parent = this;
	this.vol_control.setTransform(77.1,60.2,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.vol_control).wait(1));

	// 時間
	this.funbyo = new lib.学習時間MC();
	this.funbyo.parent = this;
	this.funbyo.setTransform(27,31.9,1,1,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.funbyo).wait(1));

	// スライド＆進捗バー
	this.slider = new lib.if_slider();
	this.slider.parent = this;
	this.slider.setTransform(9.9,11);

	this.timeline.addTween(cjs.Tween.get(this.slider).wait(1));

	// LMSメニューボタン
	this.LMS_MENU = new lib.LMSBtn();
	this.LMS_MENU.parent = this;
	this.LMS_MENU.setTransform(138.7,60.1);

	this.timeline.addTween(cjs.Tween.get(this.LMS_MENU).wait(1));

	// スマホ字幕ONボタン
	this.JIMAKU_ON = new lib.jimakuOnBtn();
	this.JIMAKU_ON.parent = this;
	this.JIMAKU_ON.setTransform(285.8,60.1);

	this.timeline.addTween(cjs.Tween.get(this.JIMAKU_ON).wait(1));

	// スマホ字幕OFFボタン
	this.JIMAKU_OFF = new lib.jimakuOffBtn();
	this.JIMAKU_OFF.parent = this;
	this.JIMAKU_OFF.setTransform(285.8,60.1);

	this.timeline.addTween(cjs.Tween.get(this.JIMAKU_OFF).wait(1));

	// 戻る
	this.BackBtn = new lib.backBtn();
	this.BackBtn.parent = this;
	this.BackBtn.setTransform(506.3,60.2,1,1.003);

	this.timeline.addTween(cjs.Tween.get(this.BackBtn).wait(1));

	// 再生
	this.PlayBtn = new lib.playBtn();
	this.PlayBtn.parent = this;
	this.PlayBtn.setTransform(579.7,60.1,1,1.003);

	this.timeline.addTween(cjs.Tween.get(this.PlayBtn).wait(1));

	// 一時停止
	this.PauseBtn = new lib.pauseBtn();
	this.PauseBtn.parent = this;
	this.PauseBtn.setTransform(579.7,60.1,1,1.003);

	this.timeline.addTween(cjs.Tween.get(this.PauseBtn).wait(1));

	// 進む
	this.NextBtn = new lib.nextBtn();
	this.NextBtn.parent = this;
	this.NextBtn.setTransform(653.2,60.2,1,1.003);

	this.timeline.addTween(cjs.Tween.get(this.NextBtn).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.502)").s().p("Eg2rAHCIAAuDMBtXAAAIAAODg");
	this.shape.setTransform(350,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.UIBtns, new cjs.Rectangle(0,0,700,133.1), null);


// stage content:
(lib.sm_vjv202_12_2 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{label_1:5,label_2:147,label_3:167,label_4:229,label_5:279});

	// timeline functions:
	this.frame_0 = function() {
		//共通変数群---------------------------
		//最初のファイルか？
		this.cFirstFileFlg = false;
		//最後のファイルか？
		this.cLastFileFlg = true;
		//ラベル数は？
		this.cTotalScene = 5;
		//指定ジャンプ先ラベル（「進む」「戻る」）初期化
		this.jtLabelB = "";
		this.jtLabelN = "";
		//指定ジャンプ先ファイル（「進む」「戻る」）
		this.jtFileB = "";
		this.jtFileN = "";
		
		//最終ラベルファンクション
		this.funcLL = function () {
			//最終ラベルのスクリプトをここにも記述
			SetCurrentNum(5);
			this.jtLabelB = "label_1";
		}
		
		//ラベルのフレーム番号を検出
		make_mycSArr();
		
		//スライド対応valMCの実行ファンクション
		this.fncValMC = function () {
			//キャンセル解除
			exportRoot.mcLyoko.q1ap1.visible = true;
			exportRoot.mcLyoko.q1ap2.visible = true;
			exportRoot.mcLyoko.q1ap3.visible = true;
			exportRoot.mcLyoko.q1ap4.visible = true;
		
			exportRoot.mcLtate.q1ap1.visible = true;
			exportRoot.mcLtate.q1ap2.visible = true;
			exportRoot.mcLtate.q1ap3.visible = true;
			exportRoot.mcLtate.q1ap4.visible = true;
			//キャンセル解除
			exportRoot.mcLyoko.q1ans1.visible = true;
			exportRoot.mcLyoko.q1ans2.visible = true;
			exportRoot.mcLyoko.q1ans3.visible = true;
			exportRoot.mcLyoko.q1ans4.visible = true;
		
			exportRoot.mcLtate.q1ans1.visible = true;
			exportRoot.mcLtate.q1ans2.visible = true;
			exportRoot.mcLtate.q1ans3.visible = true;
			exportRoot.mcLtate.q1ans4.visible = true;
		}.bind(this);
		
		this.selSel = -1;
		this.selAns = -1;
		k1ry = 0;
		k2ry = 0;
		k3ry = 0;
		k4ry = 0;
		kno = 0;
	}
	this.frame_1 = function() {
		SetBtnEvt();
		InitUI();
		CheckMode();
	}
	this.frame_5 = function() {
		SetCurrentNum(1);
		NextBtnOFF();
		this.jtLabelN = "label_3";
		//選択肢/解答欄選択変数
	}
	this.frame_17 = function() {
		playSound("vjv20214wav");
	}
	this.frame_77 = function() {
		playSound("vjv20215wav");
	}
	this.frame_89 = function() {
		/*
		//キャンセル解除
		exportRoot.mcLyoko.q1ap1.visible = true;
		exportRoot.mcLyoko.q1ap2.visible = true;
		exportRoot.mcLyoko.q1ap3.visible = true;
		exportRoot.mcLyoko.q1ap4.visible = true;
		
		exportRoot.mcLtate.q1ap1.visible = true;
		exportRoot.mcLtate.q1ap2.visible = true;
		exportRoot.mcLtate.q1ap3.visible = true;
		exportRoot.mcLtate.q1ap4.visible = true;
		*/
	}
	this.frame_91 = function() {
		/*
		//キャンセル解除
		exportRoot.mcLyoko.q1ans1.visible = true;
		exportRoot.mcLyoko.q1ans2.visible = true;
		exportRoot.mcLyoko.q1ans3.visible = true;
		exportRoot.mcLyoko.q1ans4.visible = true;
		
		exportRoot.mcLtate.q1ans1.visible = true;
		exportRoot.mcLtate.q1ans2.visible = true;
		exportRoot.mcLtate.q1ans3.visible = true;
		exportRoot.mcLtate.q1ans4.visible = true;
		*/
	}
	this.frame_147 = function() {
		SetCurrentNum(1);
		NextBtnOFF();
		exportRoot.jtLabelN = "label_3";
	}
	this.frame_151 = function() {
		if (!slider_operating) {
			//全て解答済みなのに判定を5秒間押さない場合
			if (exportRoot.mcLyoko.q1ans1.visible == false && exportRoot.mcLyoko.q1ans2.visible == false && exportRoot.mcLyoko.q1ans3.visible == false && exportRoot.mcLyoko.q1ans4.visible == false) {
				exportRoot.mcLyoko.keimc.gotoAndStop(2);
				exportRoot.mcLtate.keimc.gotoAndStop(2);
				exportRoot.timerMc.gotoAndPlay(2);
			}
		}
	}
	this.frame_166 = function() {
		Pause();
		PlayBtnOFF();
	}
	this.frame_167 = function() {
		SetCurrentNum(3);
		NextBtnOFF();
		this.jtLabelB = "label_1";
	}
	this.frame_169 = function() {
		playSound("vjvq_wWAV");
	}
	this.frame_177 = function() {
		playSound("vjv202k1wav");
	}
	this.frame_228 = function() {
		if (!slider_operating) {
			this.jtLabelB = "label_2";
			Back();
		}
	}
	this.frame_229 = function() {
		SetCurrentNum(4);
		this.jtLabelB = "label_1";
	}
	this.frame_231 = function() {
		playSound("vjv202k2wav");
	}
	this.frame_278 = function() {
		Pause();
		PlayBtnOFF();
	}
	this.frame_279 = function() {
		SetCurrentNum(5);
		this.jtLabelB = "label_1";
	}
	this.frame_291 = function() {
		playSound("vjv20216wav");
	}
	this.frame_464 = function() {
		Pause();
		UION("auto");
		BlinkNext();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(4).call(this.frame_5).wait(12).call(this.frame_17).wait(60).call(this.frame_77).wait(12).call(this.frame_89).wait(2).call(this.frame_91).wait(56).call(this.frame_147).wait(4).call(this.frame_151).wait(15).call(this.frame_166).wait(1).call(this.frame_167).wait(2).call(this.frame_169).wait(8).call(this.frame_177).wait(51).call(this.frame_228).wait(1).call(this.frame_229).wait(2).call(this.frame_231).wait(47).call(this.frame_278).wait(1).call(this.frame_279).wait(12).call(this.frame_291).wait(173).call(this.frame_464).wait(1));

	// 字幕MC
	this.JIMAKU = new lib.jimaku();
	this.JIMAKU.parent = this;
	this.JIMAKU.setTransform(350,285);
	this.JIMAKU._off = true;

	this.timeline.addTween(cjs.Tween.get(this.JIMAKU).wait(1).to({_off:false},0).wait(464));

	// UI
	this.UIBtns = new lib.UIBtns();
	this.UIBtns.parent = this;
	this.UIBtns.setTransform(0,325);
	this.UIBtns._off = true;

	this.timeline.addTween(cjs.Tween.get(this.UIBtns).wait(1).to({_off:false},0).wait(464));

	// 上部タイトルバー
	this.UItitleMC = new lib.UI_TitleMC();
	this.UItitleMC.parent = this;
	this.UItitleMC._off = true;

	this.timeline.addTween(cjs.Tween.get(this.UItitleMC).wait(1).to({_off:false},0).wait(464));

	// 上マスク
	this.instance = new lib.UI_hide1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(350,0,1,1,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(465));

	// コピーライト
	this.instance_1 = new lib.copyright2017("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(697.8,13,1.001,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(465));

	// wav
	this.val1MC = new lib.val();
	this.val1MC.parent = this;
	this.val1MC.setTransform(-12.9,15.1,1,1,0,0,0,5,5);
	this.val1MC._off = true;

	this.timeline.addTween(cjs.Tween.get(this.val1MC).wait(89).to({_off:false},0).to({_off:true},58).wait(318));

	// タイマーMC
	this.timerMc = new lib.制御判定btmc();
	this.timerMc.parent = this;
	this.timerMc.setTransform(713,-7.5);
	this.timerMc._off = true;

	this.timeline.addTween(cjs.Tween.get(this.timerMc).wait(149).to({_off:false},0).to({_off:true},18).wait(298));

	// 正解音
	this.otosei = new lib.音正解();
	this.otosei.parent = this;
	this.otosei.setTransform(-9.2,-8.7);
	this.otosei._off = true;

	this.timeline.addTween(cjs.Tween.get(this.otosei).wait(77).to({_off:false},0).to({_off:true},90).wait(298));

	// レイアウト:横
	this.mcLyoko = new lib.レイアウト横();
	this.mcLyoko.parent = this;
	this.mcLyoko.setTransform(350.1,212.5,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.mcLyoko).wait(465));

	// レイアウト:縦
	this.mcLtate = new lib.レイアウト縦();
	this.mcLtate.parent = this;
	this.mcLtate.setTransform(350.1,212.5,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.mcLtate).wait(465));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(350,-422.5,700,2534);
// library properties:
lib.properties = {
	width: 700,
	height: 845,
	fps: 12,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"sounds/vjv20214wav.mp3", id:"vjv20214wav"},
		{src:"sounds/vjv20215wav.mp3", id:"vjv20215wav"},
		{src:"sounds/vjv20216wav.mp3", id:"vjv20216wav"},
		{src:"sounds/vjv202k1wav.mp3", id:"vjv202k1wav"},
		{src:"sounds/vjv202k2wav.mp3", id:"vjv202k2wav"},
		{src:"sounds/vjvq_rWAV.mp3", id:"vjvq_rWAV"},
		{src:"sounds/vjvq_wWAV.mp3", id:"vjvq_wWAV"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;